object formDetalhes: TformDetalhes
  Left = 0
  Top = 0
  BorderIcons = [biSystemMenu]
  BorderStyle = bsSingle
  Caption = 'Detalhes'
  ClientHeight = 476
  ClientWidth = 690
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  KeyPreview = True
  OldCreateOrder = False
  Position = poScreenCenter
  OnClose = FormClose
  OnKeyPress = FormKeyPress
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object Shape1: TShape
    Left = 390
    Top = 240
    Width = 292
    Height = 111
    Brush.Style = bsClear
  end
  object Shape2: TShape
    Left = 3
    Top = 240
    Width = 381
    Height = 222
    Brush.Style = bsClear
  end
  object Label1: TLabel
    Left = 233
    Top = 68
    Width = 177
    Height = 18
    Caption = #205'tens Vendidos/Comprados'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -15
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label2: TLabel
    Left = 138
    Top = 218
    Width = 81
    Height = 18
    Caption = 'Pagamentos'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -15
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label6: TLabel
    Left = 317
    Top = 7
    Width = 27
    Height = 13
    Caption = 'Data:'
  end
  object DBText4: TDBText
    Left = 364
    Top = 7
    Width = 106
    Height = 17
    DataField = 'DataVencimento'
    DataSource = DM.dsqyListagemCR
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -15
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Label8: TLabel
    Left = 521
    Top = 218
    Width = 41
    Height = 18
    Caption = 'Status'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -15
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label9: TLabel
    Left = 394
    Top = 33
    Width = 28
    Height = 13
    Caption = 'Total:'
  end
  object DBText6: TDBText
    Left = 443
    Top = 33
    Width = 106
    Height = 17
    DataField = 'ValorTotal'
    DataSource = DM.dsqyListagemCR
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -15
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Label10: TLabel
    Left = 402
    Top = 41
    Width = 28
    Height = 13
    Caption = 'Total:'
  end
  object DBText7: TDBText
    Left = 451
    Top = 41
    Width = 106
    Height = 17
    DataField = 'ValorTotal'
    DataSource = DM.dsqyListagemCR
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -15
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Label11: TLabel
    Left = 414
    Top = 259
    Width = 80
    Height = 18
    Caption = 'Total devido'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -15
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object DBText8: TDBText
    Left = 528
    Top = 259
    Width = 138
    Height = 21
    Alignment = taRightJustify
    DataField = 'ValorTotal'
    DataSource = DM.dsqySaldoDinamico
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -15
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Shape3: TShape
    Left = 414
    Top = 278
    Width = 252
    Height = 1
  end
  object Label7: TLabel
    Left = 414
    Top = 285
    Width = 70
    Height = 18
    Caption = 'Total pago'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -15
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object DBText5: TDBText
    Left = 528
    Top = 285
    Width = 138
    Height = 21
    Alignment = taRightJustify
    DataField = 'TotalPago'
    DataSource = DM.dsqySaldoDinamico
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -15
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Shape4: TShape
    Left = 414
    Top = 304
    Width = 252
    Height = 1
  end
  object Label12: TLabel
    Left = 414
    Top = 311
    Width = 42
    Height = 18
    Caption = 'Saldo'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clRed
    Font.Height = -15
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object DBText9: TDBText
    Left = 528
    Top = 311
    Width = 138
    Height = 21
    Alignment = taRightJustify
    DataField = 'Saldo'
    DataSource = DM.dsqySaldoDinamico
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clRed
    Font.Height = -15
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Shape5: TShape
    Left = 414
    Top = 330
    Width = 252
    Height = 1
  end
  object DBGrid1: TDBGrid
    Left = 8
    Top = 92
    Width = 674
    Height = 120
    TabStop = False
    DataSource = DM.dsqyListagem
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -15
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    ReadOnly = True
    TabOrder = 2
    TitleFont.Charset = DEFAULT_CHARSET
    TitleFont.Color = clWindowText
    TitleFont.Height = -13
    TitleFont.Name = 'Tahoma'
    TitleFont.Style = []
    Columns = <
      item
        Expanded = False
        FieldName = 'IDDetalhe'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'DataLancamento'
        Title.Alignment = taCenter
        Title.Caption = 'Data Compra'
        Width = 100
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Produto'
        Title.Alignment = taCenter
        Width = 120
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Qtde'
        Title.Alignment = taCenter
        Width = 100
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Unidade'
        Title.Alignment = taCenter
        Width = 100
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'ValorUnitario'
        Title.Alignment = taCenter
        Width = 100
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'ValorTotal'
        Title.Alignment = taCenter
        Width = 100
        Visible = True
      end>
  end
  object DBGrid2: TDBGrid
    Left = 8
    Top = 244
    Width = 361
    Height = 153
    TabStop = False
    Color = 15132390
    DataSource = DM.dsPagamentos
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -15
    Font.Name = 'Tahoma'
    Font.Style = []
    Options = [dgTitles, dgIndicator, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgRowSelect, dgAlwaysShowSelection, dgConfirmDelete, dgCancelOnExit, dgTitleClick, dgTitleHotTrack]
    ParentFont = False
    ReadOnly = True
    TabOrder = 3
    TitleFont.Charset = DEFAULT_CHARSET
    TitleFont.Color = clWindowText
    TitleFont.Height = -13
    TitleFont.Name = 'Tahoma'
    TitleFont.Style = []
    Columns = <
      item
        Expanded = False
        FieldName = 'ID'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'DataPagamento'
        Title.Alignment = taCenter
        Title.Caption = 'Data Pagamento'
        Width = 154
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'ValorPago'
        Title.Alignment = taCenter
        Title.Caption = 'Valor Pago'
        Width = 156
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'IDDetalhe'
        Visible = False
      end>
  end
  object Panel1: TPanel
    Left = 0
    Top = 0
    Width = 690
    Height = 58
    Align = alTop
    Color = clSilver
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -15
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentBackground = False
    ParentFont = False
    TabOrder = 4
    object DBText2: TDBText
      Left = 72
      Top = 11
      Width = 361
      Height = 17
      DataField = 'Nome'
      DataSource = DM.dsqyListagemCR
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -15
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object DBText1: TDBText
      Left = 72
      Top = 30
      Width = 185
      Height = 17
      DataField = 'TipoLanc'
      DataSource = DM.dsqyListagemCR
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -15
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object DBText3: TDBText
      Left = 396
      Top = 29
      Width = 106
      Height = 17
      DataField = 'DataVencimento'
      DataSource = DM.dsqyListagemCR
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -15
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object Label3: TLabel
      Left = 17
      Top = 11
      Width = 47
      Height = 18
      Caption = 'Cliente:'
    end
    object Label4: TLabel
      Left = 31
      Top = 30
      Width = 33
      Height = 18
      Caption = 'Tipo:'
    end
    object Label5: TLabel
      Left = 338
      Top = 29
      Width = 50
      Height = 18
      Caption = 'Vencto:'
    end
    object Label13: TLabel
      Left = 340
      Top = 11
      Width = 48
      Height = 18
      Caption = 'Cidade:'
    end
    object DBText10: TDBText
      Left = 396
      Top = 11
      Width = 141
      Height = 17
      DataField = 'Cidade'
      DataSource = DM.dsqyListagemCR
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -15
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
    end
  end
  object DBNavigator1: TDBNavigator
    Left = 135
    Top = 435
    Width = 132
    Height = 20
    DataSource = DM.dsPagamentos
    VisibleButtons = [nbInsert, nbDelete, nbPost]
    TabOrder = 5
  end
  object campoData: TJvDBDatePickerEdit
    Left = 60
    Top = 398
    Width = 114
    Height = 27
    AllowNoDate = True
    ButtonWidth = 17
    DataField = 'DataPagamento'
    DataSource = DM.dsPagamentos
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -15
    Font.Name = 'Tahoma'
    Font.Style = []
    Glyph.Data = {
      F6060000424DF606000000000000360000002800000018000000180000000100
      180000000000C006000000000000000000000000000000000000FFFFFFFFFFFF
      9467469567469567459567469567459567469567469467459467459467469467
      45956745946745956746956745946746946746956745946746946745956745FF
      FFFFFFFFFFFFFFFF976847E7D0B6E7D0B6E6D0B7E6D0B6E7D0B6E6D0B6E6D0B6
      E7D0B6E7D0B6E6D0B6E6D0B6E7D0B6E7D0B6E6D0B7E6D0B7E7D0B6E6D0B6E7D0
      B7E6D0B6976846FFFFFFFFFFFFFFFFFF996A47E7D3BAE7D2BBE7D3BAE7D2BAE8
      D3BAE7D3BBE7D2BBE7D3BBE7D2BBE7D3BAE8D2BBE7D3BAE8D3BAE7D2BAE7D2BA
      E7D2BAE8D3BAE8D2BBE7D3BA996947FFFFFFFFFFFFFFFFFF9B6B48E8D5C0C698
      6EC6986EC6986EC6986EC6986EC6986EC6986EC6986EC6986EC6986EC6986EC6
      986EC6986EC6986EC6986EC6986ECA9D75E8D6BF9B6C49FFFFFFFFFFFFFFFFFF
      9F6D49EAD9C4C6986EF9EAE0FFF7F5FFF8F6CA9F7AFFF7F5FFF5F2FFF6F4CB9F
      7AFFF6F3FFF3F0FFF5F3CB9F79FFF4F2FFF4F0FFF5F3C6986EE9D9C39E6E49FF
      FFFFFFFFFFFFFFFFA16F4AEBDCC9C6986EF9EBE2FFF8F6FFF9F8CAA07BFFF8F7
      FFF6F4FFF8F6CB9F7AFFF7F5FFF4F2FFF6F4CB9F7AFFF5F3FFF5F2FFF6F4C698
      6EEADCC9A1704AFFFFFFFFFFFFFFFFFFA4724BECE0CEC6986EC89C74CAA07BCA
      A07BC28F61CAA07BCA9F7ACAA07BC28F61CAA07ACA9F7ACA9F7AC28F61CA9F7A
      CA9F7ACA9F7AC6986EECDFCEA4724CFFFFFFFFFFFFFFFFFFA8734DEEE2D3C698
      6EF9EEE5FFFBFAFFFBFBCAA17BFFFBFAFFF8F7FFFAF9CBA07BFFF9F9FFF7F5FF
      F9F8CBA07BFFF8F7FFF8F5FFF9F8C6986EEEE3D3A7744DFFFFFFFFFFFFFFFFFF
      AA764DEFE6D8C6986EF9F0E8FFFDFDFFFEFFCAA17CFFFDFEFFFBFAFFFDFDCBA1
      7CFFFCFCFFFAF8FFFBFBCBA17BFFFAFAFFFAFAFFFBFBC6986EEFE6D8AA764EFF
      FFFFFFFFFFFFFFFFAD784FEFE8DCC6986ECB9F76CDA37DCCA37DC29163CAA27D
      CAA17CCAA17CC29162CAA17CCAA17CCAA17CC29062CAA17CCAA17CCAA17CC698
      6EF0E9DCAD784FFFFFFFFFFFFFFFFFFFB0794FF1EBE1C6986E5676FA5B7DFFAF
      C0FFCCA37EFFFFFFFFFDFEFFFFFFCBA27DFFFEFFFFFCFCFFFEFECBA17CFFFDFD
      FFFDFDFFFEFEC6986EF1EBE1B07950FFFFFFFFFFFFFFFFFFB27B50F2EEE4C698
      6E0028FF002AFF7C99FFCCA47EFFFFFFFFFFFFFFFFFFCBA27EFFFFFFFFFDFFFF
      FFFFCBA17DFFFEFFFFFEFFFFFFFFC6986EF1EDE4B27B51FFFFFFFFFFFFFFFFFF
      B37C51F3EFE7C79A71C79A71C79A71C79A71C79A71C79A71C6986EC6986EC698
      6EC6986EC6986EC6986EC6986EC6986EC6986EC6986ECA9F79F2EFE8B47C51FF
      FFFFFFFFFFFFFFFFB57D52F3F1EAF3F1EAF3F1EAF3F1EAF3F1EAF3F1EAF3F1EA
      F3F1EAF3F1EAF3F1EAF3F1EAF3F1EAF3F1EAF3F1EAF3F1EAF3F1EAF3F1EAF3F1
      EAF3F1EAB57D52FFFFFFFFFFFFFFFFFFB57D52F3F1E9F3F1EAF3F1EAF3F1EAF3
      F1EAF3F1EAF3F1EAF3F1EAF3F1EAF3F1EAF3F1EAF3F1EAF3F1EAF3F1EAF3F1EA
      F3F1EAF3F1EAF3F1EAF3F1EAB57D52FFFFFFFFFFFFFFFFFF1421AC1421AC1421
      AC1421AC1421AC1421AC1421AC1421AC1421AC1421AC1421AC1421AC1421AC14
      21AC1421AC1421AC1421AC1421AC1421AC1421AC1421ACFFFFFFFFFFFFFFFFFF
      1829B83945D43945D43945D47F7AE4FFFFFE3940D3DAD6F51A24C53339D1C2B6
      F1DBD6F60810BD7166E6BCACF0131BBD1720BC131BBA131BBD131BBD192AB8FF
      FFFFFFFFFFFFFFFF1E32C2525FE8525FE8525FE85B64E8DAD9FECEC7FCFBFCFF
      E3E2FFFFFFFFA59CF6FFFFFF2A36D0FFFFFFF2F2FF1C25C9212BC71D26C51C25
      C91C25C91E32C2FFFFFFFFFFFFFFFFFF2239CE6373EB6373EB6373EB4154E07C
      7DEBE2DEFB7775E9FFFFFFFFFFFF2D3BD0EBE6FECEC7F5FFFFFFB8B1F42431CB
      2733D0222DCA2431CB2431CB2238CEFFFFFFFFFFFFFFFFFF263DD47489F47489
      F47489F47489F4A0A3FBFFFFFE152ECEFFFFFFFFFFFE061ECAFFFFFFFFFFFF92
      90F2EEE7FE2837D55D5DC7444ACB2837D52837D5263DD4FFFFFFFFFFFFFFFFFF
      263DD47489F47489F46161616161615B80F1D1DEFF607CECCFD5FEB5BCFB405A
      E0C6C7FB9697F75963E05F88F1535AD6616161616161535AD6535AD6263DD4FF
      FFFFFFFFFFFFFFFF5A65DF263DD4263DD4C0C0C0C0BFC00411DA0411DA0E25CE
      1832D00C27D3102BD31D37D50F2AD51531D51832D00410D6C0C0C0C0BFC0263D
      D4263DD44B50B3FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD1D1D1D1D1D1FF
      FFFFFFFFFFFFFFFFF9FAFEF9FAFEF9F9FEF9F9FEF9F9FEF9F9FEFFFFFFFFFFFF
      D1D1D1D1D1D1FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
      FFA6A6A6A6A6A6FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
      FFFFFFFFFFFFFFFFA6A6A6A6A6A6FFFFFFFFFFFFFFFFFFFFFFFF}
    ImageKind = ikCustom
    NoDateShortcut = 46
    ParentFont = False
    TabOrder = 0
  end
  object DBEdit1: TDBEdit
    Left = 192
    Top = 399
    Width = 146
    Height = 26
    DataField = 'ValorPago'
    DataSource = DM.dsPagamentos
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -15
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 1
  end
  object Timer1: TTimer
    Enabled = False
    OnTimer = Timer1Timer
    Left = 529
    Top = 327
  end
end
