unit UMenuCadastros;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ImgList, Menus;

type
  TformMenuCadastros = class(TForm)
    MainMenu1: TMainMenu;
    CADASTROS1: TMenuItem;
    Produtos1: TMenuItem;
    Clientes1: TMenuItem;
    iposdelanamentos1: TMenuItem;
    Unidades1: TMenuItem;
    procedure Produtos1Click(Sender: TObject);
    procedure Clientes1Click(Sender: TObject);
    procedure Unidades1Click(Sender: TObject);
    procedure iposdelanamentos1Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  formMenuCadastros: TformMenuCadastros;

implementation

uses UCadastroClientesFornecedores, UCadastroProdutos, UCadastroUnidades,
  UCadastroTiposLancamento;

{$R *.dfm}

procedure TformMenuCadastros.Clientes1Click(Sender: TObject);
begin

  formCadastroClientesFornecedores.showmodal;

end;

procedure TformMenuCadastros.iposdelanamentos1Click(Sender: TObject);
begin

  formCadastroTiposLancamento.ShowModal;

end;

procedure TformMenuCadastros.Produtos1Click(Sender: TObject);
begin

  formCadastroProdutos.ShowModal;

end;

procedure TformMenuCadastros.Unidades1Click(Sender: TObject);
begin

  formCadastroUnidades.ShowModal;

end;

end.
