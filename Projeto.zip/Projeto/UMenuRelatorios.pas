unit UMenuRelatorios;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ImgList, Menus, ExtCtrls;

type
  TformMenuRelatorios = class(TForm)
    MainMenu1: TMainMenu;
    RELATRIOS1: TMenuItem;
    Lanamentosporperodo1: TMenuItem;
    G1: TMenuItem;
    V1: TMenuItem;
    procedure Lanamentosporperodo1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure G1Click(Sender: TObject);
    procedure V1Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  formMenuRelatorios: TformMenuRelatorios;

implementation

uses UInformePeriodo, UMenuGraficos, UListagemVencimento;

{$R *.dfm}

procedure TformMenuRelatorios.Button2Click(Sender: TObject);
begin

  Self.Close;

end;

procedure TformMenuRelatorios.G1Click(Sender: TObject);
begin

  formMenuGraficos.ShowModal;

end;

procedure TformMenuRelatorios.Lanamentosporperodo1Click(Sender: TObject);
begin

  formInformePeriodo.ShowModal;

end;

procedure TformMenuRelatorios.V1Click(Sender: TObject);
begin

  formListagemVencimento.ShowModal;

end;

end.
