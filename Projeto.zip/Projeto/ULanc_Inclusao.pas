unit ULanc_Inclusao;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, Mask, JvExMask, JvToolEdit, JvMaskEdit, JvCheckedMaskEdit,
  JvDatePickerEdit, JvDBDatePickerEdit, Buttons, ExtCtrls, DB, DBCtrls, Grids,
  DBGrids, ImgList, JvDBLookup, JvExStdCtrls, JvCombobox, JvDBLookupComboEdit;

type
  TfrmLanc_Inclusao = class(TForm)
    Panel1: TPanel;
    btSalvar: TSpeedButton;
    Label1: TLabel;
    Label2: TLabel;
    SpeedButton2: TSpeedButton;
    SpeedButton3: TSpeedButton;
    SpeedButton4: TSpeedButton;
    Label3: TLabel;
    Label4: TLabel;
    Label5: TLabel;
    Label6: TLabel;
    Label7: TLabel;
    Label8: TLabel;
    Label13: TLabel;
    Shape3: TShape;
    Label14: TLabel;
    lblUnidade: TLabel;
    DBEdit1: TDBEdit;
    campoTipo: TDBComboBox;
    campoDataCompra: TJvDBDatePickerEdit;
    campoDataVencimento: TJvDBDatePickerEdit;
    campoCliente: TDBLookupComboBox;
    campoProduto: TDBLookupComboBox;
    campoQuantidade: TDBEdit;
    campoValorUnitario: TDBEdit;
    campoValorTotal: TDBEdit;
    DBEdit5: TDBEdit;
    DBLookupComboBox1: TDBLookupComboBox;
    procedure SpeedButton2Click(Sender: TObject);
    procedure SpeedButton3Click(Sender: TObject);
    procedure SpeedButton4Click(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure btSalvarClick(Sender: TObject);
    procedure campoProdutoCloseUp(Sender: TObject);
    procedure campoValorTotalEnter(Sender: TObject);
    procedure campoValorUnitarioExit(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmLanc_Inclusao: TfrmLanc_Inclusao;

implementation

uses UDMLanc;

{$R *.dfm}


procedure TfrmLanc_Inclusao.campoProdutoCloseUp(Sender: TObject);
begin

  DMLanc.tabProdutos.Locate('IDProduto',DMLanc.tabLancamentos.FieldByName('Lanc_IDProduto').Value,[loCaseInsensitive]);
  DMLanc.tabLancamentos.FieldByName('Lanc_ValorUnitario').Value := DMLanc.tabProdutos.FieldByName('Produto_ValorUnitario').Value;

end;

procedure TfrmLanc_Inclusao.campoValorTotalEnter(Sender: TObject);
begin

  if (campoQuantidade.Text = '') or (campoQuantidade.Text = '0') then
  begin
    ShowMessage('Informe a quantidade.');
    campoQuantidade.SetFocus;
    Abort;
  end;
  if (campoValorUnitario.Text = '') or (campoValorUnitario.Text = '0') then
  begin
    ShowMessage('Informe o valor unit�rio.');
    campoValorUnitario.SetFocus;
    Abort;
  end;

  campoValorTotal.Text := FormatFloat('0.00',Variant(campoQuantidade.Text) * Variant(campoValorUnitario.Text));


end;

procedure TfrmLanc_Inclusao.campoValorUnitarioExit(Sender: TObject);
begin

    if campoValorUnitario.Text <> '' then
    begin
      if StrToFloatDef(campoValorUnitario.text, 0) = 0 then
      begin
        ShowMessage('Valor unit�rio inv�lido!');
        campoValorUnitario.SetFocus;
      end;
    end;

end;

procedure TfrmLanc_Inclusao.FormShow(Sender: TObject);
begin

  DMLanc.qyClientes_lista.Close;
  DMLanc.qyClientes_lista.Open;
  DMLanc.qyProdutos_lista.Close;
  DMLanc.qyProdutos_lista.Open;
  DMLanc.qyGrupos_lista.Close;
  DMLanc.qyGrupos_lista.Open;

  campoTipo.SetFocus;

end;


procedure TfrmLanc_Inclusao.btSalvarClick(Sender: TObject);
begin

  if campoTipo.Text = '' then // (cpVencimento.Text='') or (cpCliente.Text='') or (cpProduto.Text='') or (cpQtde.Text='') or (cpValorUnitario.Text='') or (cpValorTotal.Text='') then
  begin
    ShowMessage('O tipo de lan�amento � obrigat�rio!' + #13 + 'O registro n�o pode ser inclu�do/atualizado.');
    campoTipo.SetFocus;
    Abort;
  end;
  if campoDataCompra.Text = '' then // (cpVencimento.Text='') or (cpCliente.Text='') or (cpProduto.Text='') or (cpQtde.Text='') or (cpValorUnitario.Text='') or (cpValorTotal.Text='') then
  begin
    ShowMessage('A data da compra � obrigat�ria!' + #13 + 'O registro n�o pode ser inclu�do/atualizado.');
    campoDataCompra.SetFocus;
    Abort;
  end;
  if campoDataVencimento.Text = '' then
  begin
    ShowMessage('A data de vencimento � obrigat�ria!' + #13 + 'O registro n�o pode ser inclu�do/atualizado.');
    campoDataVencimento.SetFocus;
    Abort;
  end;
  if campoCliente.Text = '' then
  begin
    ShowMessage('� obrigat�rio informar o cliente!' + #13 + 'O registro n�o pode ser inclu�do/atualizado.');
    campoCliente.SetFocus;
    Abort;
  end;
  if campoProduto.Text = '' then
  begin
    ShowMessage('� obrigat�rio informar o produto!' + #13 + 'O registro n�o pode ser inclu�do/atualizado.');
    campoProduto.SetFocus;
    Abort;
  end;
  if (campoQuantidade.Text = '') or (campoQuantidade.Text = '0') then
  begin
    ShowMessage('� obrigat�rio informar a quantidade!' + #13 + 'O registro n�o pode ser inclu�do/atualizado.');
    campoQuantidade.SetFocus;
    Abort;
  end;
  if campoValorUnitario.Text = '' then
  begin
    ShowMessage('� obrigat�rio informar o valor unit�rio!' + #13 + 'O registro n�o pode ser inclu�do/atualizado.');
    campoValorUnitario.SetFocus;
    Abort;
  end;

    campoValorTotal.Text := FormatFloat('0.00',Variant(campoQuantidade.Text) * Variant(campoValorUnitario.Text));

  try
    DMLanc.tabLancamentos.Post;
  finally
    ShowMessage('Registro inclu�do com sucesso!');

    if MessageDlg('Incluir novo lan�amento??', mtConfirmation, [mbYes,mbNo], 0) = mrYes then
    begin
      DMLanc.qyLanc_listagem.Close;
      DMLanc.qyLanc_listagem.Open;
      DMLanc.tabLancamentos.Append;
    end
    else
    begin
      Self.close;
    end;
  end;

end;


procedure TfrmLanc_Inclusao.SpeedButton2Click(Sender: TObject);
begin

  if campoDataCompra.Text <> '' then
  begin
    campoDataVencimento.Text := DateToStr(StrToDate(campoDataCompra.Text) + 30);
  end;

end;

procedure TfrmLanc_Inclusao.SpeedButton3Click(Sender: TObject);
begin

  if campoDataCompra.Text <> '' then
  begin
    campoDataVencimento.Text := DateToStr(StrToDate(campoDataCompra.Text) + 60);
  end;

end;

procedure TfrmLanc_Inclusao.SpeedButton4Click(Sender: TObject);
begin

  if campoDataCompra.Text <> '' then
  begin
    campoDataVencimento.Text := DateToStr(StrToDate(campoDataCompra.Text) + 90);
  end;

end;


end.
