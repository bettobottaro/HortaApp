program ControleVendas;

uses
  Forms,
  UPrincipal in 'UPrincipal.pas' {formPrincipal},
  UDM in 'UDM.pas' {DM: TDataModule},
  ULancamentos in 'ULancamentos.pas' {formLancamentos},
  UAlteracaoLancamentos in 'UAlteracaoLancamentos.pas' {formAlteracaoLancamentos},
  UInclusaoLancamentos in 'UInclusaoLancamentos.pas' {formInclusaoLancamentos},
  UInformePeriodo in 'UInformePeriodo.pas' {formInformePeriodo},
  UConfiguracoes in 'UConfiguracoes.pas' {formConfiguracoes},
  UMenuRelatorios in 'UMenuRelatorios.pas' {formMenuRelatorios},
  UCadastros in 'UCadastros.pas' {formCadastros},
  UGraficoSomatoriaTiposLancamento in 'UGraficoSomatoriaTiposLancamento.pas' {formGraficoSomatoriaTiposLancamento},
  UMenuGraficos in 'UMenuGraficos.pas' {formMenuGraficos},
  UGraficoQuantidadeProdutosPeriodo in 'UGraficoQuantidadeProdutosPeriodo.pas' {formGraficoQuantidadeProdutosPeriodo},
  UGraficoValorProdutosPeriodo in 'UGraficoValorProdutosPeriodo.pas' {formGraficoValorProdutosPeriodo},
  UAbout in 'UAbout.pas' {formAbout},
  ULancamentosCR in 'ULancamentosCR.pas' {frmLancamentosCR},
  UDetalhes in 'UDetalhes.pas' {formDetalhes},
  UListagemVencimento in 'UListagemVencimento.pas' {formListagemVencimento},
  ULogin in 'ULogin.pas' {frmLogin},
  UArvore in 'UArvore.pas' {formArvore},
  UResultado in 'UResultado.pas' {frmResultado};

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.Title := 'Controle de Vendas e Contas a Receber/Pagar';
  Application.CreateForm(TformPrincipal, formPrincipal);
  Application.CreateForm(TfrmLogin, frmLogin);
  Application.CreateForm(TDM, DM);
  Application.CreateForm(TformLancamentos, formLancamentos);
  Application.CreateForm(TformAlteracaoLancamentos, formAlteracaoLancamentos);
  Application.CreateForm(TformInclusaoLancamentos, formInclusaoLancamentos);
  Application.CreateForm(TformInformePeriodo, formInformePeriodo);
  Application.CreateForm(TformConfiguracoes, formConfiguracoes);
  Application.CreateForm(TformMenuRelatorios, formMenuRelatorios);
  Application.CreateForm(TformCadastros, formCadastros);
  Application.CreateForm(TformGraficoSomatoriaTiposLancamento, formGraficoSomatoriaTiposLancamento);
  Application.CreateForm(TformMenuGraficos, formMenuGraficos);
  Application.CreateForm(TformGraficoQuantidadeProdutosPeriodo, formGraficoQuantidadeProdutosPeriodo);
  Application.CreateForm(TformGraficoValorProdutosPeriodo, formGraficoValorProdutosPeriodo);
  Application.CreateForm(TformAbout, formAbout);
  Application.CreateForm(TfrmLancamentosCR, frmLancamentosCR);
  Application.CreateForm(TformDetalhes, formDetalhes);
  Application.CreateForm(TformListagemVencimento, formListagemVencimento);
  Application.CreateForm(TformArvore, formArvore);
  Application.CreateForm(TfrmResultado, frmResultado);
  Application.Run;
end.
