unit UMenuGraficos;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, Mask, JvExMask, JvToolEdit, JvMaskEdit, JvCheckedMaskEdit,
  JvDatePickerEdit, JvDBDatePickerEdit, ImgList, ExtCtrls, DB, DBCtrls,
  TeeGDIPlus, TeEngine, TeeProcs, Chart;

type
  TformMenuGraficos = class(TForm)
    GroupBox2: TGroupBox;
    GroupBox1: TGroupBox;
    OpcaoTipo1: TRadioButton;
    OpcaoTipo2: TRadioButton;
    Button1: TButton;
    ImageList1: TImageList;
    GroupBox6: TGroupBox;
    ListaGrupo: TDBLookupComboBox;
    Label1: TLabel;
    Panel1: TPanel;
    JvDBDatePickerEdit2: TJvDBDatePickerEdit;
    JvDBDatePickerEdit1: TJvDBDatePickerEdit;
    procedure Button1Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  formMenuGraficos: TformMenuGraficos;

implementation

uses UDM, UGraficoQuantidadeProdutosPeriodo, UGraficoValorProdutosPeriodo,
  UGraficoSomatoriaTiposLancamento;

{$R *.dfm}

procedure TformMenuGraficos.Button1Click(Sender: TObject);
begin

  if DM.tabParametros.State in [dsEdit] then
  begin
    DM.tabParametros.Post;
    DM.tabParametros.Close;
    DM.tabParametros.Open;
  end;

  if OpcaoTipo1.Checked = true then
  begin
    DM.qyQtdesPorPeriodo.Close;
    DM.qyQtdesPorPeriodo.Open;
    if DM.qyQtdesPorPeriodo.eof then
    begin
      ShowMessage('Sem dados para mostrar no per�odo informado!');
      Abort;
    end;
    formGraficoQuantidadeProdutosPeriodo.ShowModal;
  end;

  if OpcaoTipo2.Checked = true then
  begin
    DM.qyValoresPorPeriodo.Close;
    DM.qyValoresPorPeriodo.Open;
    if DM.qyValoresPorPeriodo.eof then
    begin
      ShowMessage('Sem dados para mostrar no per�odo informado!');
      Abort;
    end;
    formGraficoValorProdutosPeriodo.ShowModal;
  end;

end;

end.
