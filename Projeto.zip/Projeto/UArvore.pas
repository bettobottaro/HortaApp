﻿unit UArvore;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, Buttons, ComCtrls, ExtCtrls, StdCtrls, Grids, DBGrids, ImgList;

type
  TformArvore = class(TForm)
    Arvore: TTreeView;
    Panel1: TPanel;
    RadioGroup1: TRadioGroup;
    btComSaldo: TRadioButton;
    RadioButton2: TRadioButton;
    ImageList1: TImageList;
    btExpandir: TSpeedButton;
    lstTipos: TListBox;
    procedure FormShow(Sender: TObject);
    procedure btExpandirClick(Sender: TObject);
    procedure lstTiposDblClick(Sender: TObject);

  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  formArvore: TformArvore;

implementation

uses UDM;

{$R *.dfm}

procedure TformArvore.FormShow(Sender: TObject);
var
  Tipo, Ano, Mes, Vencimento, Texto : TTreeNode;
  vTipo, vAno, vMes, vVencimento, vTexto: String;
  Contador : Integer;

begin

  vTipo := '';
  vAno := '';
  vMes := '';
  vVencimento := '';
  vTexto := '';
  lstTipos.Clear;

  btExpandir.Caption := 'expandir tudo';

  With Arvore.Items do
  begin

    Clear;

    DM.qyTreeComSaldos.Close;
    DM.qyTreeComSaldos.Open;

    if btComSaldo.Checked = true then
    begin
      DM.qyTreeComSaldos.Filter := 'Saldo > 0';
      DM.qyTreeComSaldos.Filtered := true;
    end;
    if btComSaldo.Checked = false then
    begin
      DM.qyTreeComSaldos.Filtered := false;
    end;

    DM.qyTreeComSaldos.First;
    while not DM.qyTreeComSaldos.eof do
    begin

        if vTipo <> DM.qyTreeComSaldos.FieldByName('TipoLanc').Value then
        begin
          if Contador > 0 then
          begin
            Tipo := Add(Nil,'═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════');
          end;
          Tipo := Add(Nil,DM.qyTreeComSaldos.FieldByName('TipoLanc').Value);
          vAno := '';
          Contador := Contador + 1;
          lstTipos.Items.Add(DM.qyTreeComSaldos.FieldByName('TipoLanc').Value);
        end;

        if vAno <> DM.qyTreeComSaldos.FieldByName('Ano').Value then
        begin
          Ano := AddChild(Tipo,DM.qyTreeComSaldos.FieldByName('Ano').Value);
          vMes := '';
        end;

        if vMes <> DM.qyTreeComSaldos.FieldByName('Mes').Value then
        begin
          Mes := AddChild(Ano,DM.qyTreeComSaldos.FieldByName('Mes').Value);
        end;

        vTexto := 'Venc: ' + DM.qyTreeComSaldos.FieldByName('DataVencimento').AsString + ' - ' + DM.qyTreeComSaldos.FieldByName('Nome').value + ' - Devido: R$ ' + FormatFloat('###,###,##0.00',DM.qyTreeComSaldos.FieldByName('ValorTotal').value) + ' - Pago: R$ ' + FormatFloat('###,###,##0.00',DM.qyTreeComSaldos.FieldByName('TotalPago').value) + ' - Saldo: R$ ' + FormatFloat('###,###,##0.00',DM.qyTreeComSaldos.FieldByName('Saldo').value);
        Texto := AddChild(Mes,vTexto);
        vTipo := DM.qyTreeComSaldos.FieldByName('TipoLanc').Value;
        vAno := DM.qyTreeComSaldos.FieldByName('Ano').Value;
        vMes := DM.qyTreeComSaldos.FieldByName('Mes').Value;
        vVencimento := DM.qyTreeComSaldos.FieldByName('DataVencimento').AsString;

        DM.qyTreeComSaldos.Next;

    end;

  end;


end;

procedure TformArvore.lstTiposDblClick(Sender: TObject);
begin

  Arvore.FindChildControl(lstTipos.Items.Text);

end;



procedure TformArvore.btExpandirClick(Sender: TObject);
begin

  if btExpandir.Caption = 'expandir tudo' then
  begin
    Arvore.FullExpand;
    btExpandir.Caption := 'recolher tudo';
  end
  else
  begin
    Arvore.FullCollapse;
    btExpandir.Caption := 'expandir tudo';
  end;

end;

end.
