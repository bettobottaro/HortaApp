unit UCadastroProdutos;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, ExtCtrls, DBCtrls, Grids, DBGrids, DB;

type
  TformCadastroProdutos = class(TForm)
    DBGrid1: TDBGrid;
    DBNavigator1: TDBNavigator;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  formCadastroProdutos: TformCadastroProdutos;

implementation

uses UDM;

{$R *.dfm}

procedure TformCadastroProdutos.FormClose(Sender: TObject;
  var Action: TCloseAction);
begin

  if DM.tabProdutos.state in [dsEdit, dsInsert] then
  begin
        if MessageDlg('Deseja realmente sair sem salvar ?', mtConfirmation, [mbYes,mbNo], 0)=mrYes then
        begin
          DM.tabProdutos.Cancel;
        end
        else
        begin
          Abort;
        end;
  end;


end;

initialization
  RegisterClass(TformCadastroProdutos);

finalization
  UnRegisterClasses([TformCadastroProdutos]);

end.
