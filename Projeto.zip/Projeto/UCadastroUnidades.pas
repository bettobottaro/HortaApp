unit UCadastroUnidades;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, ExtCtrls, DBCtrls, Grids, DBGrids, DB;

type
  TformCadastroUnidades = class(TForm)
    DBGrid1: TDBGrid;
    DBNavigator1: TDBNavigator;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  formCadastroUnidades: TformCadastroUnidades;

implementation

uses UDM;

{$R *.dfm}

procedure TformCadastroUnidades.FormClose(Sender: TObject;
  var Action: TCloseAction);
begin

  if DM.tabUnidades.state in [dsEdit, dsInsert] then
  begin
        if MessageDlg('Deseja realmente sair sem salvar ?', mtConfirmation, [mbYes,mbNo], 0)=mrYes then
        begin
          DM.tabUnidades.Cancel;
        end
        else
        begin
          Abort;
        end;
  end;


end;

end.
