object formCadastros: TformCadastros
  Left = 0
  Top = 0
  BorderIcons = []
  Caption = 'Manunte'#231#227'o de Cadastros'
  ClientHeight = 571
  ClientWidth = 913
  Color = 6941107
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  PixelsPerInch = 96
  TextHeight = 13
  object Paginas1: TPageControl
    Left = 0
    Top = 0
    Width = 913
    Height = 521
    ActivePage = TabSheet3
    Align = alTop
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -15
    Font.Name = 'Tahoma'
    Font.Style = []
    MultiLine = True
    ParentFont = False
    Style = tsFlatButtons
    TabOrder = 1
    object pagClientesFornecedores: TTabSheet
      Caption = ' Clientes / Fornecedores '
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -16
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
      ExplicitLeft = 0
      ExplicitTop = 0
      ExplicitWidth = 0
      ExplicitHeight = 0
      object Grade1: TDBGrid
        Left = 0
        Top = 0
        Width = 905
        Height = 441
        Margins.Left = 10
        Margins.Top = 10
        Margins.Right = 10
        Margins.Bottom = 10
        Align = alTop
        DataSource = DM.dsClientesFornecedores
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -15
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentFont = False
        TabOrder = 0
        TitleFont.Charset = DEFAULT_CHARSET
        TitleFont.Color = clWindowText
        TitleFont.Height = -16
        TitleFont.Name = 'Tahoma'
        TitleFont.Style = []
        OnDrawColumnCell = Grade1DrawColumnCell
        Columns = <
          item
            Alignment = taCenter
            Color = 6029229
            Expanded = False
            FieldName = 'IDClienteFornecedor'
            Title.Alignment = taCenter
            Title.Caption = 'ID'
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Visible = False
          end
          item
            Expanded = False
            FieldName = 'Nome'
            Title.Alignment = taCenter
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Width = 250
            Visible = True
          end
          item
            Expanded = False
            FieldName = 'Endereco_linha1'
            Title.Alignment = taCenter
            Title.Caption = 'Logr, n'#186' - bairro'
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Width = 196
            Visible = True
          end
          item
            Expanded = False
            FieldName = 'Endereco_cidade'
            Title.Alignment = taCenter
            Title.Caption = 'Cidade'
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Width = 140
            Visible = True
          end
          item
            Expanded = False
            FieldName = 'Endereco_UF'
            Title.Alignment = taCenter
            Title.Caption = 'UF'
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Width = 50
            Visible = True
          end
          item
            Expanded = False
            FieldName = 'Endereco_CEP'
            Title.Caption = 'CEP'
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Width = 92
            Visible = True
          end
          item
            Expanded = False
            FieldName = 'Telefone'
            Title.Alignment = taCenter
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Width = 118
            Visible = True
          end
          item
            Expanded = False
            FieldName = 'Obs'
            Title.Alignment = taCenter
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Visible = False
          end>
      end
      object DBNavigator1: TDBNavigator
        Left = 325
        Top = 447
        Width = 240
        Height = 34
        DataSource = DM.dsClientesFornecedores
        VisibleButtons = [nbInsert, nbDelete, nbPost]
        TabOrder = 1
      end
    end
    object TabSheet1: TTabSheet
      Caption = 'Grupos'
      ImageIndex = 4
      object Grade5: TDBGrid
        Left = 0
        Top = 0
        Width = 905
        Height = 441
        Margins.Left = 10
        Margins.Top = 10
        Margins.Right = 10
        Margins.Bottom = 10
        Align = alTop
        DataSource = DM.dsGrupos
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -15
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentFont = False
        TabOrder = 0
        TitleFont.Charset = DEFAULT_CHARSET
        TitleFont.Color = clWindowText
        TitleFont.Height = -16
        TitleFont.Name = 'Tahoma'
        TitleFont.Style = []
        OnDrawColumnCell = Grade5DrawColumnCell
        Columns = <
          item
            Alignment = taCenter
            Expanded = False
            FieldName = 'ID'
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Visible = False
          end
          item
            Alignment = taCenter
            Expanded = False
            FieldName = 'Grupo'
            Title.Alignment = taCenter
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Width = 838
            Visible = True
          end>
      end
      object DBNavigator5: TDBNavigator
        Left = 325
        Top = 447
        Width = 240
        Height = 34
        DataSource = DM.dsGrupos
        VisibleButtons = [nbInsert, nbDelete, nbPost]
        TabOrder = 1
      end
    end
    object TabSheet2: TTabSheet
      Caption = ' Produtos '
      ImageIndex = 1
      ExplicitLeft = 0
      ExplicitTop = 0
      ExplicitWidth = 0
      ExplicitHeight = 0
      object Grade2: TDBGrid
        Left = 0
        Top = 0
        Width = 905
        Height = 441
        Margins.Left = 10
        Margins.Top = 10
        Margins.Right = 10
        Margins.Bottom = 10
        Align = alTop
        DataSource = DM.dsProdutos
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -15
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentFont = False
        TabOrder = 0
        TitleFont.Charset = DEFAULT_CHARSET
        TitleFont.Color = clWindowText
        TitleFont.Height = -16
        TitleFont.Name = 'Tahoma'
        TitleFont.Style = []
        OnDrawColumnCell = Grade2DrawColumnCell
        Columns = <
          item
            Alignment = taCenter
            Color = 6029229
            Expanded = False
            FieldName = 'IDProduto'
            Title.Alignment = taCenter
            Title.Caption = 'ID'
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Visible = False
          end
          item
            Expanded = False
            FieldName = 'Descricao'
            Title.Alignment = taCenter
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Width = 300
            Visible = True
          end
          item
            Expanded = False
            FieldName = 'GrupoAux'
            Title.Alignment = taCenter
            Title.Caption = 'Grupo'
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Width = 184
            Visible = True
          end
          item
            Expanded = False
            FieldName = 'Grupo'
            Title.Alignment = taCenter
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Visible = False
          end
          item
            Expanded = False
            FieldName = 'QtdeEstoque'
            Title.Alignment = taCenter
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Width = 150
            Visible = True
          end
          item
            Expanded = False
            FieldName = 'ValorBase'
            Title.Alignment = taCenter
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Width = 202
            Visible = True
          end
          item
            Expanded = False
            FieldName = 'Obs'
            Title.Alignment = taCenter
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Visible = False
          end>
      end
      object DBNavigator2: TDBNavigator
        Left = 325
        Top = 447
        Width = 240
        Height = 34
        DataSource = DM.dsProdutos
        VisibleButtons = [nbInsert, nbDelete, nbPost]
        TabOrder = 1
      end
    end
    object TabSheet4: TTabSheet
      Caption = ' Unidades '
      ImageIndex = 3
      ExplicitLeft = 0
      ExplicitTop = 0
      ExplicitWidth = 0
      ExplicitHeight = 0
      object Grade4: TDBGrid
        Left = 0
        Top = 0
        Width = 905
        Height = 441
        Margins.Left = 10
        Margins.Top = 10
        Margins.Right = 10
        Margins.Bottom = 10
        Align = alTop
        DataSource = DM.dsUnidades
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -16
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentFont = False
        TabOrder = 0
        TitleFont.Charset = DEFAULT_CHARSET
        TitleFont.Color = clWindowText
        TitleFont.Height = -16
        TitleFont.Name = 'Tahoma'
        TitleFont.Style = []
        OnDrawColumnCell = Grade4DrawColumnCell
        Columns = <
          item
            Alignment = taCenter
            Color = 6029229
            Expanded = False
            FieldName = 'IDUnidade'
            Title.Alignment = taCenter
            Title.Caption = 'ID'
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Visible = False
          end
          item
            Expanded = False
            FieldName = 'Unidade'
            Title.Alignment = taCenter
            Title.Caption = 'Descri'#231#227'o da Unidade'
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Width = 843
            Visible = True
          end>
      end
      object DBNavigator4: TDBNavigator
        Left = 325
        Top = 447
        Width = 240
        Height = 34
        DataSource = DM.dsUnidades
        VisibleButtons = [nbInsert, nbDelete, nbPost]
        TabOrder = 1
      end
    end
    object TabSheet3: TTabSheet
      Caption = ' Tipos de Lan'#231'amento '
      ImageIndex = 2
      object Grade3: TDBGrid
        Left = 0
        Top = 0
        Width = 905
        Height = 441
        Margins.Left = 10
        Margins.Top = 10
        Margins.Right = 10
        Margins.Bottom = 10
        Align = alTop
        DataSource = DM.dsTiposLancamentos
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -15
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentFont = False
        TabOrder = 0
        TitleFont.Charset = DEFAULT_CHARSET
        TitleFont.Color = clWindowText
        TitleFont.Height = -16
        TitleFont.Name = 'Tahoma'
        TitleFont.Style = []
        OnDrawColumnCell = Grade3DrawColumnCell
        OnDblClick = Grade3DblClick
        Columns = <
          item
            Alignment = taCenter
            Color = 6029229
            Expanded = False
            FieldName = 'IDTipo'
            Title.Alignment = taCenter
            Title.Caption = 'ID'
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Visible = False
          end
          item
            Alignment = taCenter
            Expanded = False
            FieldName = 'Descricao'
            Title.Alignment = taCenter
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Width = 281
            Visible = True
          end
          item
            Expanded = False
            FieldName = 'AuxSomarDeduzir'
            Title.Alignment = taCenter
            Title.Caption = '+/-'
            Visible = True
          end
          item
            Expanded = False
            FieldName = 'SomarDeduzir'
            Title.Alignment = taCenter
            Title.Caption = '+ / -'
            Visible = False
          end
          item
            Expanded = False
            FieldName = 'SimNao'
            Title.Alignment = taCenter
            Title.Caption = 'Listar Contas Receber/Pagar'
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Width = 252
            Visible = True
          end
          item
            Expanded = False
            FieldName = 'ControleCR'
            Title.Caption = 'Controle CR/PG'
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Visible = False
          end
          item
            Expanded = False
            FieldName = 'OrdemRelatorio'
            Title.Alignment = taCenter
            Title.Caption = 'Ordem no Relat'#243'rio'
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Width = 230
            Visible = True
          end
          item
            Expanded = False
            FieldName = 'Icone'
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -11
            Font.Name = 'Tahoma'
            Font.Style = []
            Title.Alignment = taCenter
            Title.Caption = #205'cone'
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Visible = False
          end
          item
            Expanded = False
            FieldName = 'IndiceImagem'
            Title.Alignment = taCenter
            Title.Caption = 'Ind'
            Title.Font.Charset = DEFAULT_CHARSET
            Title.Font.Color = clWindowText
            Title.Font.Height = -15
            Title.Font.Name = 'Tahoma'
            Title.Font.Style = []
            Visible = False
          end>
      end
      object DBNavigator3: TDBNavigator
        Left = 325
        Top = 447
        Width = 240
        Height = 34
        DataSource = DM.dsTiposLancamentos
        VisibleButtons = [nbInsert, nbDelete, nbPost]
        TabOrder = 1
      end
    end
  end
  object Button2: TButton
    Left = 408
    Top = 528
    Width = 97
    Height = 35
    Caption = 'Sair'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Tahoma'
    Font.Style = []
    ImageIndex = 1
    ImageMargins.Left = 10
    Images = ImageList1
    ParentFont = False
    TabOrder = 0
    TabStop = False
    OnClick = Button2Click
  end
  object ImageList1: TImageList
    Left = 32
    Top = 520
    Bitmap = {
      494C010102000500300010001000FFFFFFFFFF10FFFFFFFFFFFFFFFF424D3600
      0000000000003600000028000000400000001000000001002000000000000010
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      00000000000000000000000445005457830076799C00B9BBCC00D8D9E3000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      000000000000000000000000000000000000000000003D3D3D0041414100A5A5
      A500ADADAD00A8A8A800A6A6A600A2A2A200A0A0A0009D9D9D009A9A9A009A9A
      9A00919191003D3D3D0035353500000000000000000000000000000000000000
      00000A317D000C0D0F00001156004F82C7005A8DD2006699DE006598DD006497
      DC006295DA00426EB3002E559900001257000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      00000000000000000000000000000000000000000000949494004B4B4B00128B
      F300128BF300128BF300128BF300128BF300128BF300128BF300128BF300128B
      F300128BF3007F7F7F0050505000000000000000000000000000000000000000
      00000C3582000E0F1200001861003164A800396CB000487BBE005184C8005A8D
      D2005E91D6005689CE004679BD00001962000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      000000000000000000000000000000000000000000003E3E3E0041414100F0F0
      F00000000000FDFDFD00FAFAFA00F3F3F300F0F0F000EAEAEA00E7E7E700E7E7
      E700D5D5D5003030300021212100000000000000000000000000F9FCFA000000
      0000113F8B001313170000226D002A5DA1002B5EA2002B5EA2003363A900305E
      A8002B5EA2002B5EA2002B5CA00000236E000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      000000000000000000000000000000000000000000004242420044444400EFEF
      EF000000000000000000FEFEFE00F8F8F800F5F5F500EFEFEF00ECECEC00ECEC
      EC00D9D9D9003030300021212100000000000000000000000000002FE6000000
      00001342900014161A00002470002A5DA1002B5EA2002A5DA1002E5CA2002E5C
      A5002B5EA2002B5EA20026559900002571000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      000000000000000000000000000000000000000000004C4C4C004B4B4B00EFEF
      EF0000000000000000000000000000000000FEFEFE00F8F8F800F5F5F500F5F5
      F500E2E2E2002F2F2F0021212100000000000000000000000000002FE6000109
      CB00184A9A00191B200000287500295CA0002B5EA20024529700204A90002B57
      9F002B5EA2002B5DA1001E488C00012976000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      00000000000000000000000000000000000000000000515151004E4E4E00EFEF
      EF000000000000000000000000000000000000000000FDFDFD00FAFAFA00FBFB
      FB00E6E6E6002F2F2F0021212100000000000033EE000033EE00002FE600095E
      FE000400B4001B1E2300002A7800295CA000295B9F0019408500163C84002854
      9D002B5EA2002350940013387B00012B79000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      000000000000000000000000000000000000000000005B5B5B0055555500F0F0
      F000000000000000000000000000000000000000000000000000000000000000
      0000F0F0F0002F2F2F0021212100000000000033EE004089FF002874FF00095E
      FE000055FE0007008100002E7D0014266900477ABF00477ABF00477ABF00477A
      BF00477ABF00477ABF00477ABF00012F7E000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      000000000000000000000000000000000000000000006060600059595900E9E9
      E900FCFCFC00F4F4F400F4F4F400F5F5F500F5F5F500F5F5F500F5F5F5000000
      0000EAEAEA003131310022222200000000000033EE003F87FF002876FF00095D
      FE000055FE0007008100002F7F005287D100315EAA00305EA9003361AC00315F
      AA00305DA800305EA800305DA900013080000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      000000000000000000000000000000000000000000006B6B6B006A6A6A006262
      6200606060004E4E4E004A4A4A0045454500424242003D3D3D003A3A3A003737
      370037373700343434002D2D2D00000000000033EE000033EE00002CE600095D
      FE000400B400272A32000033840024579B00275A9E00275A9E002F60A4002B57
      A000275A9E00275A9E0024559900013485000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      00000000000000000000000000000000000000000000707070006A6A6A005E5E
      5E005A5A5A0060606000616161005959590055555500535353004F4F4F004242
      42003B3B3B003838380033333300000000000000000000000000002CE6000109
      CB002560B100292C35000035860024579B0026599D0025589C002C5BA0002D5B
      A40026599D0024579B00204F9200013687000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000075757500414141003030
      3000202020000000000000000000ECECEC00EAEAEA00B1B1B100B3B3B300C7C7
      C7008D8D8D00404040003D3D3D00000000000000000000000000002CE6000000
      00002560B1002D313A0000388B002154980024579B0020509300255097003563
      AF0023569A0021539700163D800001398C000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      000000000000000000000000000000000000000000007A7A7A00444444003434
      340025252500F7F7F700FAFAFA00E3E3E300E6E6E6005D5D5D0070707000C3C3
      C300898989004444440041414100000000000000000000000000000000000000
      00002560B1002F323D0000398C002053970023569900163F81001C448B003868
      B40022559900184285000C2B6C00013A8D000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000082828200484848003434
      340027272700F5F5F500FAFAFA00E2E2E200E6E6E6005151510067676700C2C2
      C2008C8C8C004C4C4C004A4A4A00000000000000000000000000000000000000
      00002560B10032373F00003C900025519700315FA700487AC800578AD9007CAF
      F40084B7FC007AADF2006A9DE200013D91000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000088888800454545002F2F
      2F00212121000000000000000000ECECEC00EAEAEA009B9B9B00A2A2A200C6C6
      C60093939300505050004E4E4E00000000000000000000000000000000000000
      00002560B10034384100003D910070A3E8007BAEF30088BBFF0085B8FD0083B6
      FB0078ACF200497FCA003069B500013E92000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      00000000000000000000044396005F87BC0083A2CB00CBD8EA00EDF2F8000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      0000000000000000000000000000000000000000000000000000000000000000
      000000000000000000000000000000000000424D3E000000000000003E000000
      2800000040000000100000000100010000000000800000000000000000000000
      000000000000000000000000FFFFFF00FFFFFC1F000000008001F00000000000
      8001F000000000008801D000000000008C01D000000000008F01C00000000000
      8F810000000000008FF100000000000080110000000000008001000000000000
      8001C000000000008601D000000000008001F000000000008001F00000000000
      8601F00000000000FFFFFC1F0000000000000000000000000000000000000000
      000000000000}
  end
  object OpenDialog1: TOpenDialog
    Filter = 'Imagens|*.bmp;*.jpg;*.jpeg;*.gif;*.png'
    InitialDir = 'c:\PlanilhaVendas\Icones'
    Left = 624
    Top = 448
  end
end
