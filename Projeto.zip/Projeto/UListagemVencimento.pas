unit UListagemVencimento;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, frxClass, frxDBSet, Buttons, ExtCtrls, StdCtrls, Mask, JvExMask,
  JvToolEdit, JvMaskEdit, JvCheckedMaskEdit, JvDatePickerEdit,
  JvDBDatePickerEdit, DB, Grids, DBGrids, DBCtrls, uImportExcel, frxExportXLS,
  frxExportXLSX, ComCtrls;

type
  TformListagemVencimento = class(TForm)
    GroupBox2: TGroupBox;
    campoData: TJvDBDatePickerEdit;
    JvDBDatePickerEdit1: TJvDBDatePickerEdit;
    chkOcultarPagos: TCheckBox;
    Relatorio: TfrxReport;
    Panel1: TPanel;
    btAtualizar: TSpeedButton;
    DadosRelatorio: TfrxDBDataset;
    Grade1: TDBGrid;
    GroupBox1: TGroupBox;
    TipoChecadoTodos: TRadioButton;
    TipoChecadoApenas: TRadioButton;
    ListaTipo: TDBLookupComboBox;
    btImprimir: TSpeedButton;
    Shape1: TShape;
    Configuracoes: TfrxDBDataset;
    ImportExcel1: TImportExcel;
    btExportarExcel: TSpeedButton;
    frxXLSXExport1: TfrxXLSXExport;
    GroupBox3: TGroupBox;
    ListaCliente: TDBLookupComboBox;
    ClienteChecadoApenas: TRadioButton;
    ClienteChecadoTodos: TRadioButton;
    SpeedButton1: TSpeedButton;
    btResultado: TSpeedButton;
    pgbar1: TProgressBar;
    Label1: TLabel;
    lblQtdeRegistros: TLabel;
    procedure btAtualizarClick(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure TipoChecadoTodosClick(Sender: TObject);
    procedure TipoChecadoApenasClick(Sender: TObject);
    procedure campoDataChange(Sender: TObject);
    procedure JvDBDatePickerEdit1Change(Sender: TObject);
    procedure chkOcultarPagosClick(Sender: TObject);
    procedure ListaTipoClick(Sender: TObject);
    procedure btImprimirClick(Sender: TObject);
    procedure btExportarExcelClick(Sender: TObject);
    procedure ClienteChecadoTodosClick(Sender: TObject);
    procedure ClienteChecadoApenasClick(Sender: TObject);
    procedure SpeedButton1Click(Sender: TObject);
    procedure btResultadoClick(Sender: TObject);
    procedure ListaClienteClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
    var
    TotalCreditos, TotalDebitos, Resultado: Double;

  end;

var
  formListagemVencimento: TformListagemVencimento;

implementation

uses UDM, UResultado;

{$R *.dfm}

procedure TformListagemVencimento.btExportarExcelClick(Sender: TObject);
var
  StrSQL, Grupo : String;

begin

  if DM.qyListagemCR.RecordCount = 0then
  begin
    ShowMessage('Sem dados a exportar!');
    Abort;
  end;

  StrSQL := 'delete from AuxVencimentos';
  DM.ConexaoMDB.Execute(strSQL);

  DM.qyListagemCR.First;
  while not DM.qyListagemCR.eof do
  begin
    DM.tabAuxVencimentos.Append;
    DM.tabAuxVencimentos.FieldByName('Tipo').Value := DM.qyListagemCR.FieldByName('TipoLanc').Value;
    DM.tabAuxVencimentos.FieldByName('Nome').Value := DM.qyListagemCR.FieldByName('Nome').Value;
    DM.tabAuxVencimentos.FieldByName('Vencimento').Value := DM.qyListagemCR.FieldByName('DataVencimento').Value;
    DM.tabAuxVencimentos.FieldByName('Dias').Value := DM.qyListagemCR.FieldByName('Dias').Value;
    DM.tabAuxVencimentos.FieldByName('Atraso').Value := DM.qyListagemCR.FieldByName('Atraso').Value;
    DM.tabAuxVencimentos.FieldByName('TotalDevido').Value := DM.qyListagemCR.FieldByName('ValorTotal').Value;
    DM.tabAuxVencimentos.FieldByName('TotalPago').Value := DM.qyListagemCR.FieldByName('TotalPago').Value;
    DM.tabAuxVencimentos.FieldByName('Saldo').Value := DM.qyListagemCR.FieldByName('Saldo').Value;
    DM.tabAuxVencimentos.Post;
    Grupo := DM.qyListagemCRTipoLanc.Value;
    DM.qyListagemCR.Next;
    if DM.qyListagemCRTipoLanc.Value <> Grupo then
    begin
      DM.tabAuxVencimentos.Append;
      DM.tabAuxVencimentos.FieldByName('Tipo').Value := Null;
      DM.tabAuxVencimentos.FieldByName('Nome').Value := Null;
      DM.tabAuxVencimentos.FieldByName('Vencimento').Value := Null;
      DM.tabAuxVencimentos.FieldByName('Dias').Value := Null;
      DM.tabAuxVencimentos.FieldByName('Atraso').Value := Null;
      DM.tabAuxVencimentos.FieldByName('TotalDevido').Value := Null;
      DM.tabAuxVencimentos.FieldByName('TotalPago').Value := Null;
      DM.tabAuxVencimentos.FieldByName('Saldo').Value := Null;
      DM.tabAuxVencimentos.Post;
    end;

  end;


  DM.tabAuxVencimentos.close;
  DM.tabAuxVencimentos.open;
  ImportExcel1.ExportarParaExcel(DM.tabAuxVencimentos,'Listagem');

end;

procedure TformListagemVencimento.btImprimirClick(Sender: TObject);
begin

  if DM.qyListagemCR.RecordCount = 0then
  begin
    ShowMessage('Sem dados a imprimir!');
    Abort;
  end;

  Relatorio.ShowReport();

end;

procedure TformListagemVencimento.btResultadoClick(Sender: TObject);
var
  strSQL: String;

begin

  TotalCreditos := 0;
  TotalDebitos := 0;
  Resultado := 0;

  StrSQL := 'delete from Resultado';
  DM.ConexaoMDB.Execute(strSQL);
  DM.tabResultado.Close;
  DM.tabResultado.Open;

  pgbar1.Max := DM.qyListagemCR.RecordCount;
  DM.qyListagemCR.First;

  while not DM.qyListagemCR.eof do
  begin
    pgbar1.Position := DM.qyListagemCR.RecNo;
    DM.tabResultado.Append;
    DM.tabResultado.FieldByName('Debito').Value := DM.qyListagemCR.FieldByName('ValorTotal').Value;
    DM.tabResultado.FieldByName('Credito').Value := DM.qyListagemCR.FieldByName('TotalPago').Value;
    DM.tabResultado.FieldByName('Referente').Value := '  ' + DM.qyListagemCR.FieldByName('TipoLanc').Value + ' - ' + DM.qyListagemCR.FieldByName('Nome').Value;
    if DM.qyListagemCR.FieldByName('ValorTotal').Value <> DM.qyListagemCR.FieldByName('TotalPago').Value then
    begin
      DM.tabResultado.FieldByName('Diferente').Value := 'Sim';
    end;
    DM.tabResultado.Post;

    TotalCreditos := TotalCreditos + DM.qyListagemCR.FieldByName('TotalPago').Value;
    TotalDebitos := TotalDebitos + DM.qyListagemCR.FieldByName('ValorTotal').Value;

    DM.qyListagemCR.Next;
  end;

  Resultado := TotalCreditos - TotalDebitos;
  DM.qyListagemCR.First;
  frmResultado.ShowModal;
  pgbar1.Position := 0;


end;


procedure TformListagemVencimento.campoDataChange(Sender: TObject);
begin

  Grade1.Visible := false;
  btImprimir.Enabled := false;
  btExportarExcel.Enabled := false;
  btResultado.Enabled := false;
  lblQtdeRegistros.Caption := '0';

end;

procedure TformListagemVencimento.chkOcultarPagosClick(Sender: TObject);
begin

  Grade1.Visible := false;
  btImprimir.Enabled := false;
  btExportarExcel.Enabled := false;
  btResultado.Enabled := false;
  lblQtdeRegistros.Caption := '0';

end;

procedure TformListagemVencimento.ClienteChecadoApenasClick(Sender: TObject);
begin

  ListaCliente.Enabled := true;
  Grade1.Visible := false;
  btImprimir.Enabled := false;
  btExportarExcel.Enabled := false;
  btResultado.Enabled := false;
  lblQtdeRegistros.Caption := '0';

end;

procedure TformListagemVencimento.ClienteChecadoTodosClick(Sender: TObject);
begin

  ListaCliente.Enabled := false;
  Grade1.Visible := false;
  btImprimir.Enabled := false;
  btExportarExcel.Enabled := false;
  btResultado.Enabled := false;
  lblQtdeRegistros.Caption := '0';

end;

procedure TformListagemVencimento.FormShow(Sender: TObject);
begin

  DM.tabPagamentos.Close;
  DM.tabPagamentos.Open;
  DM.tabLancamentos.Close;
  DM.tabLancamentos.Open;
  DM.qyTiposParaCR.Close;
  DM.qyTiposParaCR.Open;

  chkOcultarPagos.Checked := true;

  if DM.tabParametros.State in [dsEdit] then
  begin
    DM.tabParametros.Post;
    DM.tabParametros.Close;
    DM.tabParametros.Open;
  end;

  DM.qyListagemCR.Filter := 'DataVencimento >= ' + QuotedStr(DM.tabParametros.FieldByName('DataInicial').AsString) + ' and DataVencimento <= ' + QuotedStr(DM.tabParametros.FieldByName('DataFinal').AsString);
  DM.qyListagemCR.Filtered := true;

  if TipoChecadoApenas.Checked = true then
  begin
    DM.qyListagemCR.Filter := DM.qyListagemCR.Filter + ' and TipoLanc = ' + QuotedStr(DM.tabParametros.FieldByName('TipoLancamento').Value);
  end;


  if chkOcultarPagos.Checked = true then
  begin
    DM.qyListagemCR.Filter := DM.qyListagemCR.Filter + ' and Saldo > 0';
  end;

  lblQtdeRegistros.Caption := '0';

end;

procedure TformListagemVencimento.JvDBDatePickerEdit1Change(Sender: TObject);
begin

  Grade1.Visible := false;
  btImprimir.Enabled := false;
  btExportarExcel.Enabled := false;
  btResultado.Enabled := false;
  btResultado.Enabled := false;
  lblQtdeRegistros.Caption := '0';

end;

procedure TformListagemVencimento.ListaClienteClick(Sender: TObject);
begin

  Grade1.Visible := false;
  btImprimir.Enabled := false;
  btExportarExcel.Enabled := false;
  btResultado.Enabled := false;
  lblQtdeRegistros.Caption := '0';

end;

procedure TformListagemVencimento.ListaTipoClick(Sender: TObject);
begin

  Grade1.Visible := false;
  btImprimir.Enabled := false;
  btExportarExcel.Enabled := false;
  btResultado.Enabled := false;
  lblQtdeRegistros.Caption := '0';

end;

procedure TformListagemVencimento.SpeedButton1Click(Sender: TObject);
begin

  DM.tabParametros.Close;
  DM.tabParametros.Open;

end;

procedure TformListagemVencimento.btAtualizarClick(Sender: TObject);
begin

  if DM.tabParametros.State in [dsEdit] then
  begin
    DM.tabParametros.Post;
    DM.tabParametros.Close;
    DM.tabParametros.Open;
  end;

  DM.qyListagemCR.Filter := 'DataVencimento >= ' + QuotedStr(DM.tabParametros.FieldByName('DataInicial').AsString) + ' and DataVencimento <= ' + QuotedStr(DM.tabParametros.FieldByName('DataFinal').AsString);
  DM.qyListagemCR.Filtered := true;

  if TipoChecadoApenas.Checked = true then
  begin
    DM.qyListagemCR.Filter := DM.qyListagemCR.Filter + ' and TipoLanc = ' + QuotedStr(DM.tabParametros.FieldByName('TipoLancamento').Value);
  end;


  if ClienteChecadoApenas.Checked = true then
  begin
    DM.qyListagemCR.Filter := DM.qyListagemCR.Filter + ' and Nome = ' + QuotedStr(DM.tabParametros.FieldByName('ClienteFornecedor').Value);
  end;


  if chkOcultarPagos.Checked = true then
  begin
    DM.qyListagemCR.Filter := DM.qyListagemCR.Filter + ' and Saldo > 0  and AVista = ' + QuotedStr('N�o');
  end;

  btImprimir.Enabled := true;
  btExportarExcel.Enabled := true;
  Grade1.Visible := true;
  btResultado.Enabled := true;

  lblQtdeRegistros.Caption := IntToStr(DM.qyListagemCR.RecordCount);

end;

procedure TformListagemVencimento.TipoChecadoApenasClick(Sender: TObject);
begin

  ListaTipo.Enabled := true;
  Grade1.Visible := false;
  btImprimir.Enabled := false;
  btExportarExcel.Enabled := false;
  btResultado.Enabled := false;
  lblQtdeRegistros.Caption := '0';

end;

procedure TformListagemVencimento.TipoChecadoTodosClick(Sender: TObject);
begin

  ListaTipo.Enabled := false;
  Grade1.Visible := false;
  btImprimir.Enabled := false;
  btExportarExcel.Enabled := false;
  btResultado.Enabled := false;
  lblQtdeRegistros.Caption := '0';

end;

end.
