unit UInformePeriodo;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ImgList, Menus, Mask, JvExMask, JvToolEdit, JvMaskEdit,
  JvCheckedMaskEdit, JvDatePickerEdit, JvDBDatePickerEdit, frxClass, frxDBSet, DB,
  ExtCtrls, frxExportPDF, DBCtrls;

type
  TformInformePeriodo = class(TForm)
    campoData: TJvDBDatePickerEdit;
    Label1: TLabel;
    JvDBDatePickerEdit1: TJvDBDatePickerEdit;
    Label2: TLabel;
    ImageList1: TImageList;
    dsDadosPeriodo: TfrxDBDataset;
    RelPeriodo: TfrxReport;
    dsConfiguracoes: TfrxDBDataset;
    dsParametros: TfrxDBDataset;
    Panel1: TPanel;
    PDF: TfrxPDFExport;
    Button1: TButton;
    ListaCliente: TDBLookupComboBox;
    GroupBox1: TGroupBox;
    ClienteChecadoApenas: TRadioButton;
    ClienteChecadoTodos: TRadioButton;
    GroupBox2: TGroupBox;
    GroupBox3: TGroupBox;
    ListaProduto: TDBLookupComboBox;
    ProdutoChecadoApenas: TRadioButton;
    ProdutoChecadoTodos: TRadioButton;
    GroupBox5: TGroupBox;
    opcaoimprimir: TRadioButton;
    RadioButton2: TRadioButton;
    RelatorioResultado: TfrxDBDataset;
    GroupBox6: TGroupBox;
    ListaGrupo: TDBLookupComboBox;
    GrupoChecadoApenas: TRadioButton;
    GrupoChecadoTodos: TRadioButton;
    procedure FormKeyPress(Sender: TObject; var Key: Char);
    procedure Button1Click(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure ClienteChecadoTodosClick(Sender: TObject);
    procedure ProdutoChecadoTodosClick(Sender: TObject);
    procedure ProdutoChecadoApenasClick(Sender: TObject);

    procedure ClienteChecadoApenasClick(Sender: TObject);
    procedure GrupoChecadoTodosClick(Sender: TObject);
    procedure GrupoChecadoApenasClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  formInformePeriodo: TformInformePeriodo;

implementation

uses UDM;

{$R *.dfm}

procedure TformInformePeriodo.Button1Click(Sender: TObject);
var
  Filtros: String;
  xVendas, xComprasDespesas, xPerdas, xResultado: Double;

begin

  xVendas :=0;
  xComprasDespesas := 0;
  xPerdas := 0;
  xResultado := 0;

  if DM.tabParametros.State in [dsInsert, dsEdit] then
  begin
    DM.tabParametros.Post;
    DM.tabParametros.Close;
    DM.tabParametros.Open;
  end;

  DM.qyLancamentosPeriodo.Close;
  DM.qyLancamentosPeriodo.Open;

  DM.tabConfiguracao.Close;
  DM.tabConfiguracao.Open;


   // ****************************** FILTROS *************************************

  // TODOS OS GRUPOS > TODOS CLIENTES > TODOS PRODUTOS
  if  (GrupoChecadoTodos.Checked = true) and (ClienteChecadoTodos.Checked = true) and (ProdutoChecadoTodos.Checked = true) then
  begin
    DM.qyLancamentosPeriodo.Filtered := false;
    Filtros := 'Grupo: Todos | Cliente/Fornecedor: Todos | Produto: Todos';
  end;

  // TODOS GRUPOS > TODOS CLIENTES > DET PRODUTO
  if  (GrupoChecadoTodos.Checked = true) and (ClienteChecadoTodos.Checked = true) and (ProdutoChecadoTodos.Checked = false) then
  begin
    DM.qyLancamentosPeriodo.Filter := 'Produto = ' + QuotedStr(DM.tabParametros.FieldByName('Produto').Value);
    DM.qyLancamentosPeriodo.Filtered := true;
    Filtros := 'Grupo: Todos | Cliente/Fornecedor: Todos | Produto: ' + DM.tabParametros.FieldByName('Produto').Value;
  end;

  // TODOS GRUPOS > DET CLIENTE > TODOS PRODUTOS
  if  (GrupoChecadoTodos.Checked = true) and (ClienteChecadoTodos.Checked = false) and (ProdutoChecadoTodos.Checked = true) then
  begin
    DM.qyLancamentosPeriodo.Filter := 'Nome = ' + QuotedStr(DM.tabParametros.FieldByName('ClienteFornecedor').Value);
    DM.qyLancamentosPeriodo.Filtered := true;
    Filtros := 'Grupo: Todos | Cliente/Fornecedor: ' + DM.tabParametros.FieldByName('ClienteFornecedor').Value + ' | Produto: Todos';
  end;

  // TODOS GRUPOS > DET CLIENTE > DET PRODUTO
  if  (GrupoChecadoTodos.Checked = true) and (ClienteChecadoTodos.Checked = false) and (ProdutoChecadoTodos.Checked = false) then
  begin
    DM.qyLancamentosPeriodo.Filter := 'Nome = ' + QuotedStr(DM.tabParametros.FieldByName('ClienteFornecedor').Value) + ' and Produto = ' + QuotedStr(DM.tabParametros.FieldByName('Produto').Value);
    DM.qyLancamentosPeriodo.Filtered := true;
    Filtros := 'Grupo: Todos | Cliente/Fornecedor: ' + DM.tabParametros.FieldByName('ClienteFornecedor').Value + ' | Produto: ' + + DM.tabParametros.FieldByName('Produto').Value;
  end;

  // DET GRUPO > TODOS CLIENTES > TODOS PRODUTOS
  if  (GrupoChecadoTodos.Checked = false) and (ClienteChecadoTodos.Checked = true) and (ProdutoChecadoTodos.Checked = true) then
  begin
    DM.qyLancamentosPeriodo.Filter := 'Grupo = ' + QuotedStr(DM.tabParametros.FieldByName('Grupo').Value);
    DM.qyLancamentosPeriodo.Filtered := true;
    Filtros := 'Grupo: ' + DM.tabParametros.FieldByName('Grupo').Value + ' | Cliente/Fornecedor: Todos | Produto: Todos';
  end;

  // DET GRUPO > TODOS CLIENTES > DET PRODUTO
  if  (GrupoChecadoTodos.Checked = false) and (ClienteChecadoTodos.Checked = true) and (ProdutoChecadoTodos.Checked = false) then
  begin
    DM.qyLancamentosPeriodo.Filter := 'Grupo = ' + QuotedStr(DM.tabParametros.FieldByName('Grupo').Value) + ' and Produto = ' + QuotedStr(DM.tabParametros.FieldByName('Produto').Value);
    DM.qyLancamentosPeriodo.Filtered := true;
    Filtros := 'Grupo: ' + DM.tabParametros.FieldByName('Grupo').Value + ' | Cliente/Fornecedor: Todos | Produto: ' + DM.tabParametros.FieldByName('Produto').Value;
  end;

  // DET GRUPO > DET CLIENTE > TODOS PRODUTOS
  if  (GrupoChecadoTodos.Checked = false) and (ClienteChecadoTodos.Checked = false) and (ProdutoChecadoTodos.Checked = true) then
  begin
    DM.qyLancamentosPeriodo.Filter := 'Grupo = ' + QuotedStr(DM.tabParametros.FieldByName('Grupo').Value) + ' and Nome = ' + QuotedStr(DM.tabParametros.FieldByName('ClienteFornecedor').Value);
    DM.qyLancamentosPeriodo.Filtered := true;
    Filtros := 'Grupo: ' + DM.tabParametros.FieldByName('Grupo').Value + ' | Cliente/Fornecedor: ' + DM.tabParametros.FieldByName('ClienteFornecedor').Value + ' | Produto: Todos';
  end;

  // DET GRUPO > DET CLIENT > DET PRODUTO
  if  (GrupoChecadoTodos.Checked = false) and (ClienteChecadoTodos.Checked = false) and (ProdutoChecadoTodos.Checked = false) then
  begin
    DM.qyLancamentosPeriodo.Filter := 'Grupo = ' + QuotedStr(DM.tabParametros.FieldByName('Grupo').Value) + ' and Nome = ' + QuotedStr(DM.tabParametros.FieldByName('ClienteFornecedor').Value) + ' and Produto = ' + QuotedStr(DM.tabParametros.FieldByName('Produto').Value);
    DM.qyLancamentosPeriodo.Filtered := true;
    Filtros := 'Grupo: ' + DM.tabParametros.FieldByName('Grupo').Value + ' | Cliente/Fornecedor: ' + DM.tabParametros.FieldByName('ClienteFornecedor').Value + ' | Produto: ' + DM.tabParametros.FieldByName('ClienteFornecedor').Value;
  end;


    DM.tabParametros.Edit;
    DM.tabParametros.FieldByName('Filtros').Value := Filtros;
    DM.tabParametros.Post;
    DM.tabParametros.Close;
    DM.tabParametros.Open;


  // ********************************************************* FIM DOS FILTROS ********************************



    DM.qyLancamentosPeriodo.First;

  while not DM.qyLancamentosPeriodo.eof do
  begin
    if DM.qyLancamentosPeriodo.FieldByName('Tipo').value = 'Venda' then
      xVendas := xVendas + DM.qyLancamentosPeriodo.FieldByName('ValorTotal').value;
    if DM.qyLancamentosPeriodo.FieldByName('Tipo').value = 'Compra/Despesa' then
      xComprasDespesas := xComprasDespesas + DM.qyLancamentosPeriodo.FieldByName('ValorTotal').value;
    if DM.qyLancamentosPeriodo.FieldByName('Tipo').value = 'Perda' then
      xPerdas := xPerdas + DM.qyLancamentosPeriodo.FieldByName('ValorTotal').value;

    DM.qyLancamentosPeriodo.Next;

  end;


    xResultado := xVendas + xComprasDespesas + xPerdas;

    DM.tabRelatorioResultado.Edit;
    DM.tabRelatorioResultado.FieldByName('Vendas').Value := xVendas;
    DM.tabRelatorioResultado.FieldByName('ComprasDespesas').Value := xComprasDespesas;
    DM.tabRelatorioResultado.FieldByName('Perdas').Value := xPerdas;
    DM.tabRelatorioResultado.FieldByName('Resultado').Value := xResultado;
    DM.tabRelatorioResultado.Post;
    DM.tabRelatorioResultado.Close;
    DM.tabRelatorioResultado.Open;


  if opcaoimprimir.Checked = false then
  begin
    PDF.FileName := 'Lan�amentos de '+ FormatDateTime('dd-mm-yyyy',DM.tabParametros.FieldByName('DataInicial').value) + ' at� ' + FormatDateTime('dd-mm-yyyy',DM.tabParametros.FieldByName('DataFinal').value) + '.pdf';
    RelPeriodo.PrepareReport(True);
    RelPeriodo.Export(PDF);
  end
  else
  begin
    RelPeriodo.ShowReport();
  end;


end;



procedure TformInformePeriodo.ClienteChecadoApenasClick(Sender: TObject);
begin

  ListaCliente.Enabled := true;

end;

procedure TformInformePeriodo.ClienteChecadoTodosClick(Sender: TObject);
begin

  ListaCliente.Enabled := false;

end;

procedure TformInformePeriodo.FormKeyPress(Sender: TObject; var Key: Char);
begin

  if Key = #13 then
  begin
    Key := #0;
    PostMessage(Handle, WM_NEXTDLGCTL, 0, 0);
  end;

end;

procedure TformInformePeriodo.FormShow(Sender: TObject);
begin

  ListaGrupo.Enabled := false;
  ListaCliente.Enabled := false;
  ListaProduto.Enabled := false;

end;

procedure TformInformePeriodo.GrupoChecadoApenasClick(Sender: TObject);
begin

  ListaGrupo.Enabled := true;

end;

procedure TformInformePeriodo.GrupoChecadoTodosClick(Sender: TObject);
begin

  ListaGrupo.Enabled := false;

end;

procedure TformInformePeriodo.ProdutoChecadoApenasClick(Sender: TObject);
begin

  ListaProduto.Enabled := true;

end;

procedure TformInformePeriodo.ProdutoChecadoTodosClick(Sender: TObject);
begin

  ListaProduto.Enabled := false;

end;

end.
