unit ULanc_Manutencao;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, Mask, JvExMask, JvToolEdit, JvMaskEdit, JvCheckedMaskEdit,
  JvDatePickerEdit, JvDBDatePickerEdit, Buttons, ExtCtrls, DB, DBCtrls, Grids,
  DBGrids, ImgList;

type
  TfrmLanc_Manutencao = class(TForm)
    Panel1: TPanel;
    btSalvar: TSpeedButton;
    Label1: TLabel;
    Label2: TLabel;
    cpVencimento: TJvDBDatePickerEdit;
    cpCliente: TDBLookupComboBox;
    SpeedButton2: TSpeedButton;
    SpeedButton3: TSpeedButton;
    SpeedButton4: TSpeedButton;
    Label3: TLabel;
    cpDataCompra: TJvDBDatePickerEdit;
    Label8: TLabel;
    DBEdit4: TDBEdit;
    Shape1: TShape;
    Shape2: TShape;
    Label9: TLabel;
    btPagoTotal: TSpeedButton;
    Label13: TLabel;
    Shape3: TShape;
    btExcluir: TSpeedButton;
    cpTipo: TDBComboBox;
    lblDuploClique: TLabel;
    DBEdit1: TDBEdit;
    Label10: TLabel;
    Timer1: TTimer;
    lblValorTotal: TDBText;
    DBNavigator1: TDBNavigator;
    Shape4: TShape;
    ImageList1: TImageList;
    DBGrid1: TDBGrid;
    DBGrid2: TDBGrid;
    procedure SpeedButton2Click(Sender: TObject);
    procedure SpeedButton3Click(Sender: TObject);
    procedure SpeedButton4Click(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure btSalvarClick(Sender: TObject);
    procedure btPagoTotalClick(Sender: TObject);
    procedure btExcluirClick(Sender: TObject);
    procedure GradePagtosDblClick(Sender: TObject);
    procedure GradePagtosEnter(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
    procedure GradePagtosDrawColumnCell(Sender: TObject; const Rect: TRect;
      DataCol: Integer; Column: TColumn; State: TGridDrawState);
    procedure DBNavigator1Click(Sender: TObject; Button: TNavigateBtn);
    procedure DBGrid1DblClick(Sender: TObject);
    procedure DBGrid2DblClick(Sender: TObject);
    procedure DBGrid2DrawColumnCell(Sender: TObject; const Rect: TRect;
      DataCol: Integer; Column: TColumn; State: TGridDrawState);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmLanc_Manutencao: TfrmLanc_Manutencao;

implementation

uses UDMSQL, UCompras;

{$R *.dfm}


procedure TfrmLanc_Manutencao.DBGrid1DblClick(Sender: TObject);
begin

    if MessageDlg('Confirma a exclus�o da linha do pagamento??', mtConfirmation, [mbYes,mbNo], 0)<>mrYes then
    begin
      Abort;
    end;

    if not DMSQL.tabPagamentos.eof then
    begin
      try
      DMSQL.tabPagamentos.Delete;
      finally
      end;
    end;

end;

procedure TfrmLanc_Manutencao.DBGrid2DblClick(Sender: TObject);
begin

  frmCompras.ShowModal;

end;

procedure TfrmLanc_Manutencao.DBGrid2DrawColumnCell(Sender: TObject;
  const Rect: TRect; DataCol: Integer; Column: TColumn; State: TGridDrawState);
begin

  DMSQL.tabCompras.Edit;
  DMSQL.tabCompras.FieldByName('Produto').Value := DMSQL.tabProdutos.Locate('ID',DMSQL.tabCompras.FieldByName('IDProduto').Value,[]);
  DMSQL.tabCompras.FieldByName('ValorTotal').Value := DMSQL.tabCompras.FieldByName('Quantidade').Value * DMSQL.tabCompras.FieldByName('ValorUnitario').Value;
  DMSQL.tabCompras.Post;

end;

procedure TfrmLanc_Manutencao.DBNavigator1Click(Sender: TObject;
  Button: TNavigateBtn);
begin

  DMSQL.tabPagamentos.Append;

end;

procedure TfrmLanc_Manutencao.FormClose(Sender: TObject;
  var Action: TCloseAction);
begin

  DMSQL.tabLancamentos.Cancel;

end;

procedure TfrmLanc_Manutencao.FormShow(Sender: TObject);
begin

  {DM.qyClientes_lista.Close;
  DM.qyClientes_lista.Open;
  DM.qyProdutos_lista.Close;
  DM.qyProdutos_lista.Open;}
  DMSQL.qyGrupos_lista.Close;
  DMSQL.qyGrupos_lista.Open;

  cpdatacompra.SetFocus;

  if DMSQL.tabLancamentos.State in [dsInsert] then
  begin
  end
  else
  begin
    DMSQL.tabLancamentos.Edit;
  end;

  DMSQL.tabPagamentos.Filter := 'IDLancamento = ' + DMSQL.tabLancamentos.FieldByName('ID').AsString;

  if DMSQL.tabLancamentos.State in [dsInsert] then
  begin
    //GradePagtos.Visible := false;
    btPagoTotal.Visible := false;
    lblDuploClique.Visible := false;
    DMSQL.tabPagamentos.Filtered := false;
    lblValorTotal.Caption := '';
  end
  else
  begin
    //GradePagtos.Visible := true;
    btPagoTotal.Visible := true;
    lblDuploClique.Visible := true;
    DMSQL.tabPagamentos.Filtered := true;
    Timer1.Enabled := true;
  end;

end;

procedure TfrmLanc_Manutencao.GradePagtosDblClick(Sender: TObject);
begin

    if MessageDlg('Confirma a exclus�o da linha do pagamento??', mtConfirmation, [mbYes,mbNo], 0)<>mrYes then
    begin
      Abort;
    end;

      DMSQL.tabPagamentos.Delete;

end;

procedure TfrmLanc_Manutencao.GradePagtosDrawColumnCell(Sender: TObject;
  const Rect: TRect; DataCol: Integer; Column: TColumn; State: TGridDrawState);
var
  Icon: TBitmap;
  nIndiceImagem: byte;

begin

  {GradePagtos.DefaultDrawDataCell(Rect, Column.field, State);

  //�cones de acordo com o tipo
  if UpperCase(Column.Field.FieldName) = 'EXCLUIR' then
  begin
    GradePagtos.Canvas.FillRect(Rect);
    nIndiceImagem := 0;
      // desenha a imagem conforme a condi��o acima
      ImageList1.Draw(GradePagtos.Canvas, Rect.Left + 9, Rect.Top + 1, nIndiceImagem);
    end;}

end;

procedure TfrmLanc_Manutencao.GradePagtosEnter(Sender: TObject);
begin

  DMSQL.tabPagamentos.Edit;

end;

procedure TfrmLanc_Manutencao.btSalvarClick(Sender: TObject);
begin

  if cpTipo.Text = '' then // (cpVencimento.Text='') or (cpCliente.Text='') or (cpProduto.Text='') or (cpQtde.Text='') or (cpValorUnitario.Text='') or (cpValorTotal.Text='') then
  begin
    ShowMessage('O tipo de lan�amento � obrigat�rio!' + #13 + 'O registro n�o pode ser inclu�do/atualizado.');
    cpDataCompra.SetFocus;
    Abort;
  end;
  if cpDataCompra.Text = '' then // (cpVencimento.Text='') or (cpCliente.Text='') or (cpProduto.Text='') or (cpQtde.Text='') or (cpValorUnitario.Text='') or (cpValorTotal.Text='') then
  begin
    ShowMessage('A data da compra � obrigat�ria!' + #13 + 'O registro n�o pode ser inclu�do/atualizado.');
    cpDataCompra.SetFocus;
    Abort;
  end;
  if cpVencimento.Text = '' then
  begin
    ShowMessage('A data de vencimento � obrigat�ria!' + #13 + 'O registro n�o pode ser inclu�do/atualizado.');
    cpVencimento.SetFocus;
    Abort;
  end;
  if cpCliente.Text = '' then
  begin
    ShowMessage('� obrigat�rio informar o cliente!' + #13 + 'O registro n�o pode ser inclu�do/atualizado.');
    cpCliente.SetFocus;
    Abort;
  end;


  try
    //DMSQL.tabLancamentos.UpdateRecord;
    DMSQL.tabLancamentos.Post;
  finally
    ShowMessage('Registro atualizado com sucesso!');
    Self.close;
  end;

end;

procedure TfrmLanc_Manutencao.btExcluirClick(Sender: TObject);
begin

    if MessageDlg('Confirma a exclus�o do registro??', mtConfirmation, [mbYes,mbNo], 0)<>mrYes then
    begin
      Abort;
    end;

    try
    DMSQL.tabLancamentos.Delete;
    finally
      ShowMessage('Registro exclu�do com sucesso!!');
      Self.Close;
    end;

end;

procedure TfrmLanc_Manutencao.SpeedButton2Click(Sender: TObject);
begin

  if cpdatacompra.Text <> '' then
  begin
    DmSQL.tabLancamentos.Edit;
    DMSQL.tabLancamentosDataVencimento.Value := StrToDate(cpDataCompra.Text) + 30;
  end;

end;

procedure TfrmLanc_Manutencao.SpeedButton3Click(Sender: TObject);
begin

  if cpdatacompra.Text <> '' then
  begin
    DMSQL.tabLancamentos.Edit;
    DMSQL.tabLancamentosDataVencimento.Value := StrToDate(cpDataCompra.Text) + 60;
  end;

end;

procedure TfrmLanc_Manutencao.SpeedButton4Click(Sender: TObject);
begin

  if cpdatacompra.Text <> '' then
  begin
    DMSQL.tabLancamentos.Edit;
    DMSQL.tabLancamentosDataVencimento.Value := StrToDate(cpDataCompra.Text) + 90;
  end;

end;

procedure TfrmLanc_Manutencao.Timer1Timer(Sender: TObject);
begin

  DMSQL.qySomatoriaPagamentos.Close;
  DMSQL.qySomatoriaPagamentos.Open;
  DMSQL.qySomatoriaPagamentos.Filter := 'IDLancamento = ' + DMSQL.tabLancamentos.FieldByName('ID').AsString;
  DMSQL.qySomatoriaPagamentos.Filtered := true;

end;

procedure TfrmLanc_Manutencao.btPagoTotalClick(Sender: TObject);
begin

  if DMSQL.tabPagamentos.eof then
  begin
    DMSQL.tabPagamentos.Append;
    DMSQL.tabPagamentos.FieldByName('DataPagamento').Value := Date;
    DMSQL.tabPagamentos.FieldByName('ValorPago').Value := DMSQL.tabLancamentos.FieldByName('Lanc_ValorTotal').Value;
    DMSQL.tabPagamentos.Post;
  end;

end;

end.
