unit UAbrirForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs;

type
  TformAbrirForm = class(TForm)
  private
    procedure AbrirForm(sFormP: String; bModalP: Boolean);
    { Private declarations }
  public
    { Public declarations }
  end;

var
  formAbrirForm: TformAbrirForm;

implementation

{$R *.dfm}

// ABRIR FORM ********************************************
procedure TformAbrirForm.AbrirForm(sFormP: String; bModalP: Boolean);
Var
  FormClasse : TFormClass;
  FormTela : TForm;
  i : Integer;
  bCriado : Boolean;
begin
  bCriado := False;
  FormClasse := TFormClass(FindClass(sFormP));
  for i := 0 to Application.ComponentCount - 1 do
  begin
    if (Application.Components[i] is TForm) and
       (Application.Components[i].ClassName = sFormP) then
    begin
      FormTela := TForm(Application.Components[i]);
      bCriado := True;
      Break;
    end;
  end;
  if not bCriado then
    Application.CreateForm(FormClasse, FormTela);
  if bModalP then
  begin
    FormTela.ShowModal;
    FormTela.Free;
  end
  else
    FormTela.Show;
end;

// **********************************************************
//   No final de cada formoul�rio, antes do "end." do final do arquivo, incluir:
//
//    initialization
//    RegisterClass(TNomeDoForm);
//
//    finalization
//    UnRegisterClasses([TNomeDoForm]);
//
//
// ***********************************************************
//    Uso:  AbrirForm('TNomeDoForm', true    <= se for modal
//          AbrirForm('TNomeDoForm', false    <= se n�o for modal
// ***********************************************************


end.
