unit UCadastros;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, Tabs, ExtCtrls, DBCtrls, Grids, DBGrids, ComCtrls, JvExComCtrls,
  JvComCtrls, DB, ImgList, StdCtrls;

type
  TformCadastros = class(TForm)
    Paginas1: TPageControl;
    pagClientesFornecedores: TTabSheet;
    TabSheet2: TTabSheet;
    TabSheet3: TTabSheet;
    TabSheet4: TTabSheet;
    Grade1: TDBGrid;
    DBNavigator1: TDBNavigator;
    Grade2: TDBGrid;
    DBNavigator2: TDBNavigator;
    Grade3: TDBGrid;
    DBNavigator3: TDBNavigator;
    Grade4: TDBGrid;
    DBNavigator4: TDBNavigator;
    Button2: TButton;
    ImageList1: TImageList;
    TabSheet1: TTabSheet;
    Grade5: TDBGrid;
    DBNavigator5: TDBNavigator;
    OpenDialog1: TOpenDialog;
    procedure Button2Click(Sender: TObject);
    procedure Grade1DrawColumnCell(Sender: TObject; const Rect: TRect;
      DataCol: Integer; Column: TColumn; State: TGridDrawState);
    procedure Grade2DrawColumnCell(Sender: TObject; const Rect: TRect;
      DataCol: Integer; Column: TColumn; State: TGridDrawState);
    procedure Grade3DrawColumnCell(Sender: TObject; const Rect: TRect;
      DataCol: Integer; Column: TColumn; State: TGridDrawState);
    procedure Grade4DrawColumnCell(Sender: TObject; const Rect: TRect;
      DataCol: Integer; Column: TColumn; State: TGridDrawState);
    procedure Grade3DblClick(Sender: TObject);
    procedure Grade5DrawColumnCell(Sender: TObject; const Rect: TRect;
      DataCol: Integer; Column: TColumn; State: TGridDrawState);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  formCadastros: TformCadastros;

implementation

uses UDM;

{$R *.dfm}

procedure TformCadastros.Button2Click(Sender: TObject);
begin

  if  DM.tabClientesFornecedores.State in [dsEdit, dsInsert] then
  begin
      if MessageDlg('A tabela de CLIENTES/FORNECEDORES foi alterada.' + #13 + 'Sair sem salvar ?', mtConfirmation, [mbYes,mbNo], 0)=mrYes then
      begin
        DM.tabClientesFornecedores.Cancel;
      end
      else
      begin
        Abort;
      end;
  end;
  if  DM.tabProdutos.State in [dsEdit, dsInsert] then
  begin
      if MessageDlg('A tabela de PRODUTOS foi alterada.' + #13 + 'Sair sem salvar ?', mtConfirmation, [mbYes,mbNo], 0)=mrYes then
      begin
        DM.tabProdutos.Cancel;
      end
      else
      begin
        Abort;
      end;
  end;
  if  DM.tabTiposLancamentos.State in [dsEdit, dsInsert] then
  begin
      if MessageDlg('A tabela de TIPOS DE LAN�AMENTO foi alterada.' + #13 + 'Sair sem salvar ?', mtConfirmation, [mbYes,mbNo], 0)=mrYes then
      begin
        DM.tabTiposLancamentos.Cancel;
      end
      else
      begin
        Abort;
      end;
  end;
  if  DM.tabUnidades.State in [dsEdit, dsInsert] then
  begin
      if MessageDlg('A tabela de UNIDADES foi alterada.' + #13 + 'Sair sem salvar ?', mtConfirmation, [mbYes,mbNo], 0)=mrYes then
      begin
        DM.tabUnidades.Cancel;
      end
      else
      begin
        Abort;
      end;
  end;


  Self.Close;


end;

procedure TformCadastros.Grade1DrawColumnCell(Sender: TObject;
  const Rect: TRect; DataCol: Integer; Column: TColumn; State: TGridDrawState);
begin

  if odd(DM.tabClientesFornecedores.RecNo) then
    Grade1.Canvas.Brush.Color:= $00DDDDDD    //clLtGray
  else
    Grade1.Canvas.Brush.Color:= clCream;

  TDbGrid(Sender).Canvas.font.Color:= clBlack;
    if gdSelected in State then
      with (Sender as TDBGrid).Canvas do
        begin
          Brush.Color := $003EB56D;
          FillRect(Rect);
          Font.Style := [fsbold]
        end;

  TDbGrid(Sender).DefaultDrawDataCell(Rect, TDbGrid(Sender).columns[datacol].field, State);


end;

procedure TformCadastros.Grade2DrawColumnCell(Sender: TObject;
  const Rect: TRect; DataCol: Integer; Column: TColumn; State: TGridDrawState);
begin


  if odd(DM.tabProdutos.RecNo) then
    Grade2.Canvas.Brush.Color:= $00DDDDDD    //clLtGray
  else
    Grade2.Canvas.Brush.Color:= clCream;

  TDbGrid(Sender).Canvas.font.Color:= clBlack;
    if gdSelected in State then
      with (Sender as TDBGrid).Canvas do
        begin
          Brush.Color := $003EB56D;
          FillRect(Rect);
          Font.Style := [fsbold]
        end;

  TDbGrid(Sender).DefaultDrawDataCell(Rect, TDbGrid(Sender).columns[datacol].field, State);


end;

procedure TformCadastros.Grade3DblClick(Sender: TObject);
begin

//  if OpenDialog1.Execute then
//  begin
//    DM.tabTiposLancamentos.Edit;
//    DM.tabTiposLancamentos.FieldByName('Icone').Value := OpenDialog1.FileName;
//  end;


end;

procedure TformCadastros.Grade3DrawColumnCell(Sender: TObject;
  const Rect: TRect; DataCol: Integer; Column: TColumn; State: TGridDrawState);
begin

  if odd(DM.tabGrupos.RecNo) then
    Grade3.Canvas.Brush.Color:= $00DDDDDD    //clLtGray
  else
    Grade3.Canvas.Brush.Color:= clCream;

  TDbGrid(Sender).Canvas.font.Color:= clBlack;
    if gdSelected in State then
      with (Sender as TDBGrid).Canvas do
        begin
          Brush.Color := $003EB56D;
          FillRect(Rect);
          Font.Style := [fsbold]
        end;

  TDbGrid(Sender).DefaultDrawDataCell(Rect, TDbGrid(Sender).columns[datacol].field, State);


end;

procedure TformCadastros.Grade4DrawColumnCell(Sender: TObject;
  const Rect: TRect; DataCol: Integer; Column: TColumn; State: TGridDrawState);
begin

  if odd(DM.tabUnidades.RecNo) then
    Grade4.Canvas.Brush.Color:= $00DDDDDD    //clLtGray
  else
    Grade4.Canvas.Brush.Color:= clCream;

  TDbGrid(Sender).Canvas.font.Color:= clBlack;
    if gdSelected in State then
      with (Sender as TDBGrid).Canvas do
        begin
          Brush.Color := $003EB56D;
          FillRect(Rect);
          Font.Style := [fsbold]
        end;

  TDbGrid(Sender).DefaultDrawDataCell(Rect, TDbGrid(Sender).columns[datacol].field, State);


end;

procedure TformCadastros.Grade5DrawColumnCell(Sender: TObject;
  const Rect: TRect; DataCol: Integer; Column: TColumn; State: TGridDrawState);
begin

  if odd(DM.tabGrupos.RecNo) then
    Grade5.Canvas.Brush.Color:= $00DDDDDD    //clLtGray
  else
    Grade5.Canvas.Brush.Color:= clCream;

  TDbGrid(Sender).Canvas.font.Color:= clBlack;
    if gdSelected in State then
      with (Sender as TDBGrid).Canvas do
        begin
          Brush.Color := $003EB56D;
          FillRect(Rect);
          Font.Style := [fsbold]
        end;

  TDbGrid(Sender).DefaultDrawDataCell(Rect, TDbGrid(Sender).columns[datacol].field, State);


end;

end.
