unit UGraficoQuantidadeProdutoPeriodo;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, TeEngine, Series, ExtCtrls, TeeProcs, Chart, DBChart;

type
  TformGraficoQuantidadeProdutosPeriodo = class(TForm)
    DBChart1: TDBChart;
    Series1: TPieSeries;
    Panel1: TPanel;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  formGraficoQuantidadeProdutosPeriodo: TformGraficoQuantidadeProdutosPeriodo;

implementation

uses UDM;

{$R *.dfm}

end.
