unit UGraficoSomatoriaTiposLancamento;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, TeEngine, Series, ExtCtrls, TeeProcs, Chart, DBChart, Buttons,
  StdCtrls, frxClass, Grids, DBGrids;

type
  TformGraficoSomatoriaTiposLancamento = class(TForm)
    DBChart1: TDBChart;
    Series1: TPieSeries;
    Panel1: TPanel;
    SpeedButton1: TSpeedButton;
    SaveDialog1: TSaveDialog;
    tresde: TCheckBox;
    SpeedButton2: TSpeedButton;
    Grafico1: TfrxReport;
    procedure SpeedButton1Click(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure tresdeClick(Sender: TObject);
    procedure Grafico1BeforePrint(Sender: TfrxReportComponent);
    procedure SpeedButton2Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  formGraficoSomatoriaTiposLancamento: TformGraficoSomatoriaTiposLancamento;

implementation

uses UDM;

{$R *.dfm}


procedure TformGraficoSomatoriaTiposLancamento.FormShow(Sender: TObject);
var
  Vendas, Despesas, Perdas, Resultado: Double;

begin

  DBChart1.Title.caption := 'Resultado no Per�odo de ' + FormatDateTime('dd/mm/yy',DM.tabParametros.FieldByName('DataInicial').value) + ' a ' + FormatDateTime('dd/mm/yy',DM.tabParametros.FieldByName('DataFinal').value);

  // Atualizando tabela de GraficoResultado

  if DM.qySomatoriaTiposLancamento.Locate('Descricao','Venda',[]) then
    begin
      Vendas := DM.qySomatoriaTiposLancamento.FieldByName('ValorTotal').Value;
    end
    else
    begin
      Vendas := 0;
    end;

  if DM.qySomatoriaTiposLancamento.Locate('Descricao','Despesa',[]) then
    begin
      Despesas := DM.qySomatoriaTiposLancamento.FieldByName('ValorTotal').Value;
    end
    else
    begin
      Despesas := 0;
    end;

  if DM.qySomatoriaTiposLancamento.Locate('Descricao','Perda',[]) then
    begin
      Perdas := DM.qySomatoriaTiposLancamento.FieldByName('ValorTotal').Value;
    end
    else
    begin
      Perdas := 0;
    end;

  Resultado := Vendas - Despesas - Perdas;

  DM.tabGraficoResultado.First;
  DM.tabGraficoResultado.Edit;
  DM.tabGraficoResultado.FieldByName('ValorTotal').Value := Despesas;
  DM.tabGraficoResultado.Next;
  DM.tabGraficoResultado.Edit;
  DM.tabGraficoResultado.FieldByName('ValorTotal').Value := Perdas;
  DM.tabGraficoResultado.Next;
  DM.tabGraficoResultado.Edit;
  DM.tabGraficoResultado.FieldByName('ValorTotal').Value := Resultado;
  DM.tabGraficoResultado.Next;
  DM.tabGraficoResultado.Edit;
  DM.tabGraficoResultado.FieldByName('ValorTotal').Value := Vendas;

  DM.tabGraficoResultado.Post;

  // Atualiza a query do gr�fico
  DM.qyGraficoResultado.Close;
  DM.qyGraficoResultado.Open;

end;

procedure TformGraficoSomatoriaTiposLancamento.Grafico1BeforePrint(
  Sender: TfrxReportComponent);
begin

if Sender.Name = 'Picture1' then
   TfrxPictureView(Sender).Picture.Assign(
     DBChart1.TeeCreateMetafile(False,
       Rect(0, 0, Round(Sender.Width), Round(Sender.Height))));

end;

procedure TformGraficoSomatoriaTiposLancamento.SpeedButton1Click(
  Sender: TObject);
begin

  SaveDialog1.FileName := 'Gr�fico - Valores por Tipos de Lan�amento de '+ FormatDateTime('dd-mm-yy',DM.tabParametros.FieldByName('DataInicial').value) + ' a ' + FormatDateTime('dd-mm-yy',DM.tabParametros.FieldByName('DataFinal').value);

  If SaveDialog1.Execute Then
    Try
      DBChart1.TeeCreateBitmap(clWhite, Rect(0,0, DBChart1.Width, DBChart1.Height)).SaveToFile(SaveDialog1.FileName)
    Finally
      ShowMessage('Gr�fico exportado com sucesso!');
    End;
  end;

procedure TformGraficoSomatoriaTiposLancamento.SpeedButton2Click(
  Sender: TObject);
begin

  Grafico1.ShowReport();

end;


procedure TformGraficoSomatoriaTiposLancamento.tresdeClick(Sender: TObject);
begin

  if tresde.Checked = true then
  begin
    DBChart1.View3D := true;
  end
  else
  begin
    DBChart1.View3D := false;
  end;

end;

end.
