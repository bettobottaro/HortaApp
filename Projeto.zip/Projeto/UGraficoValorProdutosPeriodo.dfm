object formGraficoValorProdutosPeriodo: TformGraficoValorProdutosPeriodo
  Left = 0
  Top = 0
  BorderStyle = bsDialog
  Caption = 'Gr'#225'fico'
  ClientHeight = 542
  ClientWidth = 784
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object DBChart1: TDBChart
    Left = 0
    Top = 0
    Width = 784
    Height = 501
    Title.Font.Height = -19
    Title.Text.Strings = (
      'Gr'#225'fico')
    LeftAxis.AxisValuesFormat = 'R$#,##0.##'
    Legend.TextStyle = ltsPercent
    View3DOptions.Elevation = 315
    View3DOptions.Orthogonal = False
    View3DOptions.Perspective = 0
    View3DOptions.Rotation = 360
    Align = alClient
    TabOrder = 0
    ExplicitWidth = 654
    ExplicitHeight = 491
    object Series1: TPieSeries
      Marks.Arrow.Visible = True
      Marks.Callout.Brush.Color = clBlack
      Marks.Callout.Arrow.Visible = True
      Marks.Style = smsLabelValue
      Marks.Visible = True
      DataSource = DM.qyValoresPorPeriodo
      Title = 'Gr'#225'fico Anal'#237'tico'
      ValueFormat = '- R$ ###,###,##0.00'
      XLabelsSource = 'Descricao'
      Gradient.Direction = gdRadial
      OtherSlice.Legend.Visible = False
      PieValues.Name = 'Pie'
      PieValues.Order = loNone
      PieValues.ValueSource = 'ValorTotal'
    end
  end
  object Panel1: TPanel
    Left = 0
    Top = 501
    Width = 784
    Height = 41
    Align = alBottom
    TabOrder = 1
    ExplicitTop = 491
    ExplicitWidth = 654
    object SpeedButton1: TSpeedButton
      Left = 390
      Top = 6
      Width = 145
      Height = 25
      Caption = 'Exportar para  imagem'
      Glyph.Data = {
        CE010000424DCE01000000000000DE000000280000000F0000000F0000000100
        080000000000F0000000130B0000130B00002A0000002A000000FFFFFF000000
        0000FBFBFB0061616100F0F0F000BFBFBF00C8C8C8003E3E3E002F2F2F00B4B4
        B4009B9B9B00E0E0E0008F8F8F00DDDDDD00868686008B8B8B0096969600F5F5
        F500E6E6E60052525200ABABAB00D4D4D400A1A1A10023232300717171007B7B
        7B00CCCCCC00D5D5D5000E0E0E00C1C1C10025252500B7B7B700373737005757
        57001C1C1C0045454500161616005E5E5E007676760055555500696969003434
        3400000000000000000000000000000000000000000000000000000000000000
        0000000101010101010101010100000000000100000000000000000000010000
        0000010000000100000000000001000000000100000001000000000000010000
        0000010000000100000000000000000000000100000001150000000000011600
        0000010000000101010100000001011600000100000000010101010101010101
        0F0001000000000001010101010101010D00010000000000000000000001010D
        00000001010101010101010000010B0000000000000000000000000000000000
        000000000000000000000000000000000000}
      OnClick = SpeedButton1Click
    end
    object SpeedButton2: TSpeedButton
      Left = 239
      Top = 6
      Width = 145
      Height = 25
      Caption = 'Imprimir'
      Glyph.Data = {
        CA010000424DCA01000000000000DA000000280000000F0000000F0000000100
        080000000000F0000000130B0000130B00002900000029000000FFFFFF000000
        0000F5F5F500F1F1F100D4D4D400353535006C6C6C005252520074747400C8C8
        C800BCBCBC0042424200696969008F8F8F00E8E8E800565656003D3D3D008181
        8100C2C2C2004C4C4C002929290095959500E4E4E40084848400DEDEDE002424
        2400F9F9F900A2A2A200ABABAB00B5B5B500606060006F6F6F000B0B0B001B1B
        1B0031313100141414007A7A7A00CECECE00A4A4A400181818009B9B9B000000
        0000000000000000000000000000000000010101010101010101000000000000
        0001000000000000000400000000000A11000001010101012200111500000001
        0100000303030303000001010000000101000000000000000000010100000001
        0101010101010101010101010000000101010101010101010101010100000001
        0101010101010101010101010000000101010101010101010101010100000000
        0000010000000000010000000000000000000100000000000100000000000000
        00001500000000000B0000000000000000000003030303030000000000000000
        0000000000000000000000000000}
      OnClick = SpeedButton2Click
    end
    object tresde: TCheckBox
      Left = 16
      Top = 12
      Width = 48
      Height = 17
      Caption = '3D'
      Checked = True
      State = cbChecked
      TabOrder = 0
      OnClick = tresdeClick
    end
  end
  object SaveDialog1: TSaveDialog
    DefaultExt = 'bmp'
    Left = 720
    Top = 480
  end
  object Grafico1: TfrxReport
    Version = '4.9.20'
    DotMatrixReport = False
    IniFile = '\Software\Fast Reports'
    PreviewOptions.Buttons = [pbPrint, pbLoad, pbSave, pbExport, pbZoom, pbFind, pbOutline, pbPageSetup, pbTools, pbEdit, pbNavigator, pbExportQuick]
    PreviewOptions.Zoom = 1.000000000000000000
    PrintOptions.Printer = 'Default'
    PrintOptions.PrintOnSheet = 0
    ReportOptions.CreateDate = 42848.585557152800000000
    ReportOptions.LastChange = 42848.603713472220000000
    ScriptLanguage = 'PascalScript'
    ScriptText.Strings = (
      'procedure Page1OnBeforePrint(Sender: TfrxComponent);'
      'begin'
      ''
      ''
      '  '
      'end;'
      ''
      'begin'
      ''
      'end.')
    OnBeforePrint = Grafico1BeforePrint
    Left = 152
    Top = 464
    Datasets = <>
    Variables = <>
    Style = <>
    object Data: TfrxDataPage
      Height = 1000.000000000000000000
      Width = 1000.000000000000000000
    end
    object Page1: TfrxReportPage
      Orientation = poLandscape
      PaperWidth = 297.000000000000000000
      PaperHeight = 210.000000000000000000
      PaperSize = 9
      LeftMargin = 10.000000000000000000
      RightMargin = 10.000000000000000000
      TopMargin = 10.000000000000000000
      BottomMargin = 10.000000000000000000
      OnBeforePrint = 'Page1OnBeforePrint'
      object Picture1: TfrxPictureView
        Left = 3.779530000000000000
        Top = 3.779530000000000000
        Width = 1043.150280000000000000
        Height = 714.331170000000000000
        ShowHint = False
        HightQuality = False
        Transparent = False
        TransparentColor = clWhite
      end
    end
  end
end
