unit UDM;

interface

uses
  SysUtils, Classes, DB, ADODB, Dialogs, Forms, Windows;

type
  TDM = class(TDataModule)
    ConexaoMDB: TADOConnection;
    tabConfiguracao: TADOTable;
    tabConfiguracaoNome: TWideStringField;
    tabProdutos: TADOTable;
    tabProdutosIDProduto: TAutoIncField;
    tabProdutosDescricao: TWideStringField;
    tabProdutosQtdeEstoque: TFloatField;
    tabProdutosValorBase: TBCDField;
    tabProdutosObs: TWideMemoField;
    dsConfiguracao: TDataSource;
    dsProdutos: TDataSource;
    tabClientesFornecedores: TADOTable;
    dsClientesFornecedores: TDataSource;
    tabClientesFornecedoresNome: TWideStringField;
    tabClientesFornecedoresEndereco_linha1: TWideStringField;
    tabClientesFornecedoresTelefone: TWideStringField;
    tabClientesFornecedoresObs: TWideMemoField;
    tabTiposLancamentos: TADOTable;
    dsTiposLancamentos: TDataSource;
    tabTiposLancamentosIDTipo: TAutoIncField;
    tabTiposLancamentosDescricao: TWideStringField;
    tabTiposLancamentosOrdemRelatorio: TIntegerField;
    tabLancamentos: TADOTable;
    dsLancamentos: TDataSource;
    tabLancamentosIDLancamento: TAutoIncField;
    tabLancamentosDataLancamento: TDateTimeField;
    tabLancamentosIDTipo: TIntegerField;
    tabLancamentosIDClienteFornecedor: TIntegerField;
    tabLancamentosIDProduto: TIntegerField;
    qyListagem: TADOQuery;
    qyListagemDataLancamento: TDateTimeField;
    qyListagemTipo: TWideStringField;
    qyListagemNome: TWideStringField;
    qyListagemProduto: TWideStringField;
    qyListagemOrdemRelatorio: TIntegerField;
    dsqyListagem: TDataSource;
    tabLancamentosQtde: TFloatField;
    tabLancamentosValorUnitario: TBCDField;
    qyListagemQtde: TFloatField;
    qyListagemValorUnitario: TBCDField;
    qyListagemValorTotal: TFloatField;
    tabLancamentosObs: TWideStringField;
    qyListagemObs: TWideStringField;
    tabLancamentosValorTotal: TCurrencyField;
    qyListagemIDLancamento: TAutoIncField;
    tabUnidades: TADOTable;
    dsUnidades: TDataSource;
    tabUnidadesIDUnidade: TAutoIncField;
    tabUnidadesUnidade: TWideStringField;
    tabClientesFornecedoresIDClienteFornecedor: TAutoIncField;
    tabClientesFornecedoresAcrescimoDesconto: TBCDField;
    qyListagemUnidade: TWideStringField;
    tabLancamentosIDUnidade: TIntegerField;
    tabParametros: TADOTable;
    dsParametros: TDataSource;
    tabParametrosDataInicial: TDateTimeField;
    tabParametrosDataFinal: TDateTimeField;
    tabConfiguracaoImagem: TWideStringField;
    qyLancamentosPeriodo: TADOQuery;
    DateTimeField1: TDateTimeField;
    WideStringField1: TWideStringField;
    WideStringField2: TWideStringField;
    WideStringField3: TWideStringField;
    IntegerField1: TIntegerField;
    FloatField1: TFloatField;
    BCDField1: TBCDField;
    FloatField2: TFloatField;
    WideStringField4: TWideStringField;
    AutoIncField1: TAutoIncField;
    WideStringField5: TWideStringField;
    dsqyLancamentosPeriodo: TDataSource;
    tabConfiguracaoLogotipo: TWideStringField;
    tabParametrosClienteFornecedor: TWideStringField;
    tabParametrosTipoLancamento: TWideStringField;
    tabParametrosProduto: TWideStringField;
    tabParametrosFiltros: TWideStringField;
    dsqyQtdesPorPeriodo: TDataSource;
    qyValoresPorPeriodo: TADOQuery;
    dsqyValoresPorPeriodo: TDataSource;
    qySomatoriaTiposLancamento: TADOQuery;
    dsqySomatoriaTiposLancamento: TDataSource;
    qySomatoriaTiposLancamentoDescricao: TWideStringField;
    qySomatoriaTiposLancamentoValorTotal: TFloatField;
    tabGraficoResultado: TADOTable;
    dsGraficoResultado: TDataSource;
    tabGraficoResultadoDescricao: TWideStringField;
    tabGraficoResultadoValorTotal: TFloatField;
    qyGraficoResultado: TADOQuery;
    dsqyGraficoResultado: TDataSource;
    qyGraficoResultadoDescricao: TWideStringField;
    qyGraficoResultadoValorTotal: TFloatField;
    tabRelatorioResultado: TADOTable;
    dsRelatorioResultado: TDataSource;
    tabRelatorioResultadoVendas: TFloatField;
    tabRelatorioResultadoDespesas: TFloatField;
    tabRelatorioResultadoPerdas: TFloatField;
    tabRelatorioResultadoResultado: TFloatField;
    tabProdutosGrupo: TWideStringField;
    tabLancamentosDataVencimento: TDateTimeField;
    qyListagemDataVencimento: TDateTimeField;
    tabTiposLancamentosControleCR: TWideStringField;
    tabClientesFornecedoresEndereco_cidade: TWideStringField;
    tabClientesFornecedoresEndereco_UF: TWideStringField;
    tabClientesFornecedoresEndereco_CEP: TWideStringField;
    qyListagemCR: TADOQuery;
    dsqyListagemCR: TDataSource;
    qyListagemCRIDClienteFornecedor: TAutoIncField;
    qyListagemCRNome: TWideStringField;
    qyListagemCRDataVencimento: TDateTimeField;
    qyListagemCRControleCR: TWideStringField;
    qyListagemCRValorTotal: TFloatField;
    qyListagemCRCidade: TWideStringField;
    qyListagemCRDias: TWideStringField;
    qyListagemCRTipoLanc: TWideStringField;
    qyListagemIDDetalhe: TWideStringField;
    qyListagemCRIDDetalhe: TWideStringField;
    tabPagamentos: TADOTable;
    dsPagamentos: TDataSource;
    tabPagamentosID: TAutoIncField;
    tabPagamentosDataPagamento: TDateTimeField;
    tabPagamentosValorPago: TFloatField;
    tabPagamentosIDDetalhe: TWideStringField;
    tabSimNao: TADOTable;
    dsSimNao: TDataSource;
    tabTiposLancamentosSimNao: TStringField;
    tabSimNaoOpcao: TWideStringField;
    tabGrupos: TADOTable;
    dsGrupos: TDataSource;
    tabGruposID: TAutoIncField;
    tabGruposGrupo: TWideStringField;
    tabProdutosGrupoAux: TStringField;
    tabTiposLancamentosIcone: TWideStringField;
    tabTiposLancamentosIndiceImagem: TIntegerField;
    qyListagemCRTotalPago: TFloatField;
    qyListagemCRSaldo: TFloatField;
    tabParametrosGrupo: TWideStringField;
    qyLancamentosPeriodoGrupo: TWideStringField;
    qySomatoriaTiposLancamentoGrupo: TWideStringField;
    qyTiposParaCR: TADOQuery;
    dsqyTiposParaCR: TDataSource;
    qyTiposParaCRTipo: TWideStringField;
    qySaldoDinamico: TADOQuery;
    dsqySaldoDinamico: TDataSource;
    qySaldoDinamicoIDDetalhe: TWideStringField;
    qySaldoDinamicoValorTotal: TFloatField;
    qySaldoDinamicoTotalPago: TFloatField;
    qySaldoDinamicoSaldo: TFloatField;
    tabAuxVencimentos: TADOTable;
    dsAuxVencimentos: TDataSource;
    tabAuxVencimentosTipo: TWideStringField;
    tabAuxVencimentosNome: TWideStringField;
    tabAuxVencimentosVencimento: TDateTimeField;
    tabAuxVencimentosDias: TWideStringField;
    tabAuxVencimentosTotalDevido: TFloatField;
    tabAuxVencimentosTotalPago: TFloatField;
    tabAuxVencimentosSaldo: TFloatField;
    tabAuxVencimentosAtraso: TWideStringField;
    tabTiposLancamentosSomarDeduzir: TWideStringField;
    tabSomarDeduzir: TADOTable;
    dsSomarDeduzir: TDataSource;
    tabSomarDeduzirSomarDeduzir: TWideStringField;
    tabTiposLancamentosAuxSomarDeduzir: TStringField;
    qyLancamentosPeriodoSomarDeduzir: TWideStringField;
    qyListagemCRAVista: TWideStringField;
    tabLogin: TADOTable;
    dsLogin: TDataSource;
    tabLoginSenha: TWideStringField;
    qyQtdesPorPeriodo: TADOQuery;
    qyQtdesPorPeriodoProduto: TWideStringField;
    qyQtdesPorPeriodoQtde: TFloatField;
    qyValoresPorPeriodoDescricao: TWideStringField;
    qyValoresPorPeriodoValorTotal: TFloatField;
    qyTreeComSaldos: TADOQuery;
    dsqyTreeComSaldos: TDataSource;
    qyTreeComSaldosTipoLanc: TWideStringField;
    qyTreeComSaldosMes: TWideStringField;
    qyTreeComSaldosNome: TWideStringField;
    qyTreeComSaldosValorTotal: TFloatField;
    qyTreeComSaldosTotalPago: TFloatField;
    qyTreeComSaldosSaldo: TFloatField;
    qyTreeComSaldosAno: TWideStringField;
    qyTreeComSaldosDataVencimento: TDateTimeField;
    tabParametrosID: TAutoIncField;
    qyListagemCRDataPagamento: TDateTimeField;
    tabResultado: TADOTable;
    dsResultado: TDataSource;
    tabResultadoID: TAutoIncField;
    tabResultadoCredito: TFloatField;
    tabResultadoDebito: TFloatField;
    tabResultadoReferente: TWideStringField;
    qyResultado: TADOQuery;
    AutoIncField2: TAutoIncField;
    WideStringField6: TWideStringField;
    DateTimeField2: TDateTimeField;
    WideStringField7: TWideStringField;
    WideStringField8: TWideStringField;
    WideStringField9: TWideStringField;
    WideStringField10: TWideStringField;
    WideStringField11: TWideStringField;
    FloatField3: TFloatField;
    FloatField4: TFloatField;
    FloatField5: TFloatField;
    StringField1: TStringField;
    WideStringField12: TWideStringField;
    DateTimeField3: TDateTimeField;
    dsqyResultado: TDataSource;
    qyListagemCRAtraso: TWideStringField;
    tabResultadoDiferente: TWideStringField;
    procedure tabPagamentosBeforePost(DataSet: TDataSet);
    procedure DataModuleCreate(Sender: TObject);
    procedure tabLancamentosBeforePost(DataSet: TDataSet);
  private
    { Private declarations }
    function LocalizarBanco: String;
    procedure CorrigirDatasInvalidas;
    procedure AbrirDS(DS: TDataSet);
    procedure AbrirDataSets;
  public
    { Public declarations }
  end;

var
  DM: TDM;

implementation

{$R *.dfm}

// Limites de data aceitos pelo Jet/Access (o Jet nao aceita anos < 100).
// Aqui usamos uma faixa mais restritiva para barrar digitacao errada
// (ex.: "10/11/26" interpretado como ano 0026).
const
  DATA_MINIMA = 1900;
  DATA_MAXIMA = 2200;

function TDM.LocalizarBanco: String;
var
  sExe: String;
  Candidatos: array[0..3] of String;
  i: Integer;
begin
  sExe := ExtractFilePath(ParamStr(0));
  Candidatos[0] := ExpandFileName(sExe + 'BD\Dados.MDB');
  Candidatos[1] := ExpandFileName(sExe + '..\BD\Dados.MDB');
  Candidatos[2] := 'C:\ControleVendas\BD\Dados.MDB';
  Candidatos[3] := '\ControleVendas\BD\Dados.MDB';
  Result := '';
  for i := Low(Candidatos) to High(Candidatos) do
    if FileExists(Candidatos[i]) then
    begin
      Result := Candidatos[i];
      Break;
    end;
  if Result = '' then
  begin
    Application.MessageBox(PChar('Banco de dados nao encontrado.' + #13#10 + #13#10 +
      'Procurado em:' + #13#10 +
      Candidatos[0] + #13#10 + Candidatos[1] + #13#10 +
      Candidatos[2] + #13#10 + Candidatos[3]),
      'Controle de Vendas', MB_ICONERROR);
    Halt(1);
  end;
end;

// Corrige lancamentos gravados com datas fora da faixa valida (ex.: ano 0026),
// que fazem o Jet disparar "Procedimento de chamada invalido" nas consultas
// que usam Str()/Mid() sobre DataVencimento, e E_FAIL ao editar a tabela.
procedure TDM.CorrigirDatasInvalidas;
const
  FAIXA_VENC = '(DataVencimento < #01/01/1900# OR DataVencimento > #12/31/2200#)';
  FAIXA_LANC = '(DataLancamento < #01/01/1900# OR DataLancamento > #12/31/2200#)';
  OK_VENC = '(DataVencimento >= #01/01/1900# AND DataVencimento <= #12/31/2200#)';
  OK_LANC = '(DataLancamento >= #01/01/1900# AND DataLancamento <= #12/31/2200#)';
var
  nVenc, nLanc: Integer;
begin
  nVenc := 0;
  nLanc := 0;
  try
    ConexaoMDB.Execute('UPDATE Lancamentos SET DataVencimento = DataLancamento ' +
      'WHERE ' + FAIXA_VENC + ' AND ' + OK_LANC, nVenc);
    ConexaoMDB.Execute('UPDATE Lancamentos SET DataLancamento = DataVencimento ' +
      'WHERE ' + FAIXA_LANC + ' AND ' + OK_VENC, nLanc);
    if (nVenc > 0) or (nLanc > 0) then
      ShowMessage('Foram encontrados e corrigidos lancamentos com data invalida:' + #13#10 +
        'Vencimento corrigido: ' + IntToStr(nVenc) + #13#10 +
        'Data do lancamento corrigida: ' + IntToStr(nLanc) + #13#10 + #13#10 +
        'A data de vencimento foi igualada a data do lancamento. ' +
        'Revise esses registros se necessario.');
  except
    on E: Exception do
      ShowMessage('Nao foi possivel verificar datas invalidas:' + #13#10 + E.Message);
  end;
end;

procedure TDM.AbrirDS(DS: TDataSet);
begin
  try
    DS.Open;
  except
    on E: Exception do
      ShowMessage('Erro ao abrir "' + DS.Name + '":' + #13#10 + E.Message);
  end;
end;

procedure TDM.AbrirDataSets;
begin
  AbrirDS(tabConfiguracao);
  AbrirDS(tabProdutos);
  AbrirDS(tabClientesFornecedores);
  AbrirDS(tabTiposLancamentos);
  AbrirDS(tabLancamentos);
  AbrirDS(qyListagem);
  AbrirDS(tabUnidades);
  AbrirDS(tabParametros);
  AbrirDS(qyLancamentosPeriodo);
  AbrirDS(qyValoresPorPeriodo);
  AbrirDS(qySomatoriaTiposLancamento);
  AbrirDS(tabGraficoResultado);
  AbrirDS(qyGraficoResultado);
  AbrirDS(tabRelatorioResultado);
  AbrirDS(qyListagemCR);
  AbrirDS(tabPagamentos);
  AbrirDS(tabSimNao);
  AbrirDS(tabGrupos);
  AbrirDS(qyTiposParaCR);
  AbrirDS(qySaldoDinamico);
  AbrirDS(tabAuxVencimentos);
  AbrirDS(tabSomarDeduzir);
  AbrirDS(tabLogin);
  AbrirDS(qyQtdesPorPeriodo);
  AbrirDS(qyTreeComSaldos);
  AbrirDS(tabResultado);
  AbrirDS(qyResultado);
end;

procedure TDM.DataModuleCreate(Sender: TObject);
begin
  ConexaoMDB.Connected := False;
  ConexaoMDB.LoginPrompt := False;
  ConexaoMDB.ConnectionString :=
    'Provider=Microsoft.Jet.OLEDB.4.0;Data Source=' + LocalizarBanco +
    ';Mode=Share Deny None;Persist Security Info=False';
  try
    ConexaoMDB.Connected := True;
  except
    on E: Exception do
    begin
      Application.MessageBox(PChar('Nao foi possivel conectar ao banco de dados:' +
        #13#10 + E.Message), 'Controle de Vendas', MB_ICONERROR);
      Halt(1);
    end;
  end;
  CorrigirDatasInvalidas;
  AbrirDataSets;
end;

// Impede gravar datas fora da faixa valida (ex.: "10/11/26" -> ano 0026)
procedure TDM.tabLancamentosBeforePost(DataSet: TDataSet);
  procedure Checar(const sCampo, sRotulo: String);
  var
    F: TField;
  begin
    F := DataSet.FieldByName(sCampo);
    if (not F.IsNull) and
       ((F.AsDateTime < EncodeDate(DATA_MINIMA, 1, 1)) or
        (F.AsDateTime > EncodeDate(DATA_MAXIMA, 12, 31))) then
      raise Exception.Create('Data invalida no campo ' + sRotulo + '.' + #13#10 +
        'Informe o ano com 4 digitos (ex.: 10/11/2026).');
  end;
begin
  Checar('DataLancamento', 'DATA');
  Checar('DataVencimento', 'VENCIMENTO');
end;

procedure TDM.tabPagamentosBeforePost(DataSet: TDataSet);
begin

  DM.tabPagamentos.Edit;
  DM.tabPagamentos.FieldByName('IDDetalhe').Value := DM.qyListagemCR.FieldByName('IDDetalhe').Value;

end;

end.
