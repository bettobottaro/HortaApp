unit UDetalhes;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, Grids, DBGrids, DBCtrls, ExtCtrls, StdCtrls, Mask, JvExMask,
  JvToolEdit, JvMaskEdit, JvCheckedMaskEdit, JvDatePickerEdit,
  JvDBDatePickerEdit;

type
  TformDetalhes = class(TForm)
    DBGrid1: TDBGrid;
    DBGrid2: TDBGrid;
    Label1: TLabel;
    Label2: TLabel;
    Panel1: TPanel;
    DBText2: TDBText;
    DBText1: TDBText;
    DBText3: TDBText;
    Label3: TLabel;
    Label4: TLabel;
    Label5: TLabel;
    DBNavigator1: TDBNavigator;
    Label6: TLabel;
    DBText4: TDBText;
    campoData: TJvDBDatePickerEdit;
    DBEdit1: TDBEdit;
    Shape1: TShape;
    Label8: TLabel;
    Label9: TLabel;
    DBText6: TDBText;
    Label10: TLabel;
    DBText7: TDBText;
    Shape2: TShape;
    Label11: TLabel;
    DBText8: TDBText;
    Shape3: TShape;
    Label7: TLabel;
    DBText5: TDBText;
    Shape4: TShape;
    Label12: TLabel;
    DBText9: TDBText;
    Shape5: TShape;
    Timer1: TTimer;
    Label13: TLabel;
    DBText10: TDBText;
    procedure FormShow(Sender: TObject);
    procedure FormKeyPress(Sender: TObject; var Key: Char);
    procedure Timer1Timer(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  formDetalhes: TformDetalhes;

implementation

uses UDM;

{$R *.dfm}

procedure TformDetalhes.FormClose(Sender: TObject; var Action: TCloseAction);
begin

  Timer1.Enabled := false;

end;

procedure TformDetalhes.FormKeyPress(Sender: TObject; var Key: Char);
begin

  if Key = #13 then
  begin
    Key := #0;
    PostMessage(Handle, WM_NEXTDLGCTL, 0, 0);
  end;

end;

procedure TformDetalhes.FormShow(Sender: TObject);
begin

  DM.tabPagamentos.Filter := 'IDDetalhe = ' + QuotedStr(DM.qyListagemCR.FieldByName('IDDetalhe').Value);
  DM.tabPagamentos.Filtered := true;

  if (DM.tabPagamentos.RecordCount = 0) and (DM.qyListagemCRAVista.Value = 'Sim') then
  begin
    DM.tabPagamentos.Append;
    DM.tabPagamentos.FieldByName('DataPagamento').Value := DM.qyListagemCRDataVencimento.Value;
    DM.tabPagamentos.FieldByName('ValorPago').Value := DM.qyListagemCRValorTotal.Value;
    DM.tabPagamentos.FieldByName('IDDetalhe').Value := DM.qyListagemCRIDDetalhe.Value;
    DM.tabPagamentos.Post;
  end;

  Timer1.Enabled := true;

end;

procedure TformDetalhes.Timer1Timer(Sender: TObject);
begin

  DM.qySaldoDinamico.Close;
  DM.qySaldoDinamico.Open;
  DM.qySaldoDinamico.Filter := 'IDDetalhe = ' + QuotedStr(DM.qyListagemCR.FieldByName('IDDetalhe').value);
  DM.qySaldoDinamico.Filtered := true;

end;

end.
