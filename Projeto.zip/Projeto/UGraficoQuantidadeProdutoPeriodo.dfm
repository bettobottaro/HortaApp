object formGraficoQuantidadeProdutosPeriodo: TformGraficoQuantidadeProdutosPeriodo
  Left = 0
  Top = 0
  Caption = 'formGraficoQuantidadeProdutosPeriodo'
  ClientHeight = 518
  ClientWidth = 710
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object DBChart1: TDBChart
    Left = 0
    Top = 57
    Width = 710
    Height = 461
    Title.CustomPosition = True
    Title.Font.Height = -16
    Title.Left = 229
    Title.Text.Strings = (
      ' Quantidades de Produtos por Per'#237'odo')
    Title.Top = 40
    Legend.LegendStyle = lsValues
    Legend.TextStyle = ltsPercent
    View3DOptions.Elevation = 315
    View3DOptions.Orthogonal = False
    View3DOptions.Perspective = 0
    View3DOptions.Rotation = 360
    Align = alClient
    TabOrder = 0
    ExplicitTop = 48
    ExplicitWidth = 713
    ExplicitHeight = 473
    object Series1: TPieSeries
      Marks.Arrow.Visible = True
      Marks.Callout.Brush.Color = clBlack
      Marks.Callout.Arrow.Visible = True
      Marks.Visible = True
      DataSource = DM.qyQtdesPorPeriodo
      Title = 'Gr'#225'fico Anal'#237'tico'
      XLabelsSource = 'Descricao'
      Gradient.Direction = gdRadial
      OtherSlice.Legend.Visible = False
      PieValues.Name = 'Pie'
      PieValues.Order = loNone
      PieValues.ValueSource = 'QtdeTotal'
    end
  end
  object Panel1: TPanel
    Left = 0
    Top = 0
    Width = 710
    Height = 57
    Align = alTop
    TabOrder = 1
    ExplicitWidth = 775
  end
end
