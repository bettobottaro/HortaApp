unit ULancamentos;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, Grids, DBGrids, ExtCtrls, StdCtrls, DBCtrls, Buttons, JvExControls,
  JvxSlider, DB;

type
  TformLancamentos = class(TForm)
    Painel1: TPanel;
    Grade1: TDBGrid;
    filtroClienteFornecedor: TEdit;
    Label1: TLabel;
    Label2: TLabel;
    filtroProduto: TEdit;
    Label3: TLabel;
    filtroTipo: TEdit;
    GroupBox1: TGroupBox;
    Painel2: TPanel;
    Label6: TLabel;
    Panel2: TPanel;
    SpeedButton2: TSpeedButton;
    SpeedButton1: TSpeedButton;
    SpeedButton3: TSpeedButton;
    SpeedButton4: TSpeedButton;
    Label4: TLabel;
    slider1: TJvxSlider;
    etiquetaFonte: TLabel;
    Shape1: TShape;
    procedure FormShow(Sender: TObject);
    procedure filtroClienteFornecedorChange(Sender: TObject);
    procedure Filtros;
    procedure filtroProdutoChange(Sender: TObject);
    procedure filtroTipoChange(Sender: TObject);
    procedure SpeedButton2Click(Sender: TObject);
    procedure Grade1DblClick(Sender: TObject);
    procedure SpeedButton1Click(Sender: TObject);
    procedure SpeedButton3Click(Sender: TObject);
    procedure SpeedButton4Click(Sender: TObject);
    procedure Grade1TitleClick(Column: TColumn);
    procedure slider1Change(Sender: TObject);
    procedure Grade1DrawColumnCell(Sender: TObject; const Rect: TRect;
      DataCol: Integer; Column: TColumn; State: TGridDrawState);
    procedure FormKeyPress(Sender: TObject; var Key: Char);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  formLancamentos: TformLancamentos;
  Ascendente: Boolean;

implementation

uses UDM, UInclusaoLancamentos, UAlteracaoLancamentos;

{$R *.dfm}



procedure   TformLancamentos.filtroProdutoChange(Sender: TObject);
begin

  Filtros;

end;

procedure   TformLancamentos.Filtros;
begin


  if (filtroClienteFornecedor.Text <> '') or (filtroProduto.Text <> '') or (filtroTipo.Text <> '') then
  begin


    // CLIENTE/FORNECEDOR E PRODUTO
    if (filtroClienteFornecedor.Text <> '') and (filtroProduto.Text <> '') and (filtroTipo.Text = '') then
    begin
      DM.qyListagem.Filter := 'Nome like ' + QuotedStr('%' + filtroClienteFornecedor.text + '%') + ' and Produto like ' + QuotedStr('%' + filtroProduto.text + '%');
      DM.qyListagem.Filtered := True;
    end;

    // CLIENTE/FORNECEDOR E TIPO
    if (filtroClienteFornecedor.Text <> '') and (filtroTipo.Text <> '') and (filtroProduto.Text = '') then
    begin
      DM.qyListagem.Filter := 'Nome like ' + QuotedStr('%' + filtroClienteFornecedor.text + '%') + ' and Tipo like ' + QuotedStr('%' + filtroTipo.text + '%');
      DM.qyListagem.Filtered := True;
    end;

    // PRODUTO E TIPO
    if (filtroProduto.Text <> '') and (filtroTipo.Text <> '') and (filtroClienteFornecedor.Text = '') then
    begin
      DM.qyListagem.Filter := 'Produto like ' + QuotedStr('%' + filtroProduto.text + '%') + ' and Tipo like ' + QuotedStr('%' + filtroTipo.text + '%');
      DM.qyListagem.Filtered := True;
    end;

    // CLIENTE/FORNECEDOR, PRODUTO E TIPO
    if (filtroClienteFornecedor.Text <> '') and (filtroProduto.Text <> '') and (filtroTipo.Text <> '') then
    begin
      DM.qyListagem.Filter := 'Nome like ' + QuotedStr('%' + filtroClienteFornecedor.text + '%') + ' and Produto like ' + QuotedStr('%' + filtroProduto.text + '%') + ' and Tipo like ' + QuotedStr('%' + filtroTipo.text + '%'); ;
      DM.qyListagem.Filtered := True;
    end;

    // APENAS CLIENTE/FORNECEDOR
    if (filtroClienteFornecedor.Text <> '') and (filtroProduto.Text = '') and (filtroTipo.Text = '') then
    begin
      DM.qyListagem.Filter := 'Nome like ' + QuotedStr('%' + filtroClienteFornecedor.text + '%');
      DM.qyListagem.Filtered := True;
    end;

    // APENAS PRODUTO
    if (filtroClienteFornecedor.Text = '') and (filtroProduto.Text <> '') and (filtroTipo.Text = '') then
    begin
      DM.qyListagem.Filter := 'Produto like ' + QuotedStr('%' + filtroProduto.text + '%');
      DM.qyListagem.Filtered := True;
    end;

    // APENAS TIPO
    if (filtroClienteFornecedor.Text = '') and (filtroProduto.Text = '') and (filtroTipo.Text <> '') then
    begin
      DM.qyListagem.Filter := 'Tipo like ' + QuotedStr('%' + filtroTipo.text + '%');
      DM.qyListagem.Filtered := True;
    end;

  end
  else
  begin
    DM.qyListagem.Filtered := False;
  end;

  // Recontagem de registros
  Painel2.Caption := IntToStr(DM.qyListagem.RecordCount) + ' registro(s)';


end;



procedure TformLancamentos.filtroTipoChange(Sender: TObject);
begin

  Filtros;

end;

procedure TformLancamentos.Grade1DblClick(Sender: TObject);
var
  Marcador : TBookMark;

begin


  if DM.qylistagem.RecordCount = 0 then
  begin
    Abort;
  end;


  Marcador := DM.qyListagem.GetBookmark;

  DM.tabLancamentos.Filter := 'IDLancamento = ' + QuotedStr(DM.qyListagem.FieldByName('IDLancamento').Value);
  DM.tabLancamentos.Filtered := true;

  DM.tabLancamentos.Edit;
  formAlteracaoLancamentos.ShowModal;

  DM.tabLancamentos.Filtered := false;

  DM.qyListagem.Close;
  DM.qyListagem.Open;

  // Recontagem de registros
  Painel2.Caption := IntToStr(DM.qyListagem.RecordCount) + ' registro(s)';

  if DM.qyListagem.BookmarkValid(Marcador) then
  begin
    DM.qyListagem.GotoBookmark(Marcador);
  end;

end;

procedure TformLancamentos.Grade1DrawColumnCell(Sender: TObject;
  const Rect: TRect; DataCol: Integer; Column: TColumn; State: TGridDrawState);
begin


  if odd(DM.qyListagem.RecNo) then
    Grade1.Canvas.Brush.Color:= $00DDDDDD    //clLtGray
  else
    Grade1.Canvas.Brush.Color:= clCream;

  TDbGrid(Sender).Canvas.font.Color:= clBlack;
    if gdSelected in State then
      with (Sender as TDBGrid).Canvas do
        begin
          Brush.Color := $003EB56D;
          FillRect(Rect);
          //Font.Style := [fsbold]
        end;

  TDbGrid(Sender).DefaultDrawDataCell(Rect, TDbGrid(Sender).columns[datacol].field, State);



end;

procedure TformLancamentos.Grade1TitleClick(Column: TColumn);
begin

  Ascendente:= not Ascendente ;

  if Ascendente then
    DM.qyListagem.Sort := Column.FieldName + ' ASC'
  else
    DM.qyListagem.Sort := Column.FieldName + ' DESC';

end;

procedure TformLancamentos.slider1Change(Sender: TObject);
begin

  Grade1.Font.Size := slider1.Value;
  etiquetaFonte.Caption := 'fonte: ' + IntToStr(slider1.Value);

end;

procedure TformLancamentos.filtroClienteFornecedorChange(Sender: TObject);
begin

  Filtros;

end;

procedure TformLancamentos.FormKeyPress(Sender: TObject; var Key: Char);
begin

  if Key = #13 then
  begin
    Key := #0;
    PostMessage(Handle, WM_NEXTDLGCTL, 0, 0);
  end;

end;

procedure TformLancamentos.FormShow(Sender: TObject);
begin

  DM.qyListagem.Close;
  DM.qyListagem.open;
  DM.qyListagem.Filtered := false;
  filtroClienteFornecedor.Text := '';
  filtroProduto.Text := '';
  filtroTipo.Text := '';

  Painel2.Caption := IntToStr(DM.qyListagem.RecordCount) + ' registro(s)';
  etiquetaFonte.Caption := 'fonte: ' + IntToStr(slider1.Value);

  filtroClienteFornecedor.SetFocus;


end;

procedure TformLancamentos.SpeedButton1Click(Sender: TObject);
begin

  filtroClienteFornecedor.Text := '';
  filtroClienteFornecedor.SetFocus;

end;

procedure TformLancamentos.SpeedButton2Click(Sender: TObject);
begin

  DM.tabLancamentos.Append;
  formInclusaoLancamentos.ShowModal;

  DM.qyListagem.Close;
  DM.qyListagem.Open;

  // Recontagem de registros
  Painel2.Caption := IntToStr(DM.qyListagem.RecordCount) + ' registro(s)';

end;

procedure TformLancamentos.SpeedButton3Click(Sender: TObject);
begin

  filtroProduto.Text := '';
  filtroProduto.SetFocus;

end;

procedure TformLancamentos.SpeedButton4Click(Sender: TObject);
begin

  filtroTipo.Text := '';
  filtroTipo.SetFocus;


end;



end.
