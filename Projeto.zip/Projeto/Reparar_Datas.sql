-- Reparo manual (caso queira corrigir o banco SEM recompilar o programa).
-- Abra BD\Dados.MDB no Microsoft Access, crie uma consulta em modo SQL,
-- cole e execute UMA instrucao por vez. FACA BACKUP DO .MDB ANTES.

-- 1) Lancamento com vencimento no ano 0026 (causa do erro):
UPDATE Lancamentos SET DataVencimento = DataLancamento WHERE IDLancamento = 18096;

-- 2) Versao geral (qualquer vencimento fora de 1900-2200):
UPDATE Lancamentos SET DataVencimento = DataLancamento
WHERE (DataVencimento < #01/01/1900# OR DataVencimento > #12/31/2200#)
  AND DataLancamento >= #01/01/1900# AND DataLancamento <= #12/31/2200#;

-- 3) Depois: Ferramentas de Banco de Dados > Compactar e reparar banco de dados.
