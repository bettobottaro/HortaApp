object DMLanc: TDMLanc
  OldCreateOrder = False
  Height = 641
  Width = 669
  object cnnMDB: TADOConnection
    Connected = True
    ConnectionString = 
      'Provider=Microsoft.Jet.OLEDB.4.0;User ID=Admin;Data Source=C:\Pl' +
      'anilhaVendas\ControleContasReceber\BD\Dados.MDB;Mode=Share Deny ' +
      'None;Persist Security Info=False;Jet OLEDB:System database="";Je' +
      't OLEDB:Registry Path="";Jet OLEDB:Database Password="";Jet OLED' +
      'B:Engine Type=5;Jet OLEDB:Database Locking Mode=1;Jet OLEDB:Glob' +
      'al Partial Bulk Ops=2;Jet OLEDB:Global Bulk Transactions=1;Jet O' +
      'LEDB:New Database Password="";Jet OLEDB:Create System Database=F' +
      'alse;Jet OLEDB:Encrypt Database=False;Jet OLEDB:Don'#39't Copy Local' +
      'e on Compact=False;Jet OLEDB:Compact Without Replica Repair=Fals' +
      'e;Jet OLEDB:SFP=False'
    LoginPrompt = False
    Mode = cmShareDenyNone
    Provider = 'Microsoft.Jet.OLEDB.4.0'
    Left = 328
    Top = 8
  end
  object tabGrupos: TADOTable
    Active = True
    Connection = cnnMDB
    CursorType = ctStatic
    TableName = 'tabGrupos'
    Left = 80
    Top = 88
    object tabGruposIDGrupo: TAutoIncField
      FieldName = 'IDGrupo'
      ReadOnly = True
    end
    object tabGruposGrupo_descricao: TWideStringField
      FieldName = 'Grupo_descricao'
      Size = 50
    end
    object tabGruposGrupo_ordem: TIntegerField
      FieldName = 'Grupo_ordem'
    end
  end
  object dsGrupos: TDataSource
    DataSet = tabGrupos
    Left = 80
    Top = 152
  end
  object tabProdutos: TADOTable
    Active = True
    Connection = cnnMDB
    CursorType = ctStatic
    TableName = 'tabProdutos'
    Left = 160
    Top = 88
    object tabProdutosIDProduto: TAutoIncField
      FieldName = 'IDProduto'
      ReadOnly = True
    end
    object tabProdutosProduto_descricao: TWideStringField
      FieldName = 'Produto_descricao'
      Size = 100
    end
    object tabProdutosProduto_unidade: TWideStringField
      FieldName = 'Produto_unidade'
    end
    object tabProdutosProduto_valorunitario: TBCDField
      FieldName = 'Produto_valorunitario'
      DisplayFormat = '###,###,##0.00'
      EditFormat = '###,###,##0.00'
      Precision = 19
    end
    object tabProdutosProduto_IDGrupo: TIntegerField
      FieldName = 'Produto_IDGrupo'
    end
    object tabProdutosProduto_obs: TWideStringField
      FieldName = 'Produto_obs'
      Size = 250
    end
  end
  object dsProdutos: TDataSource
    DataSet = tabProdutos
    Left = 160
    Top = 152
  end
  object tabClientes: TADOTable
    Active = True
    Connection = cnnMDB
    CursorType = ctStatic
    TableName = 'tabClientes'
    Left = 240
    Top = 88
    object tabClientesIDCliente: TAutoIncField
      FieldName = 'IDCliente'
      ReadOnly = True
    end
    object tabClientesCliente_nome: TWideStringField
      FieldName = 'Cliente_nome'
      Size = 100
    end
    object tabClientesCliente_endereco: TWideStringField
      FieldName = 'Cliente_endereco'
      Size = 100
    end
    object tabClientesCliente_cidade: TWideStringField
      FieldName = 'Cliente_cidade'
      Size = 50
    end
    object tabClientesCliente_UF: TWideStringField
      FieldName = 'Cliente_UF'
      Size = 2
    end
    object tabClientesCliente_telefone: TWideStringField
      FieldName = 'Cliente_telefone'
    end
    object tabClientesCliente_email: TWideStringField
      FieldName = 'Cliente_email'
      Size = 50
    end
    object tabClientesCliente_obs: TWideStringField
      FieldName = 'Cliente_obs'
      Size = 255
    end
  end
  object dsClientes: TDataSource
    DataSet = tabClientes
    Left = 240
    Top = 152
  end
  object tabLancamentos: TADOTable
    Active = True
    Connection = cnnMDB
    CursorType = ctStatic
    TableName = 'tabLancamentos'
    Left = 320
    Top = 88
    object tabLancamentosIDLancamento: TAutoIncField
      Alignment = taCenter
      FieldName = 'IDLancamento'
      ReadOnly = True
    end
    object tabLancamentosLanc_data: TDateTimeField
      FieldName = 'Lanc_data'
    end
    object tabLancamentosLanc_IDProduto: TIntegerField
      FieldName = 'Lanc_IDProduto'
    end
    object tabLancamentosLanc_IDCliente: TIntegerField
      FieldName = 'Lanc_IDCliente'
    end
    object tabLancamentosLanc_qtde: TFloatField
      FieldName = 'Lanc_qtde'
    end
    object tabLancamentosLanc_valorunitario: TBCDField
      FieldName = 'Lanc_valorunitario'
      DisplayFormat = '###,###,##0.00'
      Precision = 19
    end
    object tabLancamentosLanc_valortotal: TBCDField
      FieldName = 'Lanc_valortotal'
      DisplayFormat = '###,###,##0.00'
      Precision = 19
    end
    object tabLancamentosLanc_obs: TWideStringField
      FieldName = 'Lanc_obs'
      Size = 255
    end
    object tabLancamentosLanc_vencimento: TDateTimeField
      FieldName = 'Lanc_vencimento'
    end
    object tabLancamentosLanc_datapagamento: TDateTimeField
      FieldName = 'Lanc_datapagamento'
    end
    object tabLancamentosLanc_valorpago: TBCDField
      FieldName = 'Lanc_valorpago'
      DisplayFormat = '###,###,##0.00'
      Precision = 19
    end
    object tabLancamentosLanc_tipo: TWideStringField
      FieldName = 'Lanc_tipo'
    end
  end
  object dsLancamentos: TDataSource
    DataSet = tabLancamentos
    Left = 320
    Top = 152
  end
  object qyLanc_listagem: TADOQuery
    Active = True
    Connection = cnnMDB
    CursorType = ctStatic
    Parameters = <>
    SQL.Strings = (
      ''
      'Select'
      '    tabLancamentos.[Lanc_vencimento],'
      '    tabGrupos.[Grupo_descricao],'
      '    tabClientes.[Cliente_nome],'
      '    tabClientes.[Cliente_cidade],'
      '    tabClientes.[Cliente_UF],'
      '    tabLancamentos.[Lanc_data],'
      
        '    IIF(Date() - tabLancamentos.[Lanc_vencimento] > 0, Format('#39'0' +
        '000'#39', Date() - tabLancamentos.[Lanc_vencimento]),'
      '    '#39#39') As Dias,'
      '    tabProdutos.[Produto_descricao],'
      '    tabLancamentos.[Lanc_qtde],'
      '    tabLancamentos.[Lanc_valorunitario],'
      '    tabLancamentos.[Lanc_valortotal],'
      '    tabLancamentos.[Lanc_datapagamento],'
      '    tabLancamentos.[Lanc_valorpago],'
      '    tabLancamentos.IDLancamento,'
      
        '    tabLancamentos.[Lanc_valortotal] - IIF(tabLancamentos.[Lanc_' +
        'valorpago] > 0, tabLancamentos.[Lanc_valorpago],'
      '    0) As Saldo,'
      '    tabLancamentos.[Lanc_tipo]'
      'From'
      '    ((tabLancamentos Inner Join'
      
        '    tabProdutos On tabProdutos.IDProduto = tabLancamentos.[Lanc_' +
        'IDProduto]) Inner Join'
      
        '    tabGrupos On tabGrupos.IDGrupo = tabProdutos.[Produto_IDGrup' +
        'o]) Inner Join'
      
        '    tabClientes On tabClientes.IDCliente = tabLancamentos.[Lanc_' +
        'IDCliente]'
      'Order By'
      '    tabLancamentos.[Lanc_vencimento] Desc,'
      '    tabClientes.[Cliente_nome]')
    Left = 80
    Top = 280
    object qyLanc_listagemGrupo_descricao: TWideStringField
      FieldName = 'Grupo_descricao'
      Size = 50
    end
    object qyLanc_listagemCliente_nome: TWideStringField
      FieldName = 'Cliente_nome'
      Size = 100
    end
    object qyLanc_listagemCliente_cidade: TWideStringField
      FieldName = 'Cliente_cidade'
      Size = 50
    end
    object qyLanc_listagemCliente_UF: TWideStringField
      Alignment = taCenter
      FieldName = 'Cliente_UF'
      Size = 2
    end
    object qyLanc_listagemLanc_data: TDateTimeField
      Alignment = taCenter
      FieldName = 'Lanc_data'
      DisplayFormat = 'dd/mm/yy'
    end
    object qyLanc_listagemLanc_vencimento: TDateTimeField
      Alignment = taCenter
      FieldName = 'Lanc_vencimento'
      DisplayFormat = 'dd/mm/yy'
    end
    object qyLanc_listagemProduto_descricao: TWideStringField
      FieldName = 'Produto_descricao'
      Size = 100
    end
    object qyLanc_listagemLanc_qtde: TFloatField
      Alignment = taCenter
      FieldName = 'Lanc_qtde'
    end
    object qyLanc_listagemLanc_valorunitario: TBCDField
      FieldName = 'Lanc_valorunitario'
      DisplayFormat = '###,###,#0.00'
      Precision = 19
    end
    object qyLanc_listagemLanc_valortotal: TBCDField
      FieldName = 'Lanc_valortotal'
      DisplayFormat = '###,###,#0.00'
      Precision = 19
    end
    object qyLanc_listagemDias: TWideStringField
      Alignment = taCenter
      FieldName = 'Dias'
      ReadOnly = True
      Size = 255
    end
    object qyLanc_listagemLanc_datapagamento: TDateTimeField
      Alignment = taCenter
      FieldName = 'Lanc_datapagamento'
      DisplayFormat = 'dd/mm/yy'
    end
    object qyLanc_listagemLanc_valorpago: TBCDField
      FieldName = 'Lanc_valorpago'
      DisplayFormat = '###,###,#0.00'
      Precision = 19
    end
    object qyLanc_listagemIDLancamento: TAutoIncField
      FieldName = 'IDLancamento'
      ReadOnly = True
    end
    object qyLanc_listagemSaldo: TBCDField
      FieldName = 'Saldo'
      ReadOnly = True
      DisplayFormat = '###,###,#0.00'
      Precision = 19
    end
    object qyLanc_listagemLanc_tipo: TWideStringField
      FieldName = 'Lanc_tipo'
    end
  end
  object dsqyLanc_listagem: TDataSource
    DataSet = qyLanc_listagem
    Left = 80
    Top = 336
  end
  object qyClientes_lista: TADOQuery
    Active = True
    Connection = cnnMDB
    CursorType = ctStatic
    Parameters = <>
    SQL.Strings = (
      'Select'
      '    tabClientes.[Cliente_nome],'
      '    tabClientes.IDCliente'
      'From'
      '    tabClientes'
      'Order By'
      '    tabClientes.[Cliente_nome]')
    Left = 200
    Top = 280
    object qyClientes_listaCliente_nome: TWideStringField
      FieldName = 'Cliente_nome'
      Size = 100
    end
    object qyClientes_listaIDCliente: TAutoIncField
      FieldName = 'IDCliente'
      ReadOnly = True
    end
  end
  object dsqyClientes_lista: TDataSource
    DataSet = qyClientes_lista
    Left = 200
    Top = 336
  end
  object qyProdutos_lista: TADOQuery
    Active = True
    Connection = cnnMDB
    CursorType = ctStatic
    OnCalcFields = qyProdutos_listaCalcFields
    Parameters = <>
    SQL.Strings = (
      'Select'
      '    tabProdutos.[Produto_descricao],'
      '    tabProdutos.[Produto_unidade],'
      '    tabProdutos.IDProduto'
      'From'
      '    tabProdutos'
      'Order By'
      '    tabProdutos.[Produto_descricao]')
    Left = 304
    Top = 280
    object qyProdutos_listaProduto_descricao: TWideStringField
      FieldName = 'Produto_descricao'
      Size = 100
    end
    object qyProdutos_listaIDProduto: TAutoIncField
      FieldName = 'IDProduto'
      ReadOnly = True
    end
    object qyProdutos_listaProduto_unidade: TWideStringField
      FieldName = 'Produto_unidade'
    end
    object qyProdutos_listaConcatenacao: TStringField
      FieldKind = fkCalculated
      FieldName = 'Concatenacao'
      Size = 100
      Calculated = True
    end
  end
  object dsqyProdutos_lista: TDataSource
    DataSet = qyProdutos_lista
    Left = 304
    Top = 336
  end
  object qyGrupos_lista: TADOQuery
    Active = True
    Connection = cnnMDB
    CursorType = ctStatic
    Parameters = <>
    SQL.Strings = (
      'Select'
      '    tabGrupos.IDGrupo,'
      '    tabGrupos.[Grupo_descricao]'
      'From'
      '    tabGrupos'
      'Order By'
      '    tabGrupos.[Grupo_descricao]')
    Left = 416
    Top = 280
  end
  object dsqyGrupos_lista: TDataSource
    DataSet = qyGrupos_lista
    Left = 416
    Top = 336
  end
  object tabParametros: TADOTable
    Active = True
    Connection = cnnMDB
    CursorType = ctStatic
    TableName = 'tabParametros'
    Left = 408
    Top = 88
    object tabParametrosID: TAutoIncField
      FieldName = 'ID'
      ReadOnly = True
    end
    object tabParametrosParam_DataInicial: TDateTimeField
      FieldName = 'Param_DataInicial'
    end
    object tabParametrosParam_DataFinal: TDateTimeField
      FieldName = 'Param_DataFinal'
    end
    object tabParametrosParam_Tipo: TWideStringField
      FieldName = 'Param_Tipo'
    end
    object tabParametrosParam_Grupo: TIntegerField
      FieldName = 'Param_Grupo'
    end
  end
  object dsParametros: TDataSource
    DataSet = tabParametros
    Left = 408
    Top = 152
  end
  object qyVencimentosPorPeriodo: TADOQuery
    Active = True
    Connection = cnnMDB
    CursorType = ctStatic
    Parameters = <>
    SQL.Strings = (
      'Select'
      '    [Lanc_listagem].[Lanc_vencimento],'
      '    [Lanc_listagem].[Grupo_descricao],'
      '    [Lanc_listagem].[Cliente_nome],'
      '    [Lanc_listagem].[Cliente_cidade],'
      '    [Lanc_listagem].[Cliente_UF],'
      '    [Lanc_listagem].[Lanc_data],'
      '    [Lanc_listagem].Dias,'
      '    [Lanc_listagem].[Produto_descricao],'
      '    [Lanc_listagem].[Lanc_qtde],'
      '    [Lanc_listagem].[Lanc_valorunitario],'
      '    [Lanc_listagem].[Lanc_valortotal],'
      '    [Lanc_listagem].[Lanc_datapagamento],'
      '    [Lanc_listagem].[Lanc_valorpago],'
      '    [Lanc_listagem].IDLancamento,'
      '    [Lanc_listagem].Saldo,'
      '    [Lanc_listagem].[Lanc_tipo],'
      '    tabParametros.[Param_DataInicial],'
      '    tabParametros.[Param_DataFinal],'
      '    [Lanc_listagem].IDGrupo,'
      '    tabParametros.[Param_Grupo],'
      '    [Lanc_listagem].[Produto_unidade]'
      'From'
      '    (Select'
      '         tabLancamentos.[Lanc_vencimento],'
      '         tabGrupos.[Grupo_descricao],'
      '         tabClientes.[Cliente_nome],'
      '         tabClientes.[Cliente_cidade],'
      '         tabClientes.[Cliente_UF],'
      '         tabLancamentos.[Lanc_data],'
      
        '         IIF(Date() - tabLancamentos.[Lanc_vencimento] > 0, Form' +
        'at('#39'0000'#39', Date() - tabLancamentos.[Lanc_vencimento]),'
      '         '#39#39') As Dias,'
      '         tabProdutos.[Produto_descricao],'
      '         tabLancamentos.[Lanc_qtde],'
      '         tabLancamentos.[Lanc_valorunitario],'
      '         tabLancamentos.[Lanc_valortotal],'
      '         tabLancamentos.[Lanc_datapagamento],'
      '         tabLancamentos.[Lanc_valorpago],'
      '         tabLancamentos.IDLancamento,'
      
        '         tabLancamentos.[Lanc_valortotal] - IIF(tabLancamentos.[' +
        'Lanc_valorpago] > 0, tabLancamentos.[Lanc_valorpago],'
      '         0) As Saldo,'
      '         tabLancamentos.[Lanc_tipo],'
      '         tabGrupos.IDGrupo,'
      '         tabProdutos.[Produto_unidade]'
      '     From'
      '         ((tabLancamentos Inner Join'
      
        '         tabProdutos On tabProdutos.IDProduto = tabLancamentos.[' +
        'Lanc_IDProduto]) Inner Join'
      
        '         tabGrupos On tabGrupos.IDGrupo = tabProdutos.[Produto_I' +
        'DGrupo]) Inner Join'
      
        '         tabClientes On tabClientes.IDCliente = tabLancamentos.[' +
        'Lanc_IDCliente]'
      '     Order By'
      '         tabLancamentos.[Lanc_vencimento] Desc,'
      '         tabClientes.[Cliente_nome]) [Lanc_listagem] Inner Join'
      
        '    tabParametros On tabParametros.[Param_Tipo] = [Lanc_listagem' +
        '].[Lanc_tipo]'
      
        '            And tabParametros.[Param_Grupo] = [Lanc_listagem].ID' +
        'Grupo'
      'Where'
      
        '    [Lanc_listagem].[Lanc_vencimento] >= tabParametros.[Param_Da' +
        'taInicial] And'
      
        '    [Lanc_listagem].[Lanc_vencimento] <= tabParametros.[Param_Da' +
        'taFinal]')
    Left = 536
    Top = 280
    object WideStringField1: TWideStringField
      FieldName = 'Grupo_descricao'
      Size = 50
    end
    object WideStringField2: TWideStringField
      FieldName = 'Cliente_nome'
      Size = 100
    end
    object WideStringField3: TWideStringField
      FieldName = 'Cliente_cidade'
      Size = 50
    end
    object WideStringField4: TWideStringField
      Alignment = taCenter
      FieldName = 'Cliente_UF'
      Size = 2
    end
    object DateTimeField1: TDateTimeField
      Alignment = taCenter
      FieldName = 'Lanc_data'
      DisplayFormat = 'dd/mm/yy'
    end
    object DateTimeField2: TDateTimeField
      Alignment = taCenter
      FieldName = 'Lanc_vencimento'
      DisplayFormat = 'dd/mm/yy'
    end
    object WideStringField5: TWideStringField
      FieldName = 'Produto_descricao'
      Size = 100
    end
    object FloatField1: TFloatField
      Alignment = taCenter
      FieldName = 'Lanc_qtde'
    end
    object BCDField1: TBCDField
      FieldName = 'Lanc_valorunitario'
      DisplayFormat = '###,###,#0.00'
      Precision = 19
    end
    object BCDField2: TBCDField
      FieldName = 'Lanc_valortotal'
      DisplayFormat = '###,###,#0.00'
      Precision = 19
    end
    object WideStringField6: TWideStringField
      Alignment = taCenter
      FieldName = 'Dias'
      ReadOnly = True
      Size = 255
    end
    object DateTimeField3: TDateTimeField
      Alignment = taCenter
      FieldName = 'Lanc_datapagamento'
      DisplayFormat = 'dd/mm/yy'
    end
    object BCDField3: TBCDField
      FieldName = 'Lanc_valorpago'
      DisplayFormat = '###,###,#0.00'
      Precision = 19
    end
    object AutoIncField1: TAutoIncField
      FieldName = 'IDLancamento'
      ReadOnly = True
    end
    object BCDField4: TBCDField
      FieldName = 'Saldo'
      ReadOnly = True
      DisplayFormat = '###,###,#0.00'
      Precision = 19
    end
    object WideStringField7: TWideStringField
      FieldName = 'Lanc_tipo'
    end
    object qyVencimentosPorPeriodoParam_DataInicial: TDateTimeField
      FieldName = 'Param_DataInicial'
    end
    object qyVencimentosPorPeriodoParam_DataFinal: TDateTimeField
      FieldName = 'Param_DataFinal'
    end
    object qyVencimentosPorPeriodoIDGrupo: TAutoIncField
      FieldName = 'IDGrupo'
      ReadOnly = True
    end
    object qyVencimentosPorPeriodoParam_Grupo: TIntegerField
      FieldName = 'Param_Grupo'
    end
    object qyVencimentosPorPeriodoProduto_unidade: TWideStringField
      FieldName = 'Produto_unidade'
    end
  end
  object dsqyVencimentosPorPeriodo: TDataSource
    DataSet = qyVencimentosPorPeriodo
    Left = 536
    Top = 336
  end
  object tabPagamentos: TADOTable
    Active = True
    Connection = cnnMDB
    CursorType = ctStatic
    BeforePost = tabPagamentosBeforePost
    TableName = 'tabPagamentos'
    Left = 496
    Top = 88
    object tabPagamentosIDPagamento: TAutoIncField
      FieldName = 'IDPagamento'
      ReadOnly = True
    end
    object tabPagamentosPag_IDLanc: TIntegerField
      FieldName = 'Pag_IDLanc'
    end
    object tabPagamentosDataPagamento: TDateTimeField
      FieldName = 'DataPagamento'
      DisplayFormat = 'dd/mm/yy'
      EditMask = '!99/99/00;1;_'
    end
    object tabPagamentosValorPago: TBCDField
      FieldName = 'ValorPago'
      DisplayFormat = '###,###,##0.00'
      Precision = 19
    end
    object tabPagamentosExcluir: TStringField
      FieldKind = fkCalculated
      FieldName = 'Excluir'
      Calculated = True
    end
  end
  object dsPagamentos: TDataSource
    DataSet = tabPagamentos
    Left = 496
    Top = 152
  end
  object qySomatoriaPagamentos: TADOQuery
    Active = True
    Connection = cnnMDB
    CursorType = ctStatic
    Parameters = <>
    SQL.Strings = (
      'Select'
      '    tabPagamentos.[Pag_IDLanc],'
      '    Sum(tabPagamentos.ValorPago) As TotalPago'
      'From'
      '    tabPagamentos'
      'Group By'
      '    tabPagamentos.[Pag_IDLanc]')
    Left = 80
    Top = 416
  end
  object dsqySomatoriaPagamentos: TDataSource
    DataSet = qySomatoriaPagamentos
    Left = 80
    Top = 472
  end
end
