unit UResultado;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, Grids, DBGrids, StdCtrls, Buttons;

type
  TfrmResultado = class(TForm)
    DBGrid1: TDBGrid;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    edtCreditos: TEdit;
    edtDebitos: TEdit;
    edtResultado: TEdit;
    btDiferentes: TSpeedButton;
    procedure FormShow(Sender: TObject);
    procedure btDiferentesClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmResultado: TfrmResultado;

implementation

uses UDM, UListagemVencimento;

{$R *.dfm}

procedure TfrmResultado.FormShow(Sender: TObject);
begin

  edtCreditos.Text := FormatFloat('###,###,##0.00', formListagemVencimento.TotalCreditos);
  edtDebitos.Text := FormatFloat('###,###,##0.00', formListagemVencimento.TotalDebitos);
  edtResultado.Text := FormatFloat('###,###,##0.00', formListagemVencimento.Resultado);


end;

procedure TfrmResultado.btDiferentesClick(Sender: TObject);
begin

  if btDiferentes.Caption = 'mostrar diferentes' then
  begin
    DM.tabResultado.Filter := 'Diferente = ' + QuotedStr('Sim');
    DM.tabResultado.Filtered := true;
    btDiferentes.Caption := 'mostrar tudo';
  end
  else
  begin
    DM.tabResultado.Filtered := false;
    btDiferentes.Caption := 'mostrar diferentes';
  end;

end;

end.
