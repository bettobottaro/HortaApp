unit UPrincipal;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, ExtCtrls, Buttons, jpeg, Menus, ImgList, sSkinManager, sSkinProvider,
  acPNG;

type
  TformPrincipal = class(TForm)
    pnlBotoes: TPanel;
    SpeedButton1: TSpeedButton;
    SpeedButton2: TSpeedButton;
    pnlInferior: TPanel;
    Timer1: TTimer;
    imgFundo: TImage;
    SpeedButton3: TSpeedButton;
    MainMenu1: TMainMenu;
    Lanamentos1: TMenuItem;
    CADASTROS1: TMenuItem;
    RELATRIOS1: TMenuItem;
    Produtos1: TMenuItem;
    Clientes1: TMenuItem;
    iposdelanamentos1: TMenuItem;
    Unidades1: TMenuItem;
    CONFIGURAES1: TMenuItem;
    Lanamentosporperodo1: TMenuItem;
    ImageList1: TImageList;
    SpeedButton4: TSpeedButton;
    Image1: TImage;
    SpeedButton5: TSpeedButton;
    SpeedButton6: TSpeedButton;
    PopupMenuOpEspeciais: TPopupMenu;
    N1: TMenuItem;
    DatacompravendaDatavencimento1: TMenuItem;
    pnlCentral: TPanel;
    procedure Timer1Timer(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure SpeedButton1Click(Sender: TObject);
    procedure Lanamentos1Click(Sender: TObject);
    procedure Produtos1Click(Sender: TObject);
    procedure Clientes1Click(Sender: TObject);
    procedure SpeedButton4Click(Sender: TObject);
    procedure SpeedButton2Click(Sender: TObject);
    procedure SpeedButton3Click(Sender: TObject);
    procedure Image1Click(Sender: TObject);
    procedure SpeedButton5Click(Sender: TObject);
    procedure SpeedButton6Click(Sender: TObject);
    procedure N1Click(Sender: TObject);
    procedure DatacompravendaDatavencimento1Click(Sender: TObject);
  private
    procedure AbrirForm(sFormP: String; bModalP: Boolean);
    { Private declarations }
  public
    { Public declarations }
  end;

var
  formPrincipal: TformPrincipal;

implementation

uses UDM, ULancamentos, UMenuRelatorios, UCadastroProdutos,
  UCadastroClientesFornecedores, UMenuCadastros, UConfiguracoes, UCadastros,
  UMenuGraficos, UAbout, ULancamentosCR, UAbrirForm, ULogin;

{$R *.dfm}


// ABRIR FORM ********************************************
procedure TformPrincipal.AbrirForm(sFormP: String; bModalP: Boolean);
Var
  FormClasse : TFormClass;
  FormTela : TForm;
  i : Integer;
  bCriado : Boolean;
begin
  bCriado := False;
  FormClasse := TFormClass(FindClass(sFormP));
  for i := 0 to Application.ComponentCount - 1 do
  begin
    if (Application.Components[i] is TForm) and
       (Application.Components[i].ClassName = sFormP) then
    begin
      FormTela := TForm(Application.Components[i]);
      bCriado := True;
      Break;
    end;
  end;
  if not bCriado then
    Application.CreateForm(FormClasse, FormTela);
  if bModalP then
  begin
    FormTela.ShowModal;
    FormTela.Free;
  end
  else
    FormTela.Show;
end;
// **********************************************************


procedure TformPrincipal.Clientes1Click(Sender: TObject);
begin

  formCadastroClientesFornecedores.showmodal;

end;

procedure TformPrincipal.DatacompravendaDatavencimento1Click(Sender: TObject);
var
  strSQL: String;

begin

    if MessageDlg('Esta opera��o n�o poder� ser desfeita.' + #13 + 'Confirma a execu��o da opera��o ??', mtConfirmation, [mbYes,mbNo], 0)=mrYes then
    begin

      StrSQL := 'delete from Pagamentos';
      DM.ConexaoMDB.Execute(strSQL);

      DM.qyListagemCR.First;
      While not DM.qyListagemCR.eof do
      begin
        DM.tabPagamentos.Append;
        DM.tabPagamentos.FieldByName('IDDetalhe').Value := DM.qyListagemCR.FieldByName('IDDetalhe').Value;
        DM.tabPagamentos.FieldByName('DataPagamento').Value := DM.qyListagemCR.FieldByName('DataVencimento').Value;
        DM.tabPagamentos.FieldByName('ValorPago').Value := DM.qyListagemCR.FieldByName('ValorTotal').Value;
        DM.tabPagamentos.Post;
        DM.qyListagemCR.Next;
      end;
        ShowMessage('Opera��o conclu�da!');
    end;

end;

procedure TformPrincipal.FormShow(Sender: TObject);
begin

  try
    Application.CreateForm(TfrmLogin, frmLogin);
    frmLogin.ShowModal;
  finally
    freeandnil(frmLogin);
  end;


  Self.Caption := UpperCase(DM.tabConfiguracao.FieldByName('Nome').Value) + '  - Controle de Vendas e Contas a Receber/Pagar';

    // Wallpaper
    if DM.tabConfiguracao.FieldByName('Imagem').Value <> '' then
    if not(fileexists(DM.tabConfiguracao.FieldByName('Imagem').Value)) then
    begin
      imgfundo.Picture := Nil;
      ShowMessage('Imagem de wallpaper n�o encontrada!');
    end
    else
    begin
      imgfundo.Picture.LoadFromFile(DM.tabConfiguracao.FieldByName('Imagem').value);
    end;

end;



procedure TformPrincipal.Image1Click(Sender: TObject);
begin

  formAbout.ShowModal;

end;

procedure TformPrincipal.Lanamentos1Click(Sender: TObject);
begin

  formLancamentos.ShowModal;

end;

procedure TformPrincipal.N1Click(Sender: TObject);
begin

    if MessageDlg('Esta opera��o n�o poder� ser desfeita.' + #13 + 'Confirma a execu��o da opera��o ??', mtConfirmation, [mbYes,mbNo], 0)=mrYes then
    begin
      DM.tabLancamentos.First;
      While not DM.tabLancamentos.eof do
      begin
        DM.tabLancamentos.edit;
        DM.tabLancamentos.FieldByName('DataVencimento').Value := DM.tabLancamentos.FieldByName('DataLancamento').Value;
        DM.tabLancamentos.Post;
        DM.tabLancamentos.Next;
      end;
        ShowMessage('Opera��o conclu�da!');
    end;

end;

procedure TformPrincipal.Produtos1Click(Sender: TObject);
begin

  formCadastroProdutos.ShowModal;

end;

procedure TformPrincipal.SpeedButton1Click(Sender: TObject);
begin

  formLancamentos.ShowModal;

end;

procedure TformPrincipal.SpeedButton2Click(Sender: TObject);
begin

  //formMenuCadastros.ShowModal;

  formCadastros.ShowModal;

end;

procedure TformPrincipal.SpeedButton3Click(Sender: TObject);
begin

  formConfiguracoes.ShowModal;

  if DM.tabConfiguracao.FieldByName('Imagem').value = '' then
  begin
    imgfundo.Picture := Nil;
    Abort;
  end;

  if not(fileexists(DM.tabConfiguracao.FieldByName('Imagem').Value)) then
  begin
    Showmessage('Imagem de Wallpaper n�o encontrada!');
    imgfundo.Picture := Nil;
  end
  else
  begin
    imgFundo.Picture.LoadFromFile(DM.tabConfiguracao.FieldByName('Imagem').Value);
  end;

  // Atualizando o t�tulo do formPrincipal
  Self.Caption := UpperCase(DM.tabConfiguracao.FieldByName('Nome').Value) + '   -   Controle de Lan�amentos';


end;

procedure TformPrincipal.SpeedButton4Click(Sender: TObject);
begin

  formMenuRelatorios.ShowModal;

end;

procedure TformPrincipal.SpeedButton5Click(Sender: TObject);
begin

  frmLancamentosCR.ShowModal;

end;

procedure TformPrincipal.SpeedButton6Click(Sender: TObject);
var
  P1: TPoint;
begin

  P1 := Mouse.CursorPos;
  PopupMenuOpEspeciais.Popup(P1.X, P1.Y);

end;



procedure TformPrincipal.Timer1Timer(Sender: TObject);
begin

  pnlInferior.Caption := FormatDateTime ('dddd", "dd" de "mmmm" de "yyyy',now) + ' - ' + FormatDateTime('hh:nn:ss',now);;

end;


end.
