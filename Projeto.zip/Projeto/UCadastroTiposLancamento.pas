unit UCadastroTiposLancamento;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, ExtCtrls, DBCtrls, Grids, DBGrids, DB;

type
  TformCadastroTiposLancamento = class(TForm)
    DBGrid1: TDBGrid;
    DBNavigator1: TDBNavigator;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  formCadastroTiposLancamento: TformCadastroTiposLancamento;

implementation

uses UDM;

{$R *.dfm}

procedure TformCadastroTiposLancamento.FormClose(Sender: TObject;
  var Action: TCloseAction);
begin

  if DM.tabTiposLancamentos.state in [dsEdit, dsInsert] then
  begin
        if MessageDlg('Deseja realmente sair sem salvar ?', mtConfirmation, [mbYes,mbNo], 0)=mrYes then
        begin
          DM.tabTiposLancamentos.Cancel;
        end
        else
        begin
          Abort;
        end;
  end;

end;

initialization
  RegisterClass(TformCadastroTiposLancamento);

finalization
  UnRegisterClasses([TformCadastroTiposLancamento]);

end.
