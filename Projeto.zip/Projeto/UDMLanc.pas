unit UDMLanc;

interface

uses
  SysUtils, Classes, DB, ADODB;

type
  TDMLanc = class(TDataModule)
    cnnMDB: TADOConnection;
    tabGrupos: TADOTable;
    tabGruposIDGrupo: TAutoIncField;
    tabGruposGrupo_descricao: TWideStringField;
    tabGruposGrupo_ordem: TIntegerField;
    dsGrupos: TDataSource;
    tabProdutos: TADOTable;
    dsProdutos: TDataSource;
    tabProdutosIDProduto: TAutoIncField;
    tabProdutosProduto_descricao: TWideStringField;
    tabClientes: TADOTable;
    dsClientes: TDataSource;
    tabClientesIDCliente: TAutoIncField;
    tabClientesCliente_nome: TWideStringField;
    tabClientesCliente_endereco: TWideStringField;
    tabClientesCliente_cidade: TWideStringField;
    tabClientesCliente_UF: TWideStringField;
    tabClientesCliente_telefone: TWideStringField;
    tabClientesCliente_email: TWideStringField;
    tabClientesCliente_obs: TWideStringField;
    tabLancamentos: TADOTable;
    dsLancamentos: TDataSource;
    tabLancamentosIDLancamento: TAutoIncField;
    tabLancamentosLanc_data: TDateTimeField;
    tabLancamentosLanc_IDProduto: TIntegerField;
    tabLancamentosLanc_IDCliente: TIntegerField;
    tabLancamentosLanc_qtde: TFloatField;
    tabLancamentosLanc_valorunitario: TBCDField;
    tabLancamentosLanc_valortotal: TBCDField;
    tabLancamentosLanc_obs: TWideStringField;
    tabProdutosProduto_unidade: TWideStringField;
    tabProdutosProduto_valorunitario: TBCDField;
    tabProdutosProduto_IDGrupo: TIntegerField;
    tabLancamentosLanc_vencimento: TDateTimeField;
    qyLanc_listagem: TADOQuery;
    qyLanc_listagemGrupo_descricao: TWideStringField;
    qyLanc_listagemCliente_nome: TWideStringField;
    qyLanc_listagemCliente_cidade: TWideStringField;
    qyLanc_listagemCliente_UF: TWideStringField;
    qyLanc_listagemLanc_data: TDateTimeField;
    qyLanc_listagemLanc_vencimento: TDateTimeField;
    qyLanc_listagemProduto_descricao: TWideStringField;
    qyLanc_listagemLanc_qtde: TFloatField;
    qyLanc_listagemLanc_valorunitario: TBCDField;
    qyLanc_listagemLanc_valortotal: TBCDField;
    dsqyLanc_listagem: TDataSource;
    qyLanc_listagemDias: TWideStringField;
    qyClientes_lista: TADOQuery;
    dsqyClientes_lista: TDataSource;
    qyProdutos_lista: TADOQuery;
    dsqyProdutos_lista: TDataSource;
    qyClientes_listaCliente_nome: TWideStringField;
    qyClientes_listaIDCliente: TAutoIncField;
    qyProdutos_listaProduto_descricao: TWideStringField;
    qyProdutos_listaIDProduto: TAutoIncField;
    tabLancamentosLanc_datapagamento: TDateTimeField;
    tabLancamentosLanc_valorpago: TBCDField;
    qyLanc_listagemLanc_datapagamento: TDateTimeField;
    qyLanc_listagemLanc_valorpago: TBCDField;
    qyLanc_listagemIDLancamento: TAutoIncField;
    qyLanc_listagemSaldo: TBCDField;
    tabLancamentosLanc_tipo: TWideStringField;
    qyLanc_listagemLanc_tipo: TWideStringField;
    tabProdutosProduto_obs: TWideStringField;
    qyGrupos_lista: TADOQuery;
    dsqyGrupos_lista: TDataSource;
    qyProdutos_listaProduto_unidade: TWideStringField;
    qyProdutos_listaConcatenacao: TStringField;
    tabParametros: TADOTable;
    dsParametros: TDataSource;
    tabParametrosID: TAutoIncField;
    tabParametrosParam_DataInicial: TDateTimeField;
    tabParametrosParam_DataFinal: TDateTimeField;
    tabParametrosParam_Tipo: TWideStringField;
    qyVencimentosPorPeriodo: TADOQuery;
    WideStringField1: TWideStringField;
    WideStringField2: TWideStringField;
    WideStringField3: TWideStringField;
    WideStringField4: TWideStringField;
    DateTimeField1: TDateTimeField;
    DateTimeField2: TDateTimeField;
    WideStringField5: TWideStringField;
    FloatField1: TFloatField;
    BCDField1: TBCDField;
    BCDField2: TBCDField;
    WideStringField6: TWideStringField;
    DateTimeField3: TDateTimeField;
    BCDField3: TBCDField;
    AutoIncField1: TAutoIncField;
    BCDField4: TBCDField;
    WideStringField7: TWideStringField;
    dsqyVencimentosPorPeriodo: TDataSource;
    qyVencimentosPorPeriodoParam_DataInicial: TDateTimeField;
    qyVencimentosPorPeriodoParam_DataFinal: TDateTimeField;
    qyVencimentosPorPeriodoIDGrupo: TAutoIncField;
    tabParametrosParam_Grupo: TIntegerField;
    qyVencimentosPorPeriodoParam_Grupo: TIntegerField;
    qyVencimentosPorPeriodoProduto_unidade: TWideStringField;
    tabPagamentos: TADOTable;
    dsPagamentos: TDataSource;
    tabPagamentosIDPagamento: TAutoIncField;
    tabPagamentosPag_IDLanc: TIntegerField;
    tabPagamentosDataPagamento: TDateTimeField;
    tabPagamentosValorPago: TBCDField;
    qySomatoriaPagamentos: TADOQuery;
    dsqySomatoriaPagamentos: TDataSource;
    tabPagamentosExcluir: TStringField;
    procedure qyProdutos_listaCalcFields(DataSet: TDataSet);
    procedure tabPagamentosBeforePost(DataSet: TDataSet);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  DMLanc: TDMLanc;

implementation

uses UDM, ULanc_Inclusao;

{$R *.dfm}

procedure TDMLanc.qyProdutos_listaCalcFields(DataSet: TDataSet);
begin

  DMLanc.qyProdutos_lista.FieldByName('Concatenacao').Value := DMLanc.qyProdutos_lista.FieldByName('Produto_Descricao').Value + '  [' + DMLanc.qyProdutos_lista.FieldByName('Produto_Unidade').Value + ']';

end;

procedure TDMLanc.tabPagamentosBeforePost(DataSet: TDataSet);
begin

  DMLanc.tabPagamentos.Edit;
  DMLanc.tabPagamentos.FieldByName('Pag_IDLanc').Value := DMLanc.tabLancamentos.FieldByName('IDLancamento').Value;

end;

end.
