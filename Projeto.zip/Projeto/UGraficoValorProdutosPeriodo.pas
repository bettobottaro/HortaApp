unit UGraficoValorProdutosPeriodo;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, TeEngine, Series, ExtCtrls, TeeProcs, Chart, DBChart, Buttons,
  StdCtrls, frxClass;

type
  TformGraficoValorProdutosPeriodo = class(TForm)
    DBChart1: TDBChart;
    Series1: TPieSeries;
    Panel1: TPanel;
    SpeedButton1: TSpeedButton;
    SaveDialog1: TSaveDialog;
    tresde: TCheckBox;
    SpeedButton2: TSpeedButton;
    Grafico1: TfrxReport;
    procedure SpeedButton1Click(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure tresdeClick(Sender: TObject);
    procedure Grafico1BeforePrint(Sender: TfrxReportComponent);
    procedure SpeedButton2Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  formGraficoValorProdutosPeriodo: TformGraficoValorProdutosPeriodo;

implementation

uses UDM;

{$R *.dfm}

procedure TformGraficoValorProdutosPeriodo.FormShow(Sender: TObject);
begin

  DBChart1.Title.caption := 'Valores Vendidos de ' + FormatDateTime('dd/mm/yy',DM.tabParametros.FieldByName('DataInicial').value) + ' a ' + FormatDateTime('dd/mm/yy',DM.tabParametros.FieldByName('DataFinal').value);



end;

procedure TformGraficoValorProdutosPeriodo.Grafico1BeforePrint(
  Sender: TfrxReportComponent);
begin

if Sender.Name = 'Picture1' then
   TfrxPictureView(Sender).Picture.Assign(
     DBChart1.TeeCreateMetafile(False,
       Rect(0, 0, Round(Sender.Width), Round(Sender.Height))));

end;

procedure TformGraficoValorProdutosPeriodo.SpeedButton1Click(Sender: TObject);
begin

  SaveDialog1.FileName := 'Gr�fico - Valores Vendidos de '+ FormatDateTime('dd-mm-yy',DM.tabParametros.FieldByName('DataInicial').value) + ' a ' + FormatDateTime('dd-mm-yy',DM.tabParametros.FieldByName('DataFinal').value);

  If SaveDialog1.Execute Then
    Try
      DBChart1.TeeCreateBitmap(clWhite, Rect(0,0, DBChart1.Width, DBChart1.Height)).SaveToFile(SaveDialog1.FileName)
    Finally
      ShowMessage('Gr�fico exportado com sucesso!');
    End;
  end;

procedure TformGraficoValorProdutosPeriodo.SpeedButton2Click(Sender: TObject);
begin

  Grafico1.ShowReport();

end;

procedure TformGraficoValorProdutosPeriodo.tresdeClick(Sender: TObject);
begin

  if tresde.Checked = true then
  begin
    DBChart1.View3D := true;
  end
  else
  begin
    DBChart1.View3D := false;
  end;

end;

end.
