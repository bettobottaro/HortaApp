object formMenuCadastros: TformMenuCadastros
  Left = 0
  Top = 0
  BorderIcons = [biSystemMenu]
  Caption = 'Menu de Cadastros'
  ClientHeight = 229
  ClientWidth = 205
  Color = 7066515
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -16
  Font.Name = 'Tahoma'
  Font.Style = []
  Menu = MainMenu1
  OldCreateOrder = False
  Position = poOwnerFormCenter
  PixelsPerInch = 96
  TextHeight = 19
  object MainMenu1: TMainMenu
    Left = 88
    Top = 32
    object CADASTROS1: TMenuItem
      Caption = '[ SELECIONE O CADASTRO ]'
      object Produtos1: TMenuItem
        Caption = #8226' Produtos'
        ImageIndex = 0
        OnClick = Produtos1Click
      end
      object Clientes1: TMenuItem
        Caption = #8226' Clientes / Fornecedores'
        OnClick = Clientes1Click
      end
      object iposdelanamentos1: TMenuItem
        Caption = #8226' Tipos de lan'#231'amentos'
        OnClick = iposdelanamentos1Click
      end
      object Unidades1: TMenuItem
        Caption = #8226' Unidades'
        OnClick = Unidades1Click
      end
    end
  end
end
