object formCadastroClientesFornecedores: TformCadastroClientesFornecedores
  Left = 0
  Top = 0
  BorderIcons = [biSystemMenu]
  Caption = 'Cadastro de Clientes/Fornecedores'
  ClientHeight = 495
  ClientWidth = 875
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  OnClose = FormClose
  PixelsPerInch = 96
  TextHeight = 13
  object DBGrid1: TDBGrid
    Left = 8
    Top = 8
    Width = 859
    Height = 441
    DataSource = DM.dsClientesFornecedores
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 0
    TitleFont.Charset = DEFAULT_CHARSET
    TitleFont.Color = clWindowText
    TitleFont.Height = -11
    TitleFont.Name = 'Tahoma'
    TitleFont.Style = []
    Columns = <
      item
        Alignment = taCenter
        Color = 6029229
        Expanded = False
        FieldName = 'IDClienteFornecedor'
        Title.Alignment = taCenter
        Title.Caption = 'ID'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Nome'
        Title.Alignment = taCenter
        Width = 250
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Endereco_linha1'
        Title.Alignment = taCenter
        Width = 190
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Endereco_linha2'
        Title.Alignment = taCenter
        Width = 190
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Telefone'
        Title.Alignment = taCenter
        Width = 90
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Obs'
        Title.Alignment = taCenter
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'AcrescimoDesconto'
        Title.Alignment = taCenter
        Width = 90
        Visible = True
      end>
  end
  object DBNavigator1: TDBNavigator
    Left = 281
    Top = 455
    Width = 312
    Height = 34
    DataSource = DM.dsClientesFornecedores
    VisibleButtons = [nbInsert, nbDelete, nbPost]
    TabOrder = 1
  end
end
