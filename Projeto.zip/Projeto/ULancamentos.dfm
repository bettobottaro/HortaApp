object formLancamentos: TformLancamentos
  Left = 0
  Top = 0
  Caption = 'Lan'#231'amentos'
  ClientHeight = 653
  ClientWidth = 1156
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -16
  Font.Name = 'Tahoma'
  Font.Style = []
  KeyPreview = True
  OldCreateOrder = False
  Position = poScreenCenter
  ShowHint = True
  WindowState = wsMaximized
  OnKeyPress = FormKeyPress
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 19
  object Label6: TLabel
    Left = 248
    Top = 110
    Width = 98
    Height = 19
    Caption = 'Valor Unit'#225'rio'
  end
  object Painel1: TPanel
    Left = 0
    Top = 0
    Width = 1156
    Height = 185
    Align = alTop
    Color = 10547655
    ParentBackground = False
    TabOrder = 0
    object Shape1: TShape
      Left = 453
      Top = 92
      Width = 147
      Height = 37
      Brush.Style = bsClear
      Pen.Color = clSilver
    end
    object Label4: TLabel
      Left = 490
      Top = 165
      Width = 270
      Height = 16
      Caption = '[ duplo clique para alterar o lan'#231'amento ]'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -13
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object etiquetaFonte: TLabel
      Left = 504
      Top = 112
      Width = 38
      Height = 16
      Caption = 'fonte: '
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -13
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object GroupBox1: TGroupBox
      Left = 5
      Top = 62
      Width = 434
      Height = 97
      Caption = ' [ Filtros ] '
      Color = 10547655
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -12
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentBackground = False
      ParentColor = False
      ParentFont = False
      TabOrder = 0
      object Label1: TLabel
        Left = 32
        Top = 22
        Width = 104
        Height = 14
        Caption = 'Cliente/Fornecedor'
      end
      object Label2: TLabel
        Left = 109
        Top = 46
        Width = 44
        Height = 14
        Caption = 'Produto'
      end
      object Label3: TLabel
        Left = 133
        Top = 70
        Width = 24
        Height = 14
        Caption = 'Tipo'
      end
      object SpeedButton1: TSpeedButton
        Left = 385
        Top = 19
        Width = 23
        Height = 22
        Glyph.Data = {
          BA010000424DBA01000000000000CA000000280000000F0000000F0000000100
          080000000000F0000000130B0000130B00002500000025000000FFFFFF000000
          000004040400FEFEFE00F4F4F4000101010003040400F5F5F500FBFBFB00F8F8
          F8000C0C0C00C3C3C3007C7C7C00C0C0C0007F7F7F000E0E0E00B9BABA009393
          9300DCDCDC009A9A9A003333330016161600383838002D2D2D0055555500ECEC
          EC00696969001B1B1B00ABABAB0090909000B5B5B500D5D5D500CECECE006E6E
          6E00A4A4A4004444440023232300000000000800090000000008000900000800
          030000070004000300000700090000040000000106010201010101061B000300
          0400050101060102010501010500000700020101000006010200000101000000
          0501020103000005000400050100030101060102010000000700020101000101
          0101060102010000000601020100080105010106010400030000060105000004
          0101010107000401000000060100030004010501000701020103000105000007
          000401010101060102010101010000000300040105010105010201051B000300
          000700040000000007000400000000030000030008000300000300080000}
        OnClick = SpeedButton1Click
      end
      object SpeedButton3: TSpeedButton
        Left = 385
        Top = 43
        Width = 23
        Height = 22
        Glyph.Data = {
          BA010000424DBA01000000000000CA000000280000000F0000000F0000000100
          080000000000F0000000130B0000130B00002500000025000000FFFFFF000000
          000004040400FEFEFE00F4F4F4000101010003040400F5F5F500FBFBFB00F8F8
          F8000C0C0C00C3C3C3007C7C7C00C0C0C0007F7F7F000E0E0E00B9BABA009393
          9300DCDCDC009A9A9A003333330016161600383838002D2D2D0055555500ECEC
          EC00696969001B1B1B00ABABAB0090909000B5B5B500D5D5D500CECECE006E6E
          6E00A4A4A4004444440023232300000000000800090000000008000900000800
          030000070004000300000700090000040000000106010201010101061B000300
          0400050101060102010501010500000700020101000006010200000101000000
          0501020103000005000400050100030101060102010000000700020101000101
          0101060102010000000601020100080105010106010400030000060105000004
          0101010107000401000000060100030004010501000701020103000105000007
          000401010101060102010101010000000300040105010105010201051B000300
          000700040000000007000400000000030000030008000300000300080000}
        OnClick = SpeedButton3Click
      end
      object SpeedButton4: TSpeedButton
        Left = 313
        Top = 67
        Width = 23
        Height = 22
        Glyph.Data = {
          BA010000424DBA01000000000000CA000000280000000F0000000F0000000100
          080000000000F0000000130B0000130B00002500000025000000FFFFFF000000
          000004040400FEFEFE00F4F4F4000101010003040400F5F5F500FBFBFB00F8F8
          F8000C0C0C00C3C3C3007C7C7C00C0C0C0007F7F7F000E0E0E00B9BABA009393
          9300DCDCDC009A9A9A003333330016161600383838002D2D2D0055555500ECEC
          EC00696969001B1B1B00ABABAB0090909000B5B5B500D5D5D500CECECE006E6E
          6E00A4A4A4004444440023232300000000000800090000000008000900000800
          030000070004000300000700090000040000000106010201010101061B000300
          0400050101060102010501010500000700020101000006010200000101000000
          0501020103000005000400050100030101060102010000000700020101000101
          0101060102010000000601020100080105010106010400030000060105000004
          0101010107000401000000060100030004010501000701020103000105000007
          000401010101060102010101010000000300040105010105010201051B000300
          000700040000000007000400000000030000030008000300000300080000}
        OnClick = SpeedButton4Click
      end
      object filtroClienteFornecedor: TEdit
        Left = 159
        Top = 19
        Width = 225
        Height = 22
        TabOrder = 0
        OnChange = filtroClienteFornecedorChange
      end
      object filtroProduto: TEdit
        Left = 159
        Top = 43
        Width = 225
        Height = 22
        TabOrder = 1
        OnChange = filtroProdutoChange
      end
      object filtroTipo: TEdit
        Left = 159
        Top = 67
        Width = 153
        Height = 22
        TabOrder = 2
        OnChange = filtroTipoChange
      end
    end
    object Panel2: TPanel
      Left = 1
      Top = 1
      Width = 1154
      Height = 55
      Align = alTop
      Color = 4109677
      ParentBackground = False
      TabOrder = 1
      object SpeedButton2: TSpeedButton
        Left = 7
        Top = 8
        Width = 157
        Height = 38
        Hint = 'NOVO LAN'#199'AMENTO'
        Caption = '  Novo lan'#231'amento'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'Tahoma'
        Font.Style = []
        Glyph.Data = {
          F6060000424DF606000000000000360000002800000018000000180000000100
          180000000000C0060000130B0000130B00000000000000000000FFFFFFFFFFFF
          FFFFFFFEFEFEFFFFFFFFFFFFF8FBF8DCECDC83BE833999390F840E1D8A1B1D8A
          1B0F840E39993983BE83DCECDCF8FBF8FFFFFFFFFFFFFEFEFEFFFFFFFFFFFFFF
          FFFFFFFFFFFFFFFFFEFEFEFFFFFFFCFDFCCCE4CD69B16A1C8A1B49A0495AA95A
          58A95849A04949A04958A9585AA95A49A0491C8A1B69B16ACCE4CDFCFDFCFFFF
          FFFEFEFEFFFFFFFFFFFFFFFFFFFEFEFEFFFFFFF6F9F68EC48E3F9B3F409B4040
          9D41088208007A00007B00007C00007C00007B00007A00088108409D41409B40
          409C3F8EC48EF5F9F6FFFFFFFEFEFEFFFFFFFEFEFEFFFFFFF6FAF67BBA7B4CA3
          4C3C9A3D0C840D007C00007E01027F03007800007500007500007700007D0000
          7E01007C000C840D3D9A3D4CA34C7ABA7AF6FAF6FFFFFFFEFEFEFFFFFFFDFEFD
          92C7924CA34D309531017E02007E01017F02007F020077009ACB9ACBE5CBCBE5
          CCB3D8B3259025007D00017F02007E01017E013195314CA34D92C792FDFEFDFF
          FFFFFFFFFFD2E7D3429D433B9A3B017E02007E01017F02017F02007F02007500
          C1DFC1FFFFFFFFFFFFE1EFE12E952E007C00017F02017F02007E01017E023B9A
          3B429D43D2E7D3FFFFFFF9FCF976B7783D993C128612007E00017F02017F0201
          7F02007F02007500C1DEC1FFFFFFFFFFFFE0EFE02E942E007C00017F02017F02
          017F02007E001286123D9A3C76B877F9FCF9E6F1E6208C2047A047007B00017E
          02007E01017F02017F02007F02007500C1DEC1FFFFFFFFFFFFE0EFE02E942E00
          7C00017F02017F02017F02017F02007B00469F46208C1FE5F1E599CA993F9C3F
          219022078207007E01007B00007B00007B00007B00007100BFDDBFFFFFFFFFFF
          FFDFEEDF289128007800007B00007B00007B00007C00007E001386133C9A3C99
          CA9954A65467B0671B8D1C178A16228F2152A75254A75454A75454A75449A149
          D4E9D4FFFFFFFFFFFFEAF4EA72B67251A65154A75454A75454A754389838007C
          00007A0059A75854A65328902777BB792F962F24902356A956E7F2E7EDF5EDED
          F5EDEDF5EDECF5ECFAFCFAFEFFFEFFFFFFFCFDFCF0F7F0EDF5EDEDF5EDEDF5ED
          ECF4EB9BCA9B007800007B0056A956268F250E850F8CC58B3F9F3E35993467B2
          66F8FBF8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFEFEFEFEFFFFFFFFFFFFFF
          FFFFFFFFFFFFFFFFFDFEFDA7D1A7007700007B0058A9590C830D11861097CB96
          51A75044A14471B872F8FBF8FDFEFDFDFEFDFDFEFDFDFEFDFEFEFEFEFEFEFFFF
          FFFEFEFEFEFEFEFDFEFDFDFEFDFDFEFDFCFDFCA6D0A6007700007B0059AB5A0F
          840F2B922B95C99461B16256AA566FB66FBFDEBFC0DFBFBBDDBBB4DAB4A6D2A7
          EAF3EAFFFEFFFFFFFFF5F9F5BADCBAA9D4AAABD5ACABD5ACAAD4AB70B571007A
          00007B0057A8552990295AAA5A85C08573BA756AB46B5EAE5D4CA44B419F3F35
          9935249123007600BEDDBEFFFFFFFFFFFFDEEEDE218E22007400007700007700
          007700007A00017F03007A0056A85759AA59A3CFA34FA44F98CB987ABC7972B8
          7166B3665CAC5B51A95148A348299429CBE4CBFFFEFFFFFFFFE0EFE02E942E00
          7C00017F02017F02017F02017F02007D001A8A1A369735A3CFA3EAF4EA2E932F
          A8D2A78CC48A81C08176BA776BB56B63B16258AB573F9F40D0E7D1FFFFFFFFFF
          FFE0EFE02D942D007C00017F02017F02017F02017F02007B0046A047258F26EA
          F4EAFAFCFA7EBC7E67B068ABD5AB90C79287C3877EBE7E74B87367B36850A851
          D5E9D5FFFEFFFFFFFFE2F0E2399C39007E00007E00007E01007E01007E001889
          1938973780BD80FAFCFAFFFFFFD9EBD94AA24A9CCC9CA3D1A497CC978EC68E83
          C18278BB7863B163D5E9D5F9FCF9F9FCF9E1F0E159AC5A2D952C1F8E1F118812
          0884090882063E9C3E49A14ADAEBDAFFFFFFFFFFFFFFFFFF9CCB9C58A858ACD6
          ACA9D4AA9ECF9D94C99489C4897DBE7D85C28583C08378BB796DB56D4FA74F40
          9E3F379B362C942A249224419E414FA44E9DCC9EFFFFFFFFFFFFFEFEFEFFFFFF
          FCFDFC82BD8259A959A3D0A4BBDCBDA2D1A399CC998FC78F84C08376BB786DB6
          6D62B0635BAC5A50A75044A1424EA74E55A85550A54F86BF86FBFDFCFFFFFFFE
          FEFEFFFFFFFEFEFEFFFFFFFCFDFC9BCB9C49A2496EB470BADCBABCDDBBA2D0A1
          95CA9588C4887DBE7E75BA746BB46B76B9767DBD7C4CA34C4AA24A9DCC9EFBFD
          FCFFFFFFFEFEFEFFFFFFFFFFFFFFFFFFFEFEFEFFFFFFFFFFFFD9EBD97CBB7D30
          943057A75798C998B4D9B5C0DEC1BBDCB9A3CFA384BF854AA1492A92297EBC7E
          D9EBD9FFFFFFFFFFFFFEFEFEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFEFEFFFF
          FFFFFFFFFAFCFAE9F3E9A1CEA159A95A2B922C1285111285112B922B59A95AA1
          CEA1E9F4E9FAFCFAFFFFFFFFFFFFFEFEFEFFFFFFFFFFFFFFFFFF}
        ParentFont = False
        OnClick = SpeedButton2Click
      end
    end
    object slider1: TJvxSlider
      Left = 464
      Top = 92
      Width = 129
      Height = 24
      Increment = 1
      MinValue = 6
      MaxValue = 18
      EdgeSize = 1
      TabOrder = 2
      TabStop = False
      Value = 11
      OnChange = slider1Change
    end
  end
  object Grade1: TDBGrid
    Left = 0
    Top = 185
    Width = 1156
    Height = 439
    TabStop = False
    Align = alClient
    DataSource = DM.dsqyListagem
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Tahoma'
    Font.Style = []
    Options = [dgTitles, dgIndicator, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgRowSelect, dgAlwaysShowSelection, dgConfirmDelete, dgCancelOnExit, dgTitleClick, dgTitleHotTrack]
    ParentFont = False
    ReadOnly = True
    TabOrder = 1
    TitleFont.Charset = DEFAULT_CHARSET
    TitleFont.Color = clWindowText
    TitleFont.Height = -11
    TitleFont.Name = 'Tahoma'
    TitleFont.Style = []
    OnDrawColumnCell = Grade1DrawColumnCell
    OnDblClick = Grade1DblClick
    OnTitleClick = Grade1TitleClick
    Columns = <
      item
        Expanded = False
        FieldName = 'DataLancamento'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -15
        Font.Name = 'Tahoma'
        Font.Style = []
        Title.Alignment = taCenter
        Width = 85
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'DataVencimento'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -15
        Font.Name = 'Tahoma'
        Font.Style = []
        Title.Alignment = taCenter
        Title.Caption = 'Vencimento'
        Width = 85
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Tipo'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -15
        Font.Name = 'Tahoma'
        Font.Style = []
        Title.Alignment = taCenter
        Width = 100
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Nome'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -15
        Font.Name = 'Tahoma'
        Font.Style = []
        Title.Alignment = taCenter
        Width = 220
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Produto'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -15
        Font.Name = 'Tahoma'
        Font.Style = []
        Title.Alignment = taCenter
        Width = 180
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Qtde'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -15
        Font.Name = 'Tahoma'
        Font.Style = []
        Title.Alignment = taCenter
        Width = 50
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Unidade'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -15
        Font.Name = 'Tahoma'
        Font.Style = []
        Title.Alignment = taCenter
        Width = 80
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'ValorUnitario'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -15
        Font.Name = 'Tahoma'
        Font.Style = []
        Title.Alignment = taCenter
        Width = 80
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'ValorTotal'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -15
        Font.Name = 'Tahoma'
        Font.Style = []
        Title.Alignment = taCenter
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Obs'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -15
        Font.Name = 'Tahoma'
        Font.Style = []
        Title.Alignment = taCenter
        Width = 237
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'OrdemRelatorio'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -15
        Font.Name = 'Tahoma'
        Font.Style = []
        Title.Alignment = taCenter
        Visible = False
      end>
  end
  object Painel2: TPanel
    Left = 0
    Top = 624
    Width = 1156
    Height = 29
    Align = alBottom
    Color = 10547655
    ParentBackground = False
    TabOrder = 2
  end
end
