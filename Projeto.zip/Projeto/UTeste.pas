unit UTeste;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs;

type
  TformTeste = class(TForm)

  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  formTeste: TformTeste;

implementation

{$R *.dfm}



initialization
  RegisterClass(TformTeste);

finalization
  UnRegisterClasses([TformTeste]);



end.
