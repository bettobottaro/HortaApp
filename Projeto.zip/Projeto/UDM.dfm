object DM: TDM
  OldCreateOrder = False
  OnCreate = DataModuleCreate
  Height = 785
  Width = 854
  object ConexaoMDB: TADOConnection
    ConnectionString = 
      'Provider=Microsoft.Jet.OLEDB.4.0;User ID=Admin;Data Source=\Cont' +
      'roleVendas\BD\Dados.MDB;Mode=Share Deny None;Persist Security In' +
      'fo=False;Jet OLEDB:System database="";Jet OLEDB:Registry Path=""' +
      ';Jet OLEDB:Database Password="";Jet OLEDB:Engine Type=5;Jet OLED' +
      'B:Database Locking Mode=1;Jet OLEDB:Global Partial Bulk Ops=2;Je' +
      't OLEDB:Global Bulk Transactions=1;Jet OLEDB:New Database Passwo' +
      'rd="";Jet OLEDB:Create System Database=False;Jet OLEDB:Encrypt D' +
      'atabase=False;Jet OLEDB:Don'#39't Copy Locale on Compact=False;Jet O' +
      'LEDB:Compact Without Replica Repair=False;Jet OLEDB:SFP=False'
    LoginPrompt = False
    Mode = cmShareDenyNone
    Provider = 'Microsoft.Jet.OLEDB.4.0'
    Left = 400
    Top = 16
  end
  object tabConfiguracao: TADOTable
    Connection = ConexaoMDB
    CursorType = ctStatic
    TableName = 'Configuracao'
    Left = 72
    Top = 80
    object tabConfiguracaoNome: TWideStringField
      FieldName = 'Nome'
      Size = 200
    end
    object tabConfiguracaoImagem: TWideStringField
      FieldName = 'Imagem'
      Size = 255
    end
    object tabConfiguracaoLogotipo: TWideStringField
      FieldName = 'Logotipo'
      Size = 255
    end
  end
  object tabProdutos: TADOTable
    Connection = ConexaoMDB
    CursorType = ctStatic
    IndexFieldNames = 'Descricao'
    TableName = 'Produtos'
    Left = 176
    Top = 80
    object tabProdutosIDProduto: TAutoIncField
      FieldName = 'IDProduto'
      ReadOnly = True
    end
    object tabProdutosDescricao: TWideStringField
      DisplayLabel = 'Descri'#231#227'o'
      FieldName = 'Descricao'
      Size = 200
    end
    object tabProdutosQtdeEstoque: TFloatField
      DisplayLabel = 'Estoque'
      FieldName = 'QtdeEstoque'
    end
    object tabProdutosValorBase: TBCDField
      DisplayLabel = 'Valor Base'
      FieldName = 'ValorBase'
      DisplayFormat = '###,###,##0.00'
      Precision = 19
    end
    object tabProdutosObs: TWideMemoField
      FieldName = 'Obs'
      BlobType = ftWideMemo
    end
    object tabProdutosGrupo: TWideStringField
      Alignment = taCenter
      FieldName = 'Grupo'
    end
    object tabProdutosGrupoAux: TStringField
      Alignment = taCenter
      FieldKind = fkLookup
      FieldName = 'GrupoAux'
      LookupDataSet = tabGrupos
      LookupKeyFields = 'Grupo'
      LookupResultField = 'Grupo'
      KeyFields = 'Grupo'
      Size = 30
      Lookup = True
    end
  end
  object dsConfiguracao: TDataSource
    DataSet = tabConfiguracao
    Left = 72
    Top = 136
  end
  object dsProdutos: TDataSource
    DataSet = tabProdutos
    Left = 176
    Top = 136
  end
  object tabClientesFornecedores: TADOTable
    Connection = ConexaoMDB
    CursorType = ctStatic
    IndexFieldNames = 'Nome'
    TableName = 'ClientesFornecedores'
    Left = 288
    Top = 80
    object tabClientesFornecedoresNome: TWideStringField
      FieldName = 'Nome'
      Size = 200
    end
    object tabClientesFornecedoresEndereco_linha1: TWideStringField
      FieldName = 'Endereco_linha1'
      Size = 200
    end
    object tabClientesFornecedoresTelefone: TWideStringField
      Alignment = taCenter
      FieldName = 'Telefone'
      Size = 50
    end
    object tabClientesFornecedoresObs: TWideMemoField
      FieldName = 'Obs'
      BlobType = ftWideMemo
    end
    object tabClientesFornecedoresIDClienteFornecedor: TAutoIncField
      FieldName = 'IDClienteFornecedor'
      ReadOnly = True
    end
    object tabClientesFornecedoresAcrescimoDesconto: TBCDField
      DisplayLabel = 'Acr'#233'sc/Desc'
      FieldName = 'AcrescimoDesconto'
      DisplayFormat = '###,###,##0.00'
      Precision = 19
    end
    object tabClientesFornecedoresEndereco_cidade: TWideStringField
      FieldName = 'Endereco_cidade'
    end
    object tabClientesFornecedoresEndereco_UF: TWideStringField
      Alignment = taCenter
      FieldName = 'Endereco_UF'
      Size = 2
    end
    object tabClientesFornecedoresEndereco_CEP: TWideStringField
      FieldName = 'Endereco_CEP'
      EditMask = '00000\-999;1;_'
      Size = 9
    end
  end
  object dsClientesFornecedores: TDataSource
    DataSet = tabClientesFornecedores
    Left = 288
    Top = 128
  end
  object tabTiposLancamentos: TADOTable
    Connection = ConexaoMDB
    CursorType = ctStatic
    IndexFieldNames = 'OrdemRelatorio'
    TableName = 'TiposLancamentos'
    Left = 416
    Top = 80
    object tabTiposLancamentosIDTipo: TAutoIncField
      FieldName = 'IDTipo'
      ReadOnly = True
    end
    object tabTiposLancamentosDescricao: TWideStringField
      DisplayLabel = 'Descri'#231#227'o'
      FieldName = 'Descricao'
    end
    object tabTiposLancamentosOrdemRelatorio: TIntegerField
      Alignment = taCenter
      DisplayLabel = 'Ordem Relat'#243'rio'
      FieldName = 'OrdemRelatorio'
    end
    object tabTiposLancamentosControleCR: TWideStringField
      Alignment = taCenter
      FieldName = 'ControleCR'
      Size = 3
    end
    object tabTiposLancamentosSimNao: TStringField
      Alignment = taCenter
      FieldKind = fkLookup
      FieldName = 'SimNao'
      LookupDataSet = tabSimNao
      LookupKeyFields = 'Opcao'
      LookupResultField = 'Opcao'
      KeyFields = 'ControleCR'
      Size = 3
      Lookup = True
    end
    object tabTiposLancamentosIcone: TWideStringField
      FieldName = 'Icone'
      Size = 255
    end
    object tabTiposLancamentosIndiceImagem: TIntegerField
      Alignment = taCenter
      FieldName = 'IndiceImagem'
    end
    object tabTiposLancamentosSomarDeduzir: TWideStringField
      Alignment = taCenter
      FieldName = 'SomarDeduzir'
      Size = 10
    end
    object tabTiposLancamentosAuxSomarDeduzir: TStringField
      Alignment = taCenter
      FieldKind = fkLookup
      FieldName = 'AuxSomarDeduzir'
      LookupDataSet = tabSomarDeduzir
      LookupKeyFields = 'SomarDeduzir'
      LookupResultField = 'SomarDeduzir'
      KeyFields = 'SomarDeduzir'
      Size = 1
      Lookup = True
    end
  end
  object dsTiposLancamentos: TDataSource
    DataSet = tabTiposLancamentos
    Left = 416
    Top = 136
  end
  object tabLancamentos: TADOTable
    Connection = ConexaoMDB
    CursorType = ctStatic
    TableName = 'Lancamentos'
    BeforePost = tabLancamentosBeforePost
    Left = 544
    Top = 80
    object tabLancamentosIDLancamento: TAutoIncField
      FieldName = 'IDLancamento'
      ReadOnly = True
    end
    object tabLancamentosDataLancamento: TDateTimeField
      Alignment = taCenter
      DisplayLabel = 'Data'
      FieldName = 'DataLancamento'
      DisplayFormat = 'dd/mm/yy'
    end
    object tabLancamentosDataVencimento: TDateTimeField
      FieldName = 'DataVencimento'
      DisplayFormat = 'dd/mm/yy'
    end
    object tabLancamentosIDTipo: TIntegerField
      FieldName = 'IDTipo'
    end
    object tabLancamentosIDClienteFornecedor: TIntegerField
      FieldName = 'IDClienteFornecedor'
    end
    object tabLancamentosIDProduto: TIntegerField
      FieldName = 'IDProduto'
    end
    object tabLancamentosQtde: TFloatField
      Alignment = taCenter
      FieldName = 'Qtde'
    end
    object tabLancamentosValorUnitario: TBCDField
      DisplayLabel = 'Valor Unit'#225'rio'
      FieldName = 'ValorUnitario'
      DisplayFormat = '###,###,##0.00'
      Precision = 19
    end
    object tabLancamentosObs: TWideStringField
      FieldName = 'Obs'
      Size = 255
    end
    object tabLancamentosValorTotal: TCurrencyField
      DisplayLabel = 'Valor Total'
      FieldKind = fkCalculated
      FieldName = 'ValorTotal'
      DisplayFormat = '###,###,##0.00'
      Calculated = True
    end
    object tabLancamentosIDUnidade: TIntegerField
      FieldName = 'IDUnidade'
    end
  end
  object dsLancamentos: TDataSource
    DataSet = tabLancamentos
    Left = 544
    Top = 136
  end
  object qyListagem: TADOQuery
    Connection = ConexaoMDB
    CursorType = ctStatic
    Parameters = <>
    SQL.Strings = (
      'Select'
      '    Lancamentos.IDLancamento,'
      '    Lancamentos.DataLancamento,'
      '    Lancamentos.DataVencimento,'
      '    TiposLancamentos.OrdemRelatorio,'
      '    TiposLancamentos.Descricao As Tipo,'
      '    ClientesFornecedores.Nome,'
      '    Produtos.Descricao As Produto,'
      '    Lancamentos.Obs,'
      '    Lancamentos.Qtde,'
      '    Unidades.Unidade,'
      '    TiposLancamentos.SomarDeduzir,'
      
        '    IIF(TiposLancamentos.SomarDeduzir = '#39'+'#39', Abs(Lancamentos.Val' +
        'orUnitario), -(Abs(Lancamentos.ValorUnitario))) As'
      '    ValorUnitario,'
      
        '    Lancamentos.Qtde * IIF(TiposLancamentos.SomarDeduzir = '#39'+'#39', ' +
        'Abs(Lancamentos.ValorUnitario),'
      '    -(Abs(Lancamentos.ValorUnitario))) As ValorTotal,'
      
        '    Str(ClientesFornecedores.IDClienteFornecedor) + '#39' - '#39' + Tipo' +
        'sLancamentos.Descricao + '#39' - '#39' +'
      '    Str(Lancamentos.DataVencimento) As IDDetalhe'
      'From'
      '    (((Lancamentos Inner Join'
      
        '    TiposLancamentos On Lancamentos.IDTipo = TiposLancamentos.ID' +
        'Tipo) Inner Join'
      
        '    Produtos On Lancamentos.IDProduto = Produtos.IDProduto) Inne' +
        'r Join'
      
        '    ClientesFornecedores On Lancamentos.IDClienteFornecedor = Cl' +
        'ientesFornecedores.IDClienteFornecedor) Inner Join'
      '    Unidades On Lancamentos.IDUnidade = Unidades.IDUnidade'
      'Order By'
      '    Lancamentos.DataLancamento,'
      '    TiposLancamentos.OrdemRelatorio,'
      '    ClientesFornecedores.Nome')
    Left = 72
    Top = 424
    object qyListagemDataLancamento: TDateTimeField
      Alignment = taCenter
      DisplayLabel = 'Data'
      FieldName = 'DataLancamento'
      DisplayFormat = 'dd/mm/yy'
    end
    object qyListagemDataVencimento: TDateTimeField
      Alignment = taCenter
      FieldName = 'DataVencimento'
      DisplayFormat = 'dd/mm/yy'
    end
    object qyListagemTipo: TWideStringField
      FieldName = 'Tipo'
    end
    object qyListagemNome: TWideStringField
      FieldName = 'Nome'
      Size = 200
    end
    object qyListagemProduto: TWideStringField
      FieldName = 'Produto'
      Size = 200
    end
    object qyListagemOrdemRelatorio: TIntegerField
      Alignment = taCenter
      FieldName = 'OrdemRelatorio'
    end
    object qyListagemQtde: TFloatField
      Alignment = taCenter
      FieldName = 'Qtde'
    end
    object qyListagemValorUnitario: TBCDField
      DisplayLabel = 'Valor Unit'#225'rio'
      FieldName = 'ValorUnitario'
      DisplayFormat = '###,###,##0.00'
      Precision = 19
    end
    object qyListagemValorTotal: TFloatField
      DisplayLabel = 'Valor Total'
      FieldName = 'ValorTotal'
      ReadOnly = True
      DisplayFormat = '###,###,##0.00'
    end
    object qyListagemObs: TWideStringField
      FieldName = 'Obs'
      Size = 255
    end
    object qyListagemIDLancamento: TAutoIncField
      FieldName = 'IDLancamento'
      ReadOnly = True
    end
    object qyListagemUnidade: TWideStringField
      Alignment = taCenter
      FieldName = 'Unidade'
    end
    object qyListagemIDDetalhe: TWideStringField
      FieldName = 'IDDetalhe'
      ReadOnly = True
      Size = 255
    end
  end
  object dsqyListagem: TDataSource
    DataSet = qyListagem
    Left = 72
    Top = 480
  end
  object tabUnidades: TADOTable
    Connection = ConexaoMDB
    CursorType = ctStatic
    IndexFieldNames = 'Unidade'
    TableName = 'Unidades'
    Left = 648
    Top = 80
    object tabUnidadesIDUnidade: TAutoIncField
      FieldName = 'IDUnidade'
      ReadOnly = True
    end
    object tabUnidadesUnidade: TWideStringField
      Alignment = taCenter
      FieldName = 'Unidade'
    end
  end
  object dsUnidades: TDataSource
    DataSet = tabUnidades
    Left = 648
    Top = 136
  end
  object tabParametros: TADOTable
    Connection = ConexaoMDB
    CursorType = ctStatic
    TableName = 'Parametros'
    Left = 72
    Top = 216
    object tabParametrosID: TAutoIncField
      FieldName = 'ID'
      ProviderFlags = [pfInUpdate, pfInWhere, pfInKey]
      ReadOnly = True
    end
    object tabParametrosDataInicial: TDateTimeField
      Alignment = taCenter
      FieldName = 'DataInicial'
      ProviderFlags = [pfInUpdate, pfInWhere, pfInKey]
      DisplayFormat = 'dd/mm/yyyy'
    end
    object tabParametrosDataFinal: TDateTimeField
      Alignment = taCenter
      FieldName = 'DataFinal'
      ProviderFlags = [pfInUpdate, pfInWhere, pfInKey]
      DisplayFormat = 'dd/mm/yyyy'
    end
    object tabParametrosClienteFornecedor: TWideStringField
      FieldName = 'ClienteFornecedor'
      ProviderFlags = [pfInUpdate, pfInWhere, pfInKey]
      Size = 150
    end
    object tabParametrosTipoLancamento: TWideStringField
      FieldName = 'TipoLancamento'
      ProviderFlags = [pfInUpdate, pfInWhere, pfInKey]
      Size = 150
    end
    object tabParametrosProduto: TWideStringField
      FieldName = 'Produto'
      ProviderFlags = [pfInUpdate, pfInWhere, pfInKey]
      Size = 150
    end
    object tabParametrosFiltros: TWideStringField
      FieldName = 'Filtros'
      ProviderFlags = [pfInUpdate, pfInWhere, pfInKey]
      Size = 255
    end
    object tabParametrosGrupo: TWideStringField
      FieldName = 'Grupo'
      ProviderFlags = [pfInUpdate, pfInWhere, pfInKey]
      Size = 30
    end
  end
  object dsParametros: TDataSource
    DataSet = tabParametros
    Left = 72
    Top = 272
  end
  object qyLancamentosPeriodo: TADOQuery
    Connection = ConexaoMDB
    CursorType = ctStatic
    Parameters = <>
    SQL.Strings = (
      'Select'
      '    Lancamentos.IDLancamento,'
      '    Produtos.Grupo,'
      '    Lancamentos.DataLancamento,'
      '    TiposLancamentos.OrdemRelatorio,'
      '    TiposLancamentos.Descricao As Tipo,'
      '    ClientesFornecedores.Nome,'
      '    Produtos.Descricao As Produto,'
      '    Lancamentos.Obs,'
      '    Lancamentos.Qtde,'
      '    Unidades.Unidade,'
      '    TiposLancamentos.SomarDeduzir,'
      
        '    IIF(TiposLancamentos.SomarDeduzir = '#39'+'#39', Abs(Lancamentos.Val' +
        'orUnitario), -(Abs(Lancamentos.ValorUnitario))) As'
      '    ValorUnitario,'
      
        '    Lancamentos.Qtde * IIF(TiposLancamentos.SomarDeduzir = '#39'+'#39', ' +
        'Abs(Lancamentos.ValorUnitario),'
      '    -(Abs(Lancamentos.ValorUnitario))) As ValorTotal'
      'From'
      '    (((Lancamentos Inner Join'
      
        '    TiposLancamentos On Lancamentos.IDTipo = TiposLancamentos.ID' +
        'Tipo) Inner Join'
      
        '    Produtos On Lancamentos.IDProduto = Produtos.IDProduto) Inne' +
        'r Join'
      
        '    ClientesFornecedores On Lancamentos.IDClienteFornecedor = Cl' +
        'ientesFornecedores.IDClienteFornecedor) Inner Join'
      '    Unidades On Lancamentos.IDUnidade = Unidades.IDUnidade,'
      '    Parametros'
      'Where'
      '    Lancamentos.DataLancamento >= Parametros.DataInicial And'
      '    Lancamentos.DataLancamento <= Parametros.DataFinal'
      'Order By'
      '    Produtos.Grupo,'
      '    Lancamentos.DataLancamento,'
      '    TiposLancamentos.OrdemRelatorio,'
      '    ClientesFornecedores.Nome,'
      '    Produtos.Descricao')
    Left = 200
    Top = 424
    object DateTimeField1: TDateTimeField
      Alignment = taCenter
      DisplayLabel = 'Data'
      FieldName = 'DataLancamento'
      DisplayFormat = 'dd/mm/yy'
    end
    object WideStringField1: TWideStringField
      Alignment = taCenter
      FieldName = 'Tipo'
    end
    object WideStringField2: TWideStringField
      FieldName = 'Nome'
      Size = 200
    end
    object WideStringField3: TWideStringField
      FieldName = 'Produto'
      Size = 200
    end
    object IntegerField1: TIntegerField
      Alignment = taCenter
      FieldName = 'OrdemRelatorio'
    end
    object FloatField1: TFloatField
      FieldName = 'Qtde'
    end
    object BCDField1: TBCDField
      DisplayLabel = 'Valor Unit'#225'rio'
      FieldName = 'ValorUnitario'
      DisplayFormat = '###,###,##0.00'
      Precision = 19
    end
    object FloatField2: TFloatField
      DisplayLabel = 'Valor Total'
      FieldName = 'ValorTotal'
      ReadOnly = True
      DisplayFormat = '###,###,##0.00'
    end
    object WideStringField4: TWideStringField
      FieldName = 'Obs'
      Size = 255
    end
    object AutoIncField1: TAutoIncField
      FieldName = 'IDLancamento'
      ReadOnly = True
    end
    object WideStringField5: TWideStringField
      Alignment = taCenter
      FieldName = 'Unidade'
    end
    object qyLancamentosPeriodoGrupo: TWideStringField
      FieldName = 'Grupo'
    end
    object qyLancamentosPeriodoSomarDeduzir: TWideStringField
      FieldName = 'SomarDeduzir'
      Size = 10
    end
  end
  object dsqyLancamentosPeriodo: TDataSource
    DataSet = qyLancamentosPeriodo
    Left = 200
    Top = 480
  end
  object dsqyQtdesPorPeriodo: TDataSource
    DataSet = qyQtdesPorPeriodo
    Left = 352
    Top = 480
  end
  object qyValoresPorPeriodo: TADOQuery
    Connection = ConexaoMDB
    CursorType = ctStatic
    Parameters = <>
    SQL.Strings = (
      'Select'
      '    Produtos.Descricao As Descricao,'
      
        '    Sum(Lancamentos.Qtde * Lancamentos.ValorUnitario) As ValorTo' +
        'tal'
      'From'
      '    ((Lancamentos Inner Join'
      
        '    Produtos On Produtos.IDProduto = Lancamentos.IDProduto) Inne' +
        'r Join'
      
        '    TiposLancamentos On TiposLancamentos.IDTipo = Lancamentos.ID' +
        'Tipo) Inner Join'
      '    Parametros On Parametros.Grupo = Produtos.Grupo'
      'Where'
      '    TiposLancamentos.Descricao = '#39'Venda'#39' And'
      '    Lancamentos.DataLancamento >= Parametros.DataInicial And'
      '    Lancamentos.DataLancamento <= Parametros.DataFinal'
      'Group By'
      '    TiposLancamentos.Descricao,'
      '    Produtos.Descricao')
    Left = 472
    Top = 424
    object qyValoresPorPeriodoDescricao: TWideStringField
      FieldName = 'Descricao'
      Size = 200
    end
    object qyValoresPorPeriodoValorTotal: TFloatField
      FieldName = 'ValorTotal'
    end
  end
  object dsqyValoresPorPeriodo: TDataSource
    DataSet = qyValoresPorPeriodo
    Left = 472
    Top = 480
  end
  object qySomatoriaTiposLancamento: TADOQuery
    Connection = ConexaoMDB
    CursorType = ctStatic
    Parameters = <>
    SQL.Strings = (
      'Select'
      '    TiposLancamentos.Descricao,'
      
        '    Sum(Lancamentos.Qtde * Abs(Lancamentos.ValorUnitario)) As Va' +
        'lorTotal,'
      '    Produtos.Grupo'
      'From'
      '    ((Lancamentos Inner Join'
      
        '    TiposLancamentos On Lancamentos.IDTipo = TiposLancamentos.ID' +
        'Tipo) Inner Join'
      
        '    Produtos On Produtos.IDProduto = Lancamentos.IDProduto) Inne' +
        'r Join'
      '    Parametros On Parametros.Grupo = Produtos.Grupo'
      'Where'
      '    Lancamentos.DataLancamento >= Parametros.DataInicial And'
      '    Lancamentos.DataLancamento <= Parametros.DataFinal'
      'Group By'
      '    TiposLancamentos.Descricao,'
      '    Produtos.Grupo')
    Left = 616
    Top = 424
    object qySomatoriaTiposLancamentoDescricao: TWideStringField
      FieldName = 'Descricao'
    end
    object qySomatoriaTiposLancamentoValorTotal: TFloatField
      FieldName = 'ValorTotal'
      DisplayFormat = '###,###,##0.00'
    end
    object qySomatoriaTiposLancamentoGrupo: TWideStringField
      FieldName = 'Grupo'
    end
  end
  object dsqySomatoriaTiposLancamento: TDataSource
    DataSet = qySomatoriaTiposLancamento
    Left = 616
    Top = 480
  end
  object tabGraficoResultado: TADOTable
    Connection = ConexaoMDB
    CursorType = ctStatic
    TableName = 'GraficoResultado'
    Left = 168
    Top = 216
    object tabGraficoResultadoDescricao: TWideStringField
      FieldName = 'Descricao'
      Size = 50
    end
    object tabGraficoResultadoValorTotal: TFloatField
      FieldName = 'ValorTotal'
    end
  end
  object dsGraficoResultado: TDataSource
    DataSet = tabGraficoResultado
    Left = 168
    Top = 272
  end
  object qyGraficoResultado: TADOQuery
    Connection = ConexaoMDB
    CursorType = ctStatic
    Parameters = <>
    SQL.Strings = (
      'SELECT'
      '  GraficoResultado.Descricao,'
      '  GraficoResultado.ValorTotal,'
      '  GraficoResultado.Mostrar'
      'FROM'
      '  GraficoResultado'
      'WHERE'
      '  GraficoResultado.Mostrar = '#39'Sim'#39)
    Left = 776
    Top = 424
    object qyGraficoResultadoDescricao: TWideStringField
      FieldName = 'Descricao'
      Size = 50
    end
    object qyGraficoResultadoValorTotal: TFloatField
      FieldName = 'ValorTotal'
    end
  end
  object dsqyGraficoResultado: TDataSource
    DataSet = qyGraficoResultado
    Left = 776
    Top = 480
  end
  object tabRelatorioResultado: TADOTable
    Connection = ConexaoMDB
    CursorType = ctStatic
    TableName = 'RelatorioResultado'
    Left = 280
    Top = 216
    object tabRelatorioResultadoVendas: TFloatField
      FieldName = 'Vendas'
    end
    object tabRelatorioResultadoDespesas: TFloatField
      FieldName = 'ComprasDespesas'
    end
    object tabRelatorioResultadoPerdas: TFloatField
      FieldName = 'Perdas'
    end
    object tabRelatorioResultadoResultado: TFloatField
      FieldName = 'Resultado'
    end
  end
  object dsRelatorioResultado: TDataSource
    DataSet = tabRelatorioResultado
    Left = 280
    Top = 272
  end
  object qyListagemCR: TADOQuery
    Connection = ConexaoMDB
    CursorType = ctStatic
    Parameters = <>
    SQL.Strings = (
      'Select'
      '    ListagemCR.OrdemRelatorio,'
      '    ListagemCR.IDClienteFornecedor,'
      '    ListagemCR.DataVencimento,'
      '    ListagemCR.AVista,'
      '    SomatoriaPagamentos.DataPagamento,'
      '    ListagemCR.Nome,'
      '    ListagemCR.ControleCR,'
      '    ListagemCR.TipoLanc,'
      '    ListagemCR.Cidade,'
      '    ListagemCR.Dias,'
      '    ListagemCR.IDDetalhe,'
      '    ListagemCR.ValorTotal,'
      
        '    Sum(IIF(ListagemCR.AVista = '#39'Sim'#39', ListagemCR.ValorTotal, II' +
        'F(SomatoriaPagamentos.TotalPago > 0,'
      '    SomatoriaPagamentos.TotalPago, 0))) As TotalPago,'
      
        '    IIF(ListagemCR.AVista = '#39'Sim'#39', 0, ListagemCR.ValorTotal - II' +
        'F(SomatoriaPagamentos.TotalPago > 0,'
      '    SomatoriaPagamentos.TotalPago, 0)) As Saldo,'
      
        '    IIF(ListagemCR.Dias <> '#39#39' And IIF(ListagemCR.AVista = '#39'Sim'#39',' +
        ' 0, ListagemCR.ValorTotal -'
      
        '    IIF(SomatoriaPagamentos.TotalPago > 0, SomatoriaPagamentos.T' +
        'otalPago, 0)) > 0, '#39'Sim'#39', '#39#39') As Atraso'
      'From'
      '    (Select'
      '         ClientesFornecedores.IDClienteFornecedor,'
      '         ClientesFornecedores.Nome,'
      '         Lancamentos.DataVencimento,'
      '         TiposLancamentos.ControleCR,'
      '         TiposLancamentos.Descricao As TipoLanc,'
      
        '         Sum(Abs(Lancamentos.Qtde * Lancamentos.ValorUnitario)) ' +
        'As ValorTotal,'
      
        '         ClientesFornecedores.[Endereco_cidade] + '#39' - '#39' + Client' +
        'esFornecedores.[Endereco_UF] As Cidade,'
      
        '         IIF(Date() - Lancamentos.DataVencimento > 0, Date() - L' +
        'ancamentos.DataVencimento, '#39#39') As Dias,'
      
        '         Str(ClientesFornecedores.IDClienteFornecedor) + '#39' - '#39' +' +
        ' TiposLancamentos.Descricao + '#39' - '#39' +'
      '         Str(Lancamentos.DataVencimento) As IDDetalhe,'
      '         TiposLancamentos.OrdemRelatorio,'
      
        '         IIF(Lancamentos.DataLancamento = Lancamentos.DataVencim' +
        'ento, '#39'Sim'#39', '#39'N'#227'o'#39') As AVista'
      '     From'
      '         ((Lancamentos Inner Join'
      
        '         TiposLancamentos On TiposLancamentos.IDTipo = Lancament' +
        'os.IDTipo) Inner Join'
      
        '         ClientesFornecedores On ClientesFornecedores.IDClienteF' +
        'ornecedor = Lancamentos.IDClienteFornecedor) Inner Join'
      '         Produtos On Produtos.IDProduto = Lancamentos.IDProduto'
      '     Where'
      '         TiposLancamentos.ControleCR = '#39'Sim'#39
      '     Group By'
      '         ClientesFornecedores.IDClienteFornecedor,'
      '         ClientesFornecedores.Nome,'
      '         Lancamentos.DataVencimento,'
      '         TiposLancamentos.ControleCR,'
      '         TiposLancamentos.Descricao,'
      
        '         ClientesFornecedores.[Endereco_cidade] + '#39' - '#39' + Client' +
        'esFornecedores.[Endereco_UF],'
      
        '         IIF(Date() - Lancamentos.DataVencimento > 0, Date() - L' +
        'ancamentos.DataVencimento, '#39#39'),'
      
        '         Str(ClientesFornecedores.IDClienteFornecedor) + '#39' - '#39' +' +
        ' TiposLancamentos.Descricao + '#39' - '#39' +'
      '         Str(Lancamentos.DataVencimento),'
      '         TiposLancamentos.OrdemRelatorio,'
      
        '         IIF(Lancamentos.DataLancamento = Lancamentos.DataVencim' +
        'ento, '#39'Sim'#39', '#39'N'#227'o'#39')) ListagemCR Left Join'
      '    (Select'
      '         Pagamentos.IDDetalhe,'
      '         Sum(Pagamentos.ValorPago) As TotalPago,'
      '         Pagamentos.DataPagamento'
      '     From'
      '         Pagamentos'
      '     Group By'
      '         Pagamentos.IDDetalhe,'
      
        '         Pagamentos.DataPagamento) SomatoriaPagamentos On Somato' +
        'riaPagamentos.IDDetalhe = ListagemCR.IDDetalhe'
      'Group By'
      '    ListagemCR.OrdemRelatorio,'
      '    ListagemCR.IDClienteFornecedor,'
      '    ListagemCR.DataVencimento,'
      '    ListagemCR.AVista,'
      '    SomatoriaPagamentos.DataPagamento,'
      '    ListagemCR.Nome,'
      '    ListagemCR.ControleCR,'
      '    ListagemCR.TipoLanc,'
      '    ListagemCR.Cidade,'
      '    ListagemCR.Dias,'
      '    ListagemCR.IDDetalhe,'
      '    ListagemCR.ValorTotal,'
      
        '    IIF(ListagemCR.AVista = '#39'Sim'#39', 0, ListagemCR.ValorTotal - II' +
        'F(SomatoriaPagamentos.TotalPago > 0,'
      '    SomatoriaPagamentos.TotalPago, 0)),'
      
        '    IIF(ListagemCR.Dias <> '#39#39' And IIF(ListagemCR.AVista = '#39'Sim'#39',' +
        ' 0, ListagemCR.ValorTotal -'
      
        '    IIF(SomatoriaPagamentos.TotalPago > 0, SomatoriaPagamentos.T' +
        'otalPago, 0)) > 0, '#39'Sim'#39', '#39#39')'
      'Order By'
      '    ListagemCR.OrdemRelatorio,'
      '    ListagemCR.DataVencimento,'
      '    ListagemCR.Nome')
    Left = 72
    Top = 568
    object qyListagemCRIDClienteFornecedor: TAutoIncField
      FieldName = 'IDClienteFornecedor'
      ReadOnly = True
    end
    object qyListagemCRNome: TWideStringField
      FieldName = 'Nome'
      Size = 200
    end
    object qyListagemCRDataVencimento: TDateTimeField
      Alignment = taCenter
      FieldName = 'DataVencimento'
      DisplayFormat = 'dd/mm/yy'
    end
    object qyListagemCRControleCR: TWideStringField
      FieldName = 'ControleCR'
      Size = 3
    end
    object qyListagemCRCidade: TWideStringField
      FieldName = 'Cidade'
      Size = 255
    end
    object qyListagemCRDias: TWideStringField
      Alignment = taCenter
      FieldName = 'Dias'
      Size = 255
    end
    object qyListagemCRTipoLanc: TWideStringField
      FieldName = 'TipoLanc'
    end
    object qyListagemCRIDDetalhe: TWideStringField
      FieldName = 'IDDetalhe'
      Size = 255
    end
    object qyListagemCRValorTotal: TFloatField
      FieldName = 'ValorTotal'
      DisplayFormat = '###,###,##0.00'
    end
    object qyListagemCRTotalPago: TFloatField
      FieldName = 'TotalPago'
      ReadOnly = True
      DisplayFormat = '###,###,##0.00'
    end
    object qyListagemCRSaldo: TFloatField
      FieldName = 'Saldo'
      ReadOnly = True
      DisplayFormat = '###,###,##0.00'
    end
    object qyListagemCRAVista: TWideStringField
      Alignment = taCenter
      FieldName = 'AVista'
      Size = 255
    end
    object qyListagemCRDataPagamento: TDateTimeField
      FieldName = 'DataPagamento'
    end
    object qyListagemCRAtraso: TWideStringField
      Alignment = taCenter
      FieldName = 'Atraso'
      Size = 255
    end
  end
  object dsqyListagemCR: TDataSource
    DataSet = qyListagemCR
    Left = 72
    Top = 624
  end
  object tabPagamentos: TADOTable
    Connection = ConexaoMDB
    CursorType = ctStatic
    BeforePost = tabPagamentosBeforePost
    IndexFieldNames = 'DataPagamento'
    TableName = 'Pagamentos'
    Left = 400
    Top = 216
    object tabPagamentosID: TAutoIncField
      FieldName = 'ID'
      ReadOnly = True
    end
    object tabPagamentosDataPagamento: TDateTimeField
      Alignment = taCenter
      FieldName = 'DataPagamento'
      DisplayFormat = 'dd/mm/yyyy'
      EditMask = '!99/99/0000;1;_'
    end
    object tabPagamentosValorPago: TFloatField
      FieldName = 'ValorPago'
      DisplayFormat = '###,###,##0.00'
    end
    object tabPagamentosIDDetalhe: TWideStringField
      FieldName = 'IDDetalhe'
      Size = 100
    end
  end
  object dsPagamentos: TDataSource
    DataSet = tabPagamentos
    Left = 400
    Top = 272
  end
  object tabSimNao: TADOTable
    Connection = ConexaoMDB
    CursorType = ctStatic
    TableName = 'SimNao'
    Left = 488
    Top = 216
    object tabSimNaoOpcao: TWideStringField
      FieldName = 'Opcao'
      Size = 3
    end
  end
  object dsSimNao: TDataSource
    DataSet = tabSimNao
    Left = 488
    Top = 272
  end
  object tabGrupos: TADOTable
    Connection = ConexaoMDB
    CursorType = ctStatic
    TableName = 'Grupos'
    Left = 744
    Top = 80
    object tabGruposID: TAutoIncField
      FieldName = 'ID'
      ReadOnly = True
    end
    object tabGruposGrupo: TWideStringField
      FieldName = 'Grupo'
    end
  end
  object dsGrupos: TDataSource
    DataSet = tabGrupos
    Left = 744
    Top = 136
  end
  object qyTiposParaCR: TADOQuery
    Connection = ConexaoMDB
    CursorType = ctStatic
    Parameters = <>
    SQL.Strings = (
      'Select'
      '    TiposLancamentos.Descricao As Tipo'
      'From'
      '    TiposLancamentos'
      'Where'
      '    TiposLancamentos.ControleCR = '#39'Sim'#39)
    Left = 168
    Top = 568
    object qyTiposParaCRTipo: TWideStringField
      FieldName = 'Tipo'
    end
  end
  object dsqyTiposParaCR: TDataSource
    DataSet = qyTiposParaCR
    Left = 168
    Top = 624
  end
  object qySaldoDinamico: TADOQuery
    Connection = ConexaoMDB
    CursorType = ctStatic
    Parameters = <>
    SQL.Strings = (
      'Select'
      '    ListagemCR.IDClienteFornecedor,'
      '    ListagemCR.IDDetalhe,'
      '    Abs(ListagemCR.ValorTotal) As ValorTotal,'
      
        '    Sum(IIF(Abs(SomatoriaPagamentos.TotalPago) > 0, Abs(Somatori' +
        'aPagamentos.TotalPago), 0)) As TotalPago,'
      
        '    Abs(ListagemCR.ValorTotal) - IIF(Abs(SomatoriaPagamentos.Tot' +
        'alPago) > 0, Abs(SomatoriaPagamentos.TotalPago),'
      '    0) As Saldo'
      'From'
      '    (Select'
      '         ClientesFornecedores.IDClienteFornecedor,'
      '         ClientesFornecedores.Nome,'
      '         Lancamentos.DataVencimento,'
      '         TiposLancamentos.ControleCR,'
      '         TiposLancamentos.Descricao As TipoLanc,'
      
        '         Sum(Lancamentos.Qtde * Lancamentos.ValorUnitario) As Va' +
        'lorTotal,'
      
        '         ClientesFornecedores.[Endereco_cidade] + '#39' - '#39' + Client' +
        'esFornecedores.[Endereco_UF] As Cidade,'
      
        '         IIF(Date() - Lancamentos.DataVencimento > 0, Date() - L' +
        'ancamentos.DataVencimento, '#39#39') As Dias,'
      
        '         Str(ClientesFornecedores.IDClienteFornecedor) + '#39' - '#39' +' +
        ' TiposLancamentos.Descricao + '#39' - '#39' +'
      '         Str(Lancamentos.DataVencimento) As IDDetalhe'
      '     From'
      '         ((Lancamentos Inner Join'
      
        '         TiposLancamentos On TiposLancamentos.IDTipo = Lancament' +
        'os.IDTipo) Inner Join'
      
        '         ClientesFornecedores On ClientesFornecedores.IDClienteF' +
        'ornecedor = Lancamentos.IDClienteFornecedor) Inner Join'
      '         Produtos On Produtos.IDProduto = Lancamentos.IDProduto'
      '     Where'
      '         TiposLancamentos.ControleCR = '#39'Sim'#39
      '     Group By'
      '         ClientesFornecedores.IDClienteFornecedor,'
      '         ClientesFornecedores.Nome,'
      '         Lancamentos.DataVencimento,'
      '         TiposLancamentos.ControleCR,'
      '         TiposLancamentos.Descricao,'
      
        '         ClientesFornecedores.[Endereco_cidade] + '#39' - '#39' + Client' +
        'esFornecedores.[Endereco_UF],'
      
        '         IIF(Date() - Lancamentos.DataVencimento > 0, Date() - L' +
        'ancamentos.DataVencimento, '#39#39'),'
      
        '         Str(ClientesFornecedores.IDClienteFornecedor) + '#39' - '#39' +' +
        ' TiposLancamentos.Descricao + '#39' - '#39' +'
      '         Str(Lancamentos.DataVencimento)) ListagemCR Left Join'
      '    (Select'
      '         Pagamentos.IDDetalhe,'
      '         Sum(Pagamentos.ValorPago) As TotalPago'
      '     From'
      '         Pagamentos'
      '     Group By'
      
        '         Pagamentos.IDDetalhe) SomatoriaPagamentos On SomatoriaP' +
        'agamentos.IDDetalhe = ListagemCR.IDDetalhe'
      'Group By'
      '    ListagemCR.IDClienteFornecedor,'
      '    ListagemCR.IDDetalhe,'
      '    Abs(ListagemCR.ValorTotal),'
      
        '    Abs(ListagemCR.ValorTotal) - IIF(Abs(SomatoriaPagamentos.Tot' +
        'alPago) > 0, Abs(SomatoriaPagamentos.TotalPago), 0)')
    Left = 264
    Top = 568
    object qySaldoDinamicoIDDetalhe: TWideStringField
      FieldName = 'IDDetalhe'
      Size = 255
    end
    object qySaldoDinamicoValorTotal: TFloatField
      FieldName = 'ValorTotal'
      DisplayFormat = '###,###,##0.00'
    end
    object qySaldoDinamicoTotalPago: TFloatField
      FieldName = 'TotalPago'
      DisplayFormat = '###,###,##0.00'
    end
    object qySaldoDinamicoSaldo: TFloatField
      FieldName = 'Saldo'
      DisplayFormat = '###,###,##0.00'
    end
  end
  object dsqySaldoDinamico: TDataSource
    DataSet = qySaldoDinamico
    Left = 264
    Top = 624
  end
  object tabAuxVencimentos: TADOTable
    Connection = ConexaoMDB
    CursorType = ctStatic
    TableName = 'AuxVencimentos'
    Left = 584
    Top = 216
    object tabAuxVencimentosAtraso: TWideStringField
      FieldName = 'Atraso'
      Size = 5
    end
    object tabAuxVencimentosTipo: TWideStringField
      FieldName = 'Tipo'
    end
    object tabAuxVencimentosNome: TWideStringField
      FieldName = 'Nome'
      Size = 150
    end
    object tabAuxVencimentosVencimento: TDateTimeField
      FieldName = 'Vencimento'
    end
    object tabAuxVencimentosDias: TWideStringField
      FieldName = 'Dias'
      Size = 8
    end
    object tabAuxVencimentosTotalDevido: TFloatField
      FieldName = 'TotalDevido'
    end
    object tabAuxVencimentosTotalPago: TFloatField
      FieldName = 'TotalPago'
    end
    object tabAuxVencimentosSaldo: TFloatField
      FieldName = 'Saldo'
    end
  end
  object dsAuxVencimentos: TDataSource
    DataSet = tabAuxVencimentos
    Left = 584
    Top = 272
  end
  object tabSomarDeduzir: TADOTable
    Connection = ConexaoMDB
    CursorType = ctStatic
    TableName = 'SomarDeduzir'
    Left = 696
    Top = 216
    object tabSomarDeduzirSomarDeduzir: TWideStringField
      Alignment = taCenter
      FieldName = 'SomarDeduzir'
      Size = 1
    end
  end
  object dsSomarDeduzir: TDataSource
    DataSet = tabSomarDeduzir
    Left = 696
    Top = 272
  end
  object tabLogin: TADOTable
    Connection = ConexaoMDB
    CursorType = ctStatic
    TableName = 'Login'
    Left = 808
    Top = 80
    object tabLoginSenha: TWideStringField
      FieldName = 'Senha'
      Size = 50
    end
  end
  object dsLogin: TDataSource
    DataSet = tabLogin
    Left = 808
    Top = 136
  end
  object qyQtdesPorPeriodo: TADOQuery
    Connection = ConexaoMDB
    CursorType = ctStatic
    Parameters = <>
    SQL.Strings = (
      'Select'
      '    Produtos.Descricao As Produto,'
      '    Sum(Lancamentos.Qtde) As Qtde'
      'From'
      '    ((Lancamentos Inner Join'
      
        '    Produtos On Produtos.IDProduto = Lancamentos.IDProduto) Inne' +
        'r Join'
      
        '    TiposLancamentos On TiposLancamentos.IDTipo = Lancamentos.ID' +
        'Tipo) Inner Join'
      '    Parametros On Parametros.Grupo = Produtos.Grupo'
      'Where'
      '    TiposLancamentos.Descricao = '#39'Venda'#39' And'
      '    Lancamentos.DataLancamento >= Parametros.DataInicial And'
      '    Lancamentos.DataLancamento <= Parametros.DataFinal'
      'Group By'
      '    TiposLancamentos.Descricao,'
      '    Produtos.Descricao')
    Left = 352
    Top = 424
    object qyQtdesPorPeriodoProduto: TWideStringField
      FieldName = 'Produto'
      Size = 200
    end
    object qyQtdesPorPeriodoQtde: TFloatField
      FieldName = 'Qtde'
    end
  end
  object qyTreeComSaldos: TADOQuery
    Connection = ConexaoMDB
    CursorType = ctStatic
    Parameters = <>
    SQL.Strings = (
      'Select'
      '    ListagemCR.TipoLanc,'
      '    Mid(ListagemCR.DataVencimento, 7, 4) As Ano,'
      '    Mid(ListagemCR.DataVencimento, 4, 2) As Mes,'
      '    ListagemCR.DataVencimento,'
      '    ListagemCR.Nome,'
      '    ListagemCR.ValorTotal,'
      
        '    Sum(IIF(ListagemCR.AVista = '#39'Sim'#39', ListagemCR.ValorTotal, II' +
        'F(SomatoriaPagamentos.TotalPago > 0,'
      '    SomatoriaPagamentos.TotalPago, 0))) As TotalPago,'
      
        '    IIF(ListagemCR.AVista = '#39'Sim'#39', 0, ListagemCR.ValorTotal - II' +
        'F(SomatoriaPagamentos.TotalPago > 0,'
      '    SomatoriaPagamentos.TotalPago, 0)) As Saldo'
      'From'
      '    (Select'
      '         ClientesFornecedores.IDClienteFornecedor,'
      '         ClientesFornecedores.Nome,'
      '         Lancamentos.DataVencimento,'
      '         TiposLancamentos.ControleCR,'
      '         TiposLancamentos.Descricao As TipoLanc,'
      
        '         Sum(Abs(Lancamentos.Qtde * Lancamentos.ValorUnitario)) ' +
        'As ValorTotal,'
      
        '         ClientesFornecedores.[Endereco_cidade] + '#39' - '#39' + Client' +
        'esFornecedores.[Endereco_UF] As Cidade,'
      
        '         IIF(Date() - Lancamentos.DataVencimento > 0, Date() - L' +
        'ancamentos.DataVencimento, '#39#39') As Dias,'
      
        '         Str(ClientesFornecedores.IDClienteFornecedor) + '#39' - '#39' +' +
        ' TiposLancamentos.Descricao + '#39' - '#39' +'
      '         Str(Lancamentos.DataVencimento) As IDDetalhe,'
      '         TiposLancamentos.OrdemRelatorio,'
      
        '         IIF(Lancamentos.DataLancamento = Lancamentos.DataVencim' +
        'ento, '#39'Sim'#39', '#39'N'#227'o'#39') As AVista'
      '     From'
      '         ((Lancamentos Inner Join'
      
        '         TiposLancamentos On TiposLancamentos.IDTipo = Lancament' +
        'os.IDTipo) Inner Join'
      
        '         ClientesFornecedores On ClientesFornecedores.IDClienteF' +
        'ornecedor = Lancamentos.IDClienteFornecedor) Inner Join'
      '         Produtos On Produtos.IDProduto = Lancamentos.IDProduto'
      '     Where'
      '         TiposLancamentos.ControleCR = '#39'Sim'#39
      '     Group By'
      '         ClientesFornecedores.IDClienteFornecedor,'
      '         ClientesFornecedores.Nome,'
      '         Lancamentos.DataVencimento,'
      '         TiposLancamentos.ControleCR,'
      '         TiposLancamentos.Descricao,'
      
        '         ClientesFornecedores.[Endereco_cidade] + '#39' - '#39' + Client' +
        'esFornecedores.[Endereco_UF],'
      
        '         IIF(Date() - Lancamentos.DataVencimento > 0, Date() - L' +
        'ancamentos.DataVencimento, '#39#39'),'
      
        '         Str(ClientesFornecedores.IDClienteFornecedor) + '#39' - '#39' +' +
        ' TiposLancamentos.Descricao + '#39' - '#39' +'
      '         Str(Lancamentos.DataVencimento),'
      '         TiposLancamentos.OrdemRelatorio,'
      
        '         IIF(Lancamentos.DataLancamento = Lancamentos.DataVencim' +
        'ento, '#39'Sim'#39', '#39'N'#227'o'#39')) ListagemCR Left Join'
      '    (Select'
      '         Pagamentos.IDDetalhe,'
      '         Sum(Pagamentos.ValorPago) As TotalPago'
      '     From'
      '         Pagamentos'
      '     Group By'
      
        '         Pagamentos.IDDetalhe) SomatoriaPagamentos On SomatoriaP' +
        'agamentos.IDDetalhe = ListagemCR.IDDetalhe'
      'Group By'
      '    ListagemCR.OrdemRelatorio,'
      '    ListagemCR.TipoLanc,'
      '    Mid(ListagemCR.DataVencimento, 7, 4),'
      '    Mid(ListagemCR.DataVencimento, 4, 2),'
      '    ListagemCR.DataVencimento,'
      '    ListagemCR.Nome,'
      '    ListagemCR.ValorTotal,'
      
        '    IIF(ListagemCR.AVista = '#39'Sim'#39', 0, ListagemCR.ValorTotal - II' +
        'F(SomatoriaPagamentos.TotalPago > 0,'
      '    SomatoriaPagamentos.TotalPago, 0)),'
      '    ListagemCR.Cidade,'
      '    ListagemCR.Dias,'
      '    ListagemCR.IDDetalhe,'
      '    ListagemCR.AVista'
      'Order By'
      '    ListagemCR.OrdemRelatorio,'
      '    Mid(ListagemCR.DataVencimento, 7, 4),'
      '    Mid(ListagemCR.DataVencimento, 4, 2),'
      '    ListagemCR.DataVencimento,'
      '    ListagemCR.Nome')
    Left = 384
    Top = 568
    object qyTreeComSaldosTipoLanc: TWideStringField
      FieldName = 'TipoLanc'
    end
    object qyTreeComSaldosAno: TWideStringField
      FieldName = 'Ano'
      Size = 255
    end
    object qyTreeComSaldosMes: TWideStringField
      FieldName = 'Mes'
      Size = 255
    end
    object qyTreeComSaldosNome: TWideStringField
      FieldName = 'Nome'
      Size = 200
    end
    object qyTreeComSaldosDataVencimento: TDateTimeField
      FieldName = 'DataVencimento'
      DisplayFormat = 'dd/mm/yy'
    end
    object qyTreeComSaldosValorTotal: TFloatField
      FieldName = 'ValorTotal'
      DisplayFormat = '###,###,##0.00'
    end
    object qyTreeComSaldosTotalPago: TFloatField
      FieldName = 'TotalPago'
      DisplayFormat = '###,###,##0.00'
    end
    object qyTreeComSaldosSaldo: TFloatField
      FieldName = 'Saldo'
      DisplayFormat = '###,###,##0.00'
    end
  end
  object dsqyTreeComSaldos: TDataSource
    DataSet = qyTreeComSaldos
    Left = 384
    Top = 624
  end
  object tabResultado: TADOTable
    Connection = ConexaoMDB
    CursorType = ctStatic
    TableName = 'Resultado'
    Left = 800
    Top = 216
    object tabResultadoID: TAutoIncField
      FieldName = 'ID'
      ReadOnly = True
    end
    object tabResultadoCredito: TFloatField
      FieldName = 'Credito'
      DisplayFormat = '###,###,##0.00'
    end
    object tabResultadoDebito: TFloatField
      FieldName = 'Debito'
      DisplayFormat = '###,###,##0.00'
    end
    object tabResultadoReferente: TWideStringField
      FieldName = 'Referente'
      Size = 200
    end
    object tabResultadoDiferente: TWideStringField
      FieldName = 'Diferente'
      Size = 3
    end
  end
  object dsResultado: TDataSource
    DataSet = tabResultado
    Left = 800
    Top = 272
  end
  object qyResultado: TADOQuery
    Connection = ConexaoMDB
    CursorType = ctStatic
    Parameters = <>
    SQL.Strings = (
      'Select'
      '    ListagemCR.OrdemRelatorio,'
      '    ListagemCR.IDClienteFornecedor,'
      '    ListagemCR.DataVencimento,'
      '    ListagemCR.AVista,'
      '    SomatoriaPagamentos.DataPagamento,'
      '    ListagemCR.Nome,'
      '    ListagemCR.ControleCR,'
      '    ListagemCR.TipoLanc,'
      '    ListagemCR.Cidade,'
      '    ListagemCR.Dias,'
      '    ListagemCR.IDDetalhe,'
      '    ListagemCR.ValorTotal,'
      
        '    Sum(IIF(ListagemCR.AVista = '#39'Sim'#39', ListagemCR.ValorTotal, II' +
        'F(SomatoriaPagamentos.TotalPago > 0,'
      '    SomatoriaPagamentos.TotalPago, 0))) As TotalPago,'
      
        '    IIF(ListagemCR.AVista = '#39'Sim'#39', 0, ListagemCR.ValorTotal - II' +
        'F(SomatoriaPagamentos.TotalPago > 0,'
      '    SomatoriaPagamentos.TotalPago, 0)) As Saldo'
      'From'
      '    (Select'
      '         ClientesFornecedores.IDClienteFornecedor,'
      '         ClientesFornecedores.Nome,'
      '         Lancamentos.DataVencimento,'
      '         TiposLancamentos.ControleCR,'
      '         TiposLancamentos.Descricao As TipoLanc,'
      
        '         Sum(Abs(Lancamentos.Qtde * Lancamentos.ValorUnitario)) ' +
        'As ValorTotal,'
      
        '         ClientesFornecedores.[Endereco_cidade] + '#39' - '#39' + Client' +
        'esFornecedores.[Endereco_UF] As Cidade,'
      
        '         IIF(Date() - Lancamentos.DataVencimento > 0, Date() - L' +
        'ancamentos.DataVencimento, '#39#39') As Dias,'
      
        '         Str(ClientesFornecedores.IDClienteFornecedor) + '#39' - '#39' +' +
        ' TiposLancamentos.Descricao + '#39' - '#39' +'
      '         Str(Lancamentos.DataVencimento) As IDDetalhe,'
      '         TiposLancamentos.OrdemRelatorio,'
      
        '         IIF(Lancamentos.DataLancamento = Lancamentos.DataVencim' +
        'ento, '#39'Sim'#39', '#39'N'#227'o'#39') As AVista'
      '     From'
      '         ((Lancamentos Inner Join'
      
        '         TiposLancamentos On TiposLancamentos.IDTipo = Lancament' +
        'os.IDTipo) Inner Join'
      
        '         ClientesFornecedores On ClientesFornecedores.IDClienteF' +
        'ornecedor = Lancamentos.IDClienteFornecedor) Inner Join'
      '         Produtos On Produtos.IDProduto = Lancamentos.IDProduto'
      '     Where'
      '         TiposLancamentos.ControleCR = '#39'Sim'#39
      '     Group By'
      '         ClientesFornecedores.IDClienteFornecedor,'
      '         ClientesFornecedores.Nome,'
      '         Lancamentos.DataVencimento,'
      '         TiposLancamentos.ControleCR,'
      '         TiposLancamentos.Descricao,'
      
        '         ClientesFornecedores.[Endereco_cidade] + '#39' - '#39' + Client' +
        'esFornecedores.[Endereco_UF],'
      
        '         IIF(Date() - Lancamentos.DataVencimento > 0, Date() - L' +
        'ancamentos.DataVencimento, '#39#39'),'
      
        '         Str(ClientesFornecedores.IDClienteFornecedor) + '#39' - '#39' +' +
        ' TiposLancamentos.Descricao + '#39' - '#39' +'
      '         Str(Lancamentos.DataVencimento),'
      '         TiposLancamentos.OrdemRelatorio,'
      
        '         IIF(Lancamentos.DataLancamento = Lancamentos.DataVencim' +
        'ento, '#39'Sim'#39', '#39'N'#227'o'#39')) ListagemCR Left Join'
      '    (Select'
      '         Pagamentos.IDDetalhe,'
      '         Sum(Pagamentos.ValorPago) As TotalPago,'
      '         Pagamentos.DataPagamento'
      '     From'
      '         Pagamentos'
      '     Group By'
      '         Pagamentos.IDDetalhe,'
      
        '         Pagamentos.DataPagamento) SomatoriaPagamentos On Somato' +
        'riaPagamentos.IDDetalhe = ListagemCR.IDDetalhe'
      'Group By'
      '    ListagemCR.OrdemRelatorio,'
      '    ListagemCR.IDClienteFornecedor,'
      '    ListagemCR.DataVencimento,'
      '    ListagemCR.AVista,'
      '    SomatoriaPagamentos.DataPagamento,'
      '    ListagemCR.Nome,'
      '    ListagemCR.ControleCR,'
      '    ListagemCR.TipoLanc,'
      '    ListagemCR.Cidade,'
      '    ListagemCR.Dias,'
      '    ListagemCR.IDDetalhe,'
      '    ListagemCR.ValorTotal,'
      
        '    IIF(ListagemCR.AVista = '#39'Sim'#39', 0, ListagemCR.ValorTotal - II' +
        'F(SomatoriaPagamentos.TotalPago > 0,'
      '    SomatoriaPagamentos.TotalPago, 0))'
      'Order By'
      '    ListagemCR.OrdemRelatorio,'
      '    ListagemCR.DataVencimento,'
      '    ListagemCR.Nome')
    Left = 504
    Top = 568
    object AutoIncField2: TAutoIncField
      FieldName = 'IDClienteFornecedor'
      ReadOnly = True
    end
    object WideStringField6: TWideStringField
      FieldName = 'Nome'
      Size = 200
    end
    object DateTimeField2: TDateTimeField
      Alignment = taCenter
      FieldName = 'DataVencimento'
      DisplayFormat = 'dd/mm/yy'
    end
    object WideStringField7: TWideStringField
      FieldName = 'ControleCR'
      Size = 3
    end
    object WideStringField8: TWideStringField
      FieldName = 'Cidade'
      Size = 255
    end
    object WideStringField9: TWideStringField
      Alignment = taCenter
      FieldName = 'Dias'
      Size = 255
    end
    object WideStringField10: TWideStringField
      FieldName = 'TipoLanc'
    end
    object WideStringField11: TWideStringField
      FieldName = 'IDDetalhe'
      Size = 255
    end
    object FloatField3: TFloatField
      FieldName = 'ValorTotal'
      DisplayFormat = '###,###,##0.00'
    end
    object FloatField4: TFloatField
      FieldName = 'TotalPago'
      ReadOnly = True
      DisplayFormat = '###,###,##0.00'
    end
    object FloatField5: TFloatField
      FieldName = 'Saldo'
      ReadOnly = True
      DisplayFormat = '###,###,##0.00'
    end
    object StringField1: TStringField
      Alignment = taCenter
      FieldKind = fkCalculated
      FieldName = 'Atraso'
      Size = 5
      Calculated = True
    end
    object WideStringField12: TWideStringField
      Alignment = taCenter
      FieldName = 'AVista'
      Size = 255
    end
    object DateTimeField3: TDateTimeField
      FieldName = 'DataPagamento'
    end
  end
  object dsqyResultado: TDataSource
    DataSet = qyResultado
    Left = 504
    Top = 624
  end
end
