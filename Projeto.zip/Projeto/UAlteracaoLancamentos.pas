unit UAlteracaoLancamentos;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, DBCtrls, StdCtrls, Mask, JvExMask, JvToolEdit, JvMaskEdit,
  JvCheckedMaskEdit, JvDatePickerEdit, JvDBDatePickerEdit, Buttons, ExtCtrls, DB,
  ImgList;

type
  TformAlteracaoLancamentos = class(TForm)
    Label1: TLabel;
    campoClienteFornecedor: TDBLookupComboBox;
    Label3: TLabel;
    campoProduto: TDBLookupComboBox;
    Label4: TLabel;
    Label5: TLabel;
    campoQtde: TDBEdit;
    DBEdit3: TDBEdit;
    Panel1: TPanel;
    Button1: TButton;
    Button2: TButton;
    ImageList1: TImageList;
    Button3: TButton;
    campoUnidade: TDBLookupComboBox;
    Label9: TLabel;
    SpeedButton4: TSpeedButton;
    SpeedButton3: TSpeedButton;
    SpeedButton2: TSpeedButton;
    pnlSuperior: TPanel;
    Label10: TLabel;
    SpeedButton5: TSpeedButton;
    campoTipo: TDBLookupComboBox;
    Label2: TLabel;
    SpeedButton8: TSpeedButton;
    SpeedButton9: TSpeedButton;
    SpeedButton6: TSpeedButton;
    SpeedButton7: TSpeedButton;
    Label7: TLabel;
    Label8: TLabel;
    Label11: TLabel;
    campoUnitario: TDBEdit;
    campoValorTotal: TDBEdit;
    Label12: TLabel;
    campoValorBase: TEdit;
    campoData: TJvDBDatePickerEdit;
    campoDataVencimento: TJvDBDatePickerEdit;
    procedure FormKeyPress(Sender: TObject; var Key: Char);
    procedure campoQtdeExit(Sender: TObject);
    procedure campoUnitarioExit(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure SpeedButton1Click(Sender: TObject);
    procedure SpeedButton2Click(Sender: TObject);
    procedure SpeedButton3Click(Sender: TObject);
    procedure SpeedButton4Click(Sender: TObject);
    procedure SpeedButton8Click(Sender: TObject);
    procedure SpeedButton9Click(Sender: TObject);
    procedure SpeedButton6Click(Sender: TObject);
    procedure SpeedButton7Click(Sender: TObject);
    procedure campoUnitarioEnter(Sender: TObject);
    procedure campoDataExit(Sender: TObject);
    procedure campoDataVencimentoExit(Sender: TObject);
  private
    { Private declarations }
    function DataValida(D: TDateTime): Boolean;
    procedure AtualizarValorTotal;
  public
    { Public declarations }
  end;

var
  formAlteracaoLancamentos: TformAlteracaoLancamentos;

implementation

uses UDM, UCadastroClientesFornecedores, UCadastroProdutos,
  UCadastroTiposLancamento, UCadastroUnidades, UCadastros;

{$R *.dfm}

// Aceita apenas datas plausiveis (ano com 4 digitos). Rejeita data vazia
// (TDateTime = 0 / NullDate) e anos como 0026, que corrompem o banco Jet.
function TformAlteracaoLancamentos.DataValida(D: TDateTime): Boolean;
begin
  Result := (D >= EncodeDate(1900, 1, 1)) and (D <= EncodeDate(2200, 12, 31));
end;

procedure TformAlteracaoLancamentos.AtualizarValorTotal;
begin
  if not (DM.tabLancamentos.State in [dsInsert, dsEdit]) then
    DM.tabLancamentos.Edit;
  // AsFloat/AsCurrency tratam campo vazio como 0 (sem erro de variant Null)
  DM.tabLancamentos.FieldByName('ValorTotal').AsCurrency :=
    DM.tabLancamentos.FieldByName('Qtde').AsFloat *
    DM.tabLancamentos.FieldByName('ValorUnitario').AsCurrency;
end;

procedure TformAlteracaoLancamentos.campoDataExit(Sender: TObject);
begin

  if (campoData.Text <> '') and ((Date - campoData.Date > 90) or (campoData.Date - Date > 90))   then
  begin
    ShowMessage('A data parece estar inconsistente! Verifique por favor.');
  end;

end;

procedure TformAlteracaoLancamentos.campoDataVencimentoExit(Sender: TObject);
begin

  if (campoDataVencimento.Text <> '') and ((Date - campoDataVencimento.Date > 90) or (campoDataVencimento.Date - Date > 90))   then
  begin
    ShowMessage('A data parece estar inconsistente! Verifique por favor.');
  end;

end;

procedure TformAlteracaoLancamentos.campoQtdeExit(Sender: TObject);
begin

  AtualizarValorTotal;

end;

procedure TformAlteracaoLancamentos.campoUnitarioEnter(Sender: TObject);
begin

  //Localizando o valor unit�rio do produto
  if DM.tabProdutos.Locate('IDProduto',DM.tabLancamentos.FieldByName('IDProduto').Value,[]) = true then
  begin
    DM.tabProdutos.Locate('IDProduto',DM.tabLancamentos.FieldByName('IDProduto').Value,[]);
    if DM.tabProdutos.FieldByName('ValorBase').AsString <> '' then
    begin
      DM.tabLancamentos.FieldByName('ValorUnitario').Value := DM.tabProdutos.FieldByName('ValorBase').Value;
      campoValorBase.Text := FormatFloat('###,###,##0.00',DM.tabProdutos.FieldByName('ValorBase').Value);
    end
    else
    begin
      DM.tabLancamentos.FieldByName('ValorUnitario').Value := 0;
      campoValorBase.Text := FormatFloat('###,###,##0.00',0);
    end;
  end;


end;

procedure TformAlteracaoLancamentos.campoUnitarioExit(Sender: TObject);
begin

  AtualizarValorTotal;

end;

procedure TformAlteracaoLancamentos.FormKeyPress(Sender: TObject; var Key: Char);
begin

  if Key = #13 then
  begin
    Key := #0;
    PostMessage(Handle, WM_NEXTDLGCTL, 0, 0);
  end;

end;

procedure TformAlteracaoLancamentos.FormShow(Sender: TObject);
begin

  AtualizarValorTotal;

end;

procedure TformAlteracaoLancamentos.SpeedButton1Click(Sender: TObject);
begin

  //formCadastroTiposLancamento.ShowModal;
  formCadastros.ShowModal;


end;

procedure TformAlteracaoLancamentos.SpeedButton2Click(Sender: TObject);
begin

  //formCadastroClientesFornecedores.ShowModal;
  formCadastros.ShowModal;


end;

procedure TformAlteracaoLancamentos.SpeedButton3Click(Sender: TObject);
begin

  //formCadastroProdutos.ShowModal;
  formCadastros.ShowModal;


end;

procedure TformAlteracaoLancamentos.SpeedButton4Click(Sender: TObject);
begin

  //formCadastroUnidades.ShowModal;
  formCadastros.ShowModal;


end;

procedure TformAlteracaoLancamentos.SpeedButton6Click(Sender: TObject);
begin

  if DataValida(campoData.Date) then
  begin
    DM.tabLancamentos.FieldByName('DataVencimento').Value := campoData.Date + 60;
  end;


end;

procedure TformAlteracaoLancamentos.SpeedButton7Click(Sender: TObject);
begin

  if DataValida(campoData.Date) then
  begin
    DM.tabLancamentos.FieldByName('DataVencimento').Value := campoData.Date + 90;
  end;


end;

procedure TformAlteracaoLancamentos.SpeedButton8Click(Sender: TObject);
begin

  if DataValida(campoData.Date) then
  begin
    DM.tabLancamentos.FieldByName('DataVencimento').Value := campoData.Date;
  end;


end;

procedure TformAlteracaoLancamentos.SpeedButton9Click(Sender: TObject);
begin

  if DataValida(campoData.Date) then
  begin
    DM.tabLancamentos.FieldByName('DataVencimento').Value := campoData.Date + 30;
  end;


end;

procedure TformAlteracaoLancamentos.Button1Click(Sender: TObject);
begin

  // Verifica se h� algum campo obrigat�rio em branco

  if campoData.text = '' then
  begin
    ShowMessage('O campo DATA � obrigat�rio.');
    campoData.SetFocus;
    campoData.Color := $0000ECFF;
    Abort;
  end
  else
  begin
    campoData.Color := clWindow;
  end;
  if campoDataVencimento.text = '' then
  begin
    ShowMessage('O campo VENCIMENTO � obrigat�rio.');
    campoDataVencimento.SetFocus;
    campoDataVencimento.Color := $0000ECFF;
    Abort;
  end
  else
  begin
    campoDataVencimento.Color := clWindow;
  end;
  if not DataValida(campoData.Date) then
  begin
    ShowMessage('O campo DATA est� inv�lida.' + #13 + 'Informe o ano com 4 d�gitos (ex.: 10/11/2026).');
    campoData.SetFocus;
    campoData.Color := $0000ECFF;
    Abort;
  end;
  if not DataValida(campoDataVencimento.Date) then
  begin
    ShowMessage('O campo VENCIMENTO est� inv�lido.' + #13 + 'Informe o ano com 4 d�gitos (ex.: 10/11/2026).');
    campoDataVencimento.SetFocus;
    campoDataVencimento.Color := $0000ECFF;
    Abort;
  end;
  if campoTipo.text = '' then
  begin
    ShowMessage('O campo TIPO DE LAN�AMENTO � obrigat�rio.');
    campoTipo.SetFocus;
    campoTipo.Color := $0000ECFF;
    Abort;
  end
  else
  begin
    campoTipo.Color := clWindow;
  end;
  if campoClienteFornecedor.text = '' then
  begin
    ShowMessage('O campo CLIENTE/FORNECEDOR � obrigat�rio.');
    campoClienteFornecedor.SetFocus;
    campoClienteFornecedor.Color := $0000ECFF;
    Abort;
  end
  else
  begin
    campoClienteFornecedor.Color := clWindow;
  end;
  if campoProduto.text = '' then
  begin
    ShowMessage('O campo PRODUTO � obrigat�rio.');
    campoProduto.SetFocus;
    campoProduto.Color := $0000ECFF;
    Abort;
  end
  else
  begin
    campoProduto.Color := clWindow;
  end;
  if campoQtde.text = '' then
  begin
    ShowMessage('O campo QUANTIDADE � obrigat�rio.');
    campoQtde.SetFocus;
    campoQtde.Color := $0000ECFF;
    Abort;
  end
  else
  begin
    campoQtde.Color := clWindow;
  end;
  if campoUnidade.text = '' then
  begin
    ShowMessage('O campo UNIDADE � obrigat�rio.');
    campoUnidade.SetFocus;
    campoUnidade.Color := $0000ECFF;
    Abort;
  end
  else
  begin
    campoUnidade.Color := clWindow;
  end;
  if campoUnitario.text = '' then
  begin
    ShowMessage('O campo VALOR UNIT�RIO � obrigat�rio.');
    campoUnitario.SetFocus;
    campoUnitario.Color := $0000ECFF;
    Abort;
  end
  else
  begin
    campoUnitario.Color := clWindow;
  end;

 // ************************************************

 // Tenta gravar registro

  try
    DM.tabLancamentos.Post;
    DM.tabLancamentos.Close;
    DM.tabLancamentos.Open;
  except
    on E: Exception do
    begin
      // Nao diz "salvo com sucesso" se a gravacao falhou; mantem o form aberto
      ShowMessage('N�o foi poss�vel salvar o lan�amento:' + #13 + E.Message);
      Abort;
    end;
  end;

  ShowMessage('Lan�amento salvo com sucesso!');
  Self.Close;

end;

procedure TformAlteracaoLancamentos.Button2Click(Sender: TObject);
begin

    DM.tabLancamentos.Cancel;
    Self.Close;

end;

procedure TformAlteracaoLancamentos.Button3Click(Sender: TObject);
begin

    if MessageDlg('Confirma a exclus�o do lan�amento ?', mtConfirmation, [mbYes,mbNo], 0)=mrYes then
    begin
      DM.tabLancamentos.Delete;
      Self.Close;
    end;

end;


initialization
  RegisterClass(TformAlteracaoLancamentos);

finalization
  UnRegisterClasses([TformAlteracaoLancamentos]);

end.
