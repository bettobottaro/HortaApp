object formAbrirForm: TformAbrirForm
  Left = 0
  Top = 0
  Caption = 'formAbrirForm'
  ClientHeight = 232
  ClientWidth = 375
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
end
