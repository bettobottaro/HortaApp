object frmResultado: TfrmResultado
  Left = 0
  Top = 0
  BorderIcons = [biSystemMenu]
  BorderStyle = bsSingle
  Caption = 'Resultado'
  ClientHeight = 363
  ClientWidth = 650
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -13
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 16
  object Label1: TLabel
    Left = 8
    Top = 339
    Width = 85
    Height = 16
    Caption = 'Total Cr'#233'ditos:'
  end
  object Label2: TLabel
    Left = 243
    Top = 339
    Width = 80
    Height = 16
    Caption = 'Total D'#233'bitos:'
  end
  object Label3: TLabel
    Left = 473
    Top = 339
    Width = 61
    Height = 16
    Caption = 'Resultado:'
  end
  object btDiferentes: TSpeedButton
    Left = 8
    Top = 8
    Width = 129
    Height = 27
    Caption = 'mostrar diferentes'
    OnClick = btDiferentesClick
  end
  object DBGrid1: TDBGrid
    Left = 8
    Top = 41
    Width = 633
    Height = 292
    DataSource = DM.dsResultado
    ReadOnly = True
    TabOrder = 0
    TitleFont.Charset = DEFAULT_CHARSET
    TitleFont.Color = clWindowText
    TitleFont.Height = -13
    TitleFont.Name = 'Tahoma'
    TitleFont.Style = []
    Columns = <
      item
        Expanded = False
        FieldName = 'Credito'
        Title.Alignment = taCenter
        Title.Caption = 'Cr'#233'dito'
        Width = 100
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Debito'
        Title.Alignment = taCenter
        Title.Caption = 'D'#233'bito'
        Width = 100
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Referente'
        Title.Alignment = taCenter
        Width = 389
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Diferente'
        Visible = False
      end>
  end
  object edtCreditos: TEdit
    Left = 100
    Top = 336
    Width = 102
    Height = 24
    TabStop = False
    Alignment = taCenter
    ReadOnly = True
    TabOrder = 1
  end
  object edtDebitos: TEdit
    Left = 333
    Top = 336
    Width = 102
    Height = 24
    TabStop = False
    Alignment = taCenter
    ReadOnly = True
    TabOrder = 2
  end
  object edtResultado: TEdit
    Left = 539
    Top = 336
    Width = 102
    Height = 24
    TabStop = False
    Alignment = taCenter
    ReadOnly = True
    TabOrder = 3
  end
end
