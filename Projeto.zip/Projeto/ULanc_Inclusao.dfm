object frmLanc_Inclusao: TfrmLanc_Inclusao
  Left = 0
  Top = 0
  BorderIcons = [biSystemMenu]
  BorderStyle = bsSingle
  Caption = 'INCLUS'#195'O DE LAN'#199'AMENTOS'
  ClientHeight = 386
  ClientWidth = 385
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -15
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poOwnerFormCenter
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 18
  object Shape3: TShape
    Left = 16
    Top = 8
    Width = 353
    Height = 46
    Brush.Style = bsClear
  end
  object Label1: TLabel
    Left = 16
    Top = 60
    Width = 87
    Height = 18
    Caption = 'Data Compra'
  end
  object Label2: TLabel
    Left = 144
    Top = 60
    Width = 76
    Height = 18
    Caption = 'Vencimento'
  end
  object SpeedButton2: TSpeedButton
    Left = 254
    Top = 80
    Width = 30
    Height = 26
    Caption = '+30d'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -9
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    OnClick = SpeedButton2Click
  end
  object SpeedButton3: TSpeedButton
    Left = 286
    Top = 80
    Width = 30
    Height = 26
    Caption = '+60d'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -9
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    OnClick = SpeedButton3Click
  end
  object SpeedButton4: TSpeedButton
    Left = 318
    Top = 80
    Width = 30
    Height = 26
    Caption = '+90d'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -9
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    OnClick = SpeedButton4Click
  end
  object Label3: TLabel
    Left = 16
    Top = 112
    Width = 42
    Height = 18
    Caption = 'Cliente'
  end
  object Label4: TLabel
    Left = 16
    Top = 164
    Width = 50
    Height = 18
    Caption = 'Produto'
  end
  object Label5: TLabel
    Left = 20
    Top = 216
    Width = 32
    Height = 18
    Caption = 'Qtde'
  end
  object Label6: TLabel
    Left = 168
    Top = 216
    Width = 85
    Height = 18
    Caption = 'Valor Unit'#225'rio'
  end
  object Label7: TLabel
    Left = 279
    Top = 216
    Width = 82
    Height = 18
    Caption = 'Valor Total'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -15
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Label8: TLabel
    Left = 16
    Top = 272
    Width = 26
    Height = 18
    Caption = 'Obs'
  end
  object Label13: TLabel
    Left = 108
    Top = 21
    Width = 38
    Height = 18
    Caption = 'Tipo: '
  end
  object Label14: TLabel
    Left = 85
    Top = 216
    Width = 52
    Height = 18
    Caption = 'Unidade'
  end
  object lblUnidade: TLabel
    Left = 64
    Top = 238
    Width = 5
    Height = 18
    Alignment = taCenter
  end
  object Panel1: TPanel
    Left = 0
    Top = 340
    Width = 385
    Height = 46
    Align = alBottom
    TabOrder = 0
    object btSalvar: TSpeedButton
      Left = 124
      Top = 6
      Width = 129
      Height = 33
      Caption = 'Salvar'
      Glyph.Data = {
        26040000424D2604000000000000360000002800000012000000120000000100
        180000000000F0030000C40E0000C40E00000000000000000000FFFFFFFFFFFF
        FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
        FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF0000FAFAFA9A9A9AAAAAA9C3C2C2DDDB
        DBDEDADADBD9D7DAD8D6D9D6D4D9D5D4D8D4D3D6D2D1D5D3D1D4D3D1BFBEBEA8
        A8A7959595FBFBFB0000EBEBEB1919195D56504D657B2586D62483D22281CF22
        81CE2180CD2080CD207FCD1E7ECA1E7ECD1C7ECE4A64795A544E000000ECECEC
        0000F0F0F0414141938C87748FA34FBAFF51BAFF50B8FF4EB6FE4DB5FD4CB5FC
        4AB3FB4AB2FA4AB3FD48B3FE6B879B89827D29292AF0F0F00000F5F5F5191919
        3F3F409D9A99FFFFFDFFFFFFFFFFFEFFFFF9FFF9F4FDF6F1F8F2ECF3EDE7F4ED
        E8F0EBE68C8A87282828000000F3F3F30000F5F5F52020204343439E9E9EF2EB
        E7E2D4CEE3D6CFE2D5D0E0D4CDDFD3CDDED1CBDBCFC8DBCEC6E6DEDA8F908F27
        2727000000F4F4F40000F5F5F52626264A4A4A9C9C9DF8F7F7F7F4F3F7F4F3F7
        F4F3F7F5F3F7F5F4F7F5F3F5F4F3F5F4F3F2F1F08F8F8F282828000000F4F4F4
        0000F5F5F52F2F2F4E4E4E9D9F9FEBE4E0D8CAC2D9CCC5D9CCC5D9CCC5D9CCC5
        D9CCC5D6CBC4D6C8C1E8E1DF949596282828000000F4F4F40000F6F6F6343434
        535353A1A1A1FFFFFEFFFDFBFEFBFAFEFCFAFEFBFAFEFBFAFEFBFAFEFBFAFFFD
        FBFFFFFF9C9C9C292929000000F4F4F40000F5F5F53A3A3A5D5D5D959595F0F0
        F0F2F2F3EAECECEBEBECECEEEEECEDEEECEEEEEBEDEDF6F6F6F4F4F48E8E8E2C
        2C2C010101F3F3F30000F5F5F54242426868686060606363635B5B5B5252524F
        4F4E4B4B4B4A4A4A4848484646464343434545453C3C3C2F2F2F080808F5F5F5
        0000F6F6F64B4B4B6D6D6D6060605656565454545757575454544D4D4D494949
        4848484444443B3B3B3535353333333535350E0E0EF5F5F50000F7F7F7545454
        5A5A5A414141363636707070C4C4C4C5C5C5BABABAB2B2B2ABABABA4A4A4A3A3
        A3858585484848393939131313F5F5F50000F8F8F85C5C5C4F4F4F2A2A2A1D1D
        1D7C7C7CFBFBFBFDFDFDEFEFEFEDEDEDA7A7A78F8F8FCFCFCFB2B2B25353533E
        3E3E1A1A1AF5F5F50000F8F8F86464645555552F2F2F232323797979F5F5F5F1
        F1F1E0E0E0E7E7E76F6F6F494949BBBBBBADADAD5555554444441E1E1EF5F5F5
        0000F9F9F96E6E6E5656562A2A2A1E1E1E7D7D7DFAFAFAFCFCFCEEEEEEF0F0F0
        8D8D8D6C6C6CC7C7C7B3B3B35D5D5D464646232323F3F3F30000F5F5F5535353
        4141411515150E0E0E5D5D5DCFCFCFCCCCCCBFBFBFBABABA9C9C9C8D8D8DA2A2
        A28686864141412A2A2A828282FFFFFF0000FFFFFFF4F4F4F7F7F7F5F5F5F5F5
        F5F6F6F6FAFAFAF7F7F7F7F7F7F7F7F7F9F9F9FAFAFAF8F8F8F6F6F6F4F4F4F3
        F3F3FFFFFFFFFFFF0000}
      OnClick = btSalvarClick
    end
  end
  object DBEdit1: TDBEdit
    Left = 16
    Top = 617
    Width = 32
    Height = 21
    Color = clBtnFace
    DataField = 'IDLancamento'
    DataSource = DM.dsLancamentos
    Enabled = False
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    ReadOnly = True
    TabOrder = 1
  end
  object campoTipo: TDBComboBox
    Left = 152
    Top = 18
    Width = 105
    Height = 26
    DataField = 'Lanc_tipo'
    DataSource = DMLanc.dsLancamentos
    Items.Strings = (
      'A Receber'
      'A Pagar')
    TabOrder = 2
  end
  object campoDataCompra: TJvDBDatePickerEdit
    Left = 16
    Top = 80
    Width = 108
    Height = 26
    AllowNoDate = True
    DataField = 'Lanc_data'
    DataSource = DMLanc.dsLancamentos
    NoDateShortcut = 46
    TabOrder = 3
  end
  object campoDataVencimento: TJvDBDatePickerEdit
    Left = 144
    Top = 80
    Width = 107
    Height = 26
    AllowNoDate = True
    DataField = 'Lanc_vencimento'
    DataSource = DMLanc.dsLancamentos
    NoDateShortcut = 46
    TabOrder = 4
  end
  object campoCliente: TDBLookupComboBox
    Left = 16
    Top = 132
    Width = 353
    Height = 26
    DataField = 'Lanc_IDCliente'
    DataSource = DMLanc.dsLancamentos
    KeyField = 'IDCliente'
    ListField = 'Cliente_nome'
    ListSource = DMLanc.dsqyClientes_lista
    TabOrder = 5
  end
  object campoProduto: TDBLookupComboBox
    Left = 16
    Top = 184
    Width = 353
    Height = 26
    DataField = 'Lanc_IDProduto'
    DataSource = DMLanc.dsLancamentos
    KeyField = 'IDProduto'
    ListField = 'Concatenacao'
    ListSource = DMLanc.dsqyProdutos_lista
    TabOrder = 6
    OnCloseUp = campoProdutoCloseUp
  end
  object campoQuantidade: TDBEdit
    Left = 16
    Top = 235
    Width = 43
    Height = 26
    DataField = 'Lanc_qtde'
    DataSource = DMLanc.dsLancamentos
    TabOrder = 7
  end
  object campoValorUnitario: TDBEdit
    Left = 160
    Top = 235
    Width = 102
    Height = 26
    DataField = 'Lanc_valorunitario'
    DataSource = DMLanc.dsLancamentos
    TabOrder = 8
  end
  object campoValorTotal: TDBEdit
    Left = 272
    Top = 235
    Width = 97
    Height = 26
    DataField = 'Lanc_valortotal'
    DataSource = DMLanc.dsLancamentos
    TabOrder = 9
  end
  object DBEdit5: TDBEdit
    Left = 16
    Top = 293
    Width = 353
    Height = 26
    DataField = 'Lanc_obs'
    DataSource = DMLanc.dsLancamentos
    TabOrder = 10
  end
  object DBLookupComboBox1: TDBLookupComboBox
    Left = 67
    Top = 235
    Width = 89
    Height = 26
    DataField = 'Lanc_IDCliente'
    DataSource = DMLanc.dsLancamentos
    KeyField = 'IDCliente'
    ListField = 'Cliente_nome'
    ListSource = DMLanc.dsqyClientes_lista
    TabOrder = 11
  end
end
