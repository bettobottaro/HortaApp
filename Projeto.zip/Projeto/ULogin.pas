unit ULogin;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, JvExControls, JvButton, JvTransparentButton, StdCtrls, Mask, acPNG,
  ExtCtrls, INIFiles, Buttons;

type
  TfrmLogin = class(TForm)
    edtSenha: TMaskEdit;
    botaoOk: TJvTransparentButton;
    botaoAbortar: TJvTransparentButton;
    Logo: TImage;
    edtNovaSenha: TEdit;
    edtCript: TEdit;
    btSalvar: TSpeedButton;
    shpFundo: TShape;
    lblNovaSenha: TLabel;
    shpCirculo: TShape;
    lblContador: TLabel;
    pnlNovaSenha: TPanel;
    Shape1: TShape;
    Image1: TImage;
    Label1: TLabel;
    procedure edtSenhaKeyPress(Sender: TObject; var Key: Char);
    procedure botaoOkClick(Sender: TObject);
    procedure botaoAbortarClick(Sender: TObject);
    procedure btGerarClick(Sender: TObject);
    procedure LogoDblClick(Sender: TObject);
    procedure btSalvarClick(Sender: TObject);
    procedure edtNovaSenhaChange(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure Label1Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmLogin: TfrmLogin;

implementation

uses UPrincipal, UDM;

{$R *.dfm}

var
  Tentativa : integer;
  vcontador : integer;


//funcao que retorna o c�digo ASCII dos caracteres
function AsciiToInt(Caracter: Char): Integer;
var
  i: Integer;
begin
  i := 32;
  while i < 255 do begin
    if Chr(i) = Caracter then
      Break;
    i := i + 1;
  end;
  Result := i;
end;


// procedure para redefinir form principal
procedure DefinirFormPrincipal(NovoMainForm: TForm);
var
  TmpMain: ^TCustomForm;
begin
  TmpMain := @Application.Mainform;
  TmpMain^ := NovoMainForm;
end;



{ Esta funcao tem como objetivo criptografar uma string utilizando o c�digo ASCII de cada caracter e
somando a esse c�digo o valor da CHAVE}

Function Cript(texto:string;chave:integer):String;
var
  cont: integer;
  retorno: string;
begin
  if (trim(texto)=EmptyStr) or (chave=0) then begin
    result := texto;
  end else begin
    retorno:='';
    for cont:=1 to length(texto) do begin
      retorno:=retorno+chr(asciitoint(texto[cont])+chave);
    end;
    result:=retorno;
  end;
end;

// ------------------------------------------------------------------

procedure TfrmLogin.botaoAbortarClick(Sender: TObject);
begin

  Application.Terminate;

end;

procedure TfrmLogin.botaoOkClick(Sender: TObject);
var
  Config: TIniFile;

begin

  if edtSenha.Text = '' then
  begin
    Abort;
    edtSenha.SetFocus;
  end;



  if Cript(edtSenha.Text, 5976) = DM.tabLogin.FieldByName('Senha').Value then
    begin

    if not Assigned(formPrincipal) then
    begin
      Application.CreateForm(TformPrincipal, formPrincipal);
    end;

      DefinirFormPrincipal(formPrincipal);
      frmLogin.close;
      formPrincipal.Show;

  end;

    if Cript(edtSenha.Text, 5976) <> DM.tabLogin.FieldByName('Senha').Value then
    begin

        Tentativa := Tentativa + 1;

        if Tentativa >= 3 then
        begin
          Application.Terminate;
        end;

        ShowMessage('Senha incoreta! Tente novamente.' + #13 + #13 + 'Tentativa: ' + IntToStr(Tentativa) + ' de 3');
        edtSenha.Text := '';
        edtSenha.SetFocus;

    end;

end;
procedure TfrmLogin.edtNovaSenhaChange(Sender: TObject);
begin

  if edtNovaSenha.Text <> '' then
    edtCript.Text := Cript(edtNovaSenha.Text, 5976);

  //edtCript.Text := '';

end;

procedure TfrmLogin.edtSenhaKeyPress(Sender: TObject; var Key: Char);
begin

  if Key = #13 then
    botaoOkClick(Sender);

end;

procedure TfrmLogin.FormShow(Sender: TObject);
begin


    // Logotipo
    if DM.tabConfiguracao.FieldByName('Logotipo').Value <> '' then
    if (fileexists(DM.tabConfiguracao.FieldByName('Logotipo').Value)) then
    begin
      Logo.Picture.LoadFromFile(DM.tabConfiguracao.FieldByName('Logotipo').value);
    end;


end;

procedure TfrmLogin.Label1Click(Sender: TObject);
begin

    pnlNovaSenha.Visible := false;

end;

procedure TfrmLogin.LogoDblClick(Sender: TObject);
begin

  lblContador.Visible := true;
  shpCirculo.Visible := true;
  vcontador := vcontador + 1;
  lblContador.Caption := IntToStr(vcontador);

  if vcontador < 3 then
  begin
    Abort;
  end
  else
  begin
    lblContador.Visible := false;
    shpCirculo.Visible := false;
    pnlNovaSenha.Visible := true;
    edtNovaSenha.Text := '';
    edtCript.Text := '';

    edtNovaSenha.setfocus;
  end;

end;

procedure TfrmLogin.btGerarClick(Sender: TObject);
begin

if edtNovaSenha.Text <> '' then
  edtCript.Text := Cript(edtNovaSenha.Text, 5976);

end;

procedure TfrmLogin.btSalvarClick(Sender: TObject);
begin

  if edtCript.Text <> '' then
  begin
    DM.tabLogin.Edit;
    DM.tabLogin.FieldByName('Senha').Value := edtCript.Text;
    DM.tabLogin.Post;

    ShowMessage('Senha atualizada com sucesso!');
    pnlNovaSenha.Visible := false;
    vcontador := 0;
    edtSenha.SetFocus;
  end;

end;

end.
