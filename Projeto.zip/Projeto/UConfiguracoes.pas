unit UConfiguracoes;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, ExtCtrls, DBCtrls, Grids, DBGrids, Buttons, DB, ImgList, StdCtrls,
  Mask;

type
  TformConfiguracoes = class(TForm)
    OpenDialog1: TOpenDialog;
    Panel1: TPanel;
    Label1: TLabel;
    DBEdit1: TDBEdit;
    Label2: TLabel;
    Button2: TButton;
    Button1: TButton;
    ImageList1: TImageList;
    Button3: TButton;
    Button4: TButton;
    Label3: TLabel;
    Button5: TButton;
    Button6: TButton;
    Image1: TImage;
    DBMemo1: TDBMemo;
    DBMemo2: TDBMemo;
    Image2: TImage;
    Shape1: TShape;
    Shape2: TShape;
    procedure SpeedButton1Click(Sender: TObject);
    procedure SpeedButton2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button6Click(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure FormShow(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  formConfiguracoes: TformConfiguracoes;

implementation

uses UDM, UPrincipal;

{$R *.dfm}

procedure TformConfiguracoes.Button1Click(Sender: TObject);
begin

  if DM.tabConfiguracao.State in [dsEdit] then
  begin
    DM.tabConfiguracao.Post;
    DM.tabConfiguracao.Close;
    DM.tabConfiguracao.Open;
    ShowMessage('Altera��es salvas!');
    self.Close;
  end;



end;

procedure TformConfiguracoes.Button2Click(Sender: TObject);
begin

    if DM.tabConfiguracao.State in [dsEdit] then
    begin
      if MessageDlg('Cancela as altera��es ?', mtConfirmation, [mbYes,mbNo], 0)=mrYes then
      begin
        DM.tabConfiguracao.Cancel;
        Self.Close;
      end
      else
      begin
        Abort;
      end;
    end
    else
    begin
      Self.Close;
    end;

end;

procedure TformConfiguracoes.Button3Click(Sender: TObject);
begin

    if MessageDlg('Excluir o wallpaper ?', mtConfirmation, [mbYes,mbNo], 0)=mrYes then
    begin
      DM.tabConfiguracao.Edit;
      DM.tabConfiguracao.FieldByName('Imagem').Value := '';
      Image1.Picture := Nil;
    end;

end;

procedure TformConfiguracoes.Button4Click(Sender: TObject);
begin

  if OpenDialog1.Execute then
  begin
    DM.tabConfiguracao.Edit;
    DM.tabConfiguracao.FieldByName('Imagem').Value := OpenDialog1.FileName;

    if DM.tabConfiguracao.FieldByName('Imagem').Value <> '' then
    begin
      formPrincipal.imgFundo.Picture.LoadFromFile(DM.tabConfiguracao.FieldByName('Imagem').Value);
      Image1.Picture.LoadFromFile(DM.tabConfiguracao.FieldByName('Imagem').value);
    end
    else
    begin
      formPrincipal.imgFundo := Nil;
      Image1.Picture := Nil;
    end;
  end;

end;


procedure TformConfiguracoes.Button5Click(Sender: TObject);
begin

    if MessageDlg('Excluir o logotipo ?', mtConfirmation, [mbYes,mbNo], 0)=mrYes then
    begin
      DM.tabConfiguracao.Edit;
      DM.tabConfiguracao.FieldByName('Logotipo').Value := '';
      Image2.Picture := Nil;
    end;

end;

procedure TformConfiguracoes.Button6Click(Sender: TObject);
begin

  if OpenDialog1.Execute then
  begin
    DM.tabConfiguracao.Edit;
    DM.tabConfiguracao.FieldByName('Logotipo').Value := OpenDialog1.FileName;
    Image2.Picture.LoadFromFile(DM.tabConfiguracao.FieldByName('Logotipo').value);
  end;

end;

procedure TformConfiguracoes.FormShow(Sender: TObject);
begin

    // Wallpaper
    if DM.tabConfiguracao.FieldByName('Imagem').Value <> '' then
    if not(fileexists(DM.tabConfiguracao.FieldByName('Imagem').Value)) then
    begin
      ShowMessage('Imagem de wallpaper n�o encontrada!');
    end
    else
    begin
      Image1.Picture.LoadFromFile(DM.tabConfiguracao.FieldByName('Imagem').value);
    end;


    // Logotipo
    if DM.tabConfiguracao.FieldByName('Logotipo').Value <> '' then
    if not(fileexists(DM.tabConfiguracao.FieldByName('Logotipo').Value)) then
    begin
      ShowMessage('Imagem de logotipo n�o encontrada!');
    end
    else
    begin
      Image2.Picture.LoadFromFile(DM.tabConfiguracao.FieldByName('Logotipo').value);
    end;


end;

procedure TformConfiguracoes.SpeedButton1Click(Sender: TObject);
begin

  if OpenDialog1.Execute then
  begin
    DM.tabConfiguracao.Edit;
    DM.tabConfiguracao.FieldByName('Imagem').Value := OpenDialog1.FileName;

    if DM.tabConfiguracao.FieldByName('Imagem').Value <> '' then
    begin
      formPrincipal.imgFundo.Picture.LoadFromFile(DM.tabConfiguracao.FieldByName('Imagem').Value);
    end
    else
    begin
      formPrincipal.imgFundo := Nil;
    end;
  end;

end;

procedure TformConfiguracoes.SpeedButton2Click(Sender: TObject);
begin

    DM.tabConfiguracao.Edit;
    DM.tabConfiguracao.FieldByName('Imagem').Value := '';

end;

end.
