object formCadastroTiposLancamento: TformCadastroTiposLancamento
  Left = 0
  Top = 0
  BorderIcons = [biSystemMenu]
  Caption = 'Cadastro de Tipos de Lan'#231'amento'
  ClientHeight = 327
  ClientWidth = 331
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  OnClose = FormClose
  PixelsPerInch = 96
  TextHeight = 13
  object DBGrid1: TDBGrid
    Left = 8
    Top = 8
    Width = 313
    Height = 272
    DataSource = DM.dsTiposLancamentos
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 0
    TitleFont.Charset = DEFAULT_CHARSET
    TitleFont.Color = clWindowText
    TitleFont.Height = -11
    TitleFont.Name = 'Tahoma'
    TitleFont.Style = []
    Columns = <
      item
        Alignment = taCenter
        Color = 6029229
        Expanded = False
        FieldName = 'IDTipo'
        Title.Alignment = taCenter
        Title.Caption = 'ID'
        Visible = False
      end
      item
        Alignment = taCenter
        Expanded = False
        FieldName = 'Descricao'
        Title.Alignment = taCenter
        Width = 150
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'OrdemRelatorio'
        Title.Alignment = taCenter
        Title.Caption = 'Ordem no Relat'#243'rio'
        Width = 120
        Visible = True
      end>
  end
  object DBNavigator1: TDBNavigator
    Left = 30
    Top = 286
    Width = 273
    Height = 34
    DataSource = DM.dsTiposLancamentos
    VisibleButtons = [nbInsert, nbDelete, nbPost]
    TabOrder = 1
  end
end
