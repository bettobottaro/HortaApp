unit UGraficoQuantidadeProdutosPeriodo;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, TeEngine, Series, ExtCtrls, TeeProcs, Chart, DBChart, Buttons,
  StdCtrls, JvExControls, JvChart, frxChart, frxClass, frxDBSet, TeeGDIPlus;

type
  TformGraficoQuantidadeProdutosPeriodo = class(TForm)
    DBChart1: TDBChart;
    Series1: TPieSeries;
    Panel1: TPanel;
    SpeedButton1: TSpeedButton;
    SaveDialog1: TSaveDialog;
    SpeedButton2: TSpeedButton;
    tresde: TCheckBox;
    Grafico1: TfrxReport;
    procedure SpeedButton1Click(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure SpeedButton2Click(Sender: TObject);
    procedure tresdeClick(Sender: TObject);
    procedure Grafico1BeforePrint(Sender: TfrxReportComponent);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  formGraficoQuantidadeProdutosPeriodo: TformGraficoQuantidadeProdutosPeriodo;

implementation

uses UDM;

{$R *.dfm}

procedure TformGraficoQuantidadeProdutosPeriodo.FormShow(Sender: TObject);
begin

  DBChart1.Title.caption := 'Quantidades Vendidas de ' + FormatDateTime('dd/mm/yy',DM.tabParametros.FieldByName('DataInicial').value) + ' a ' + FormatDateTime('dd/mm/yy',DM.tabParametros.FieldByName('DataFinal').value);

end;

procedure TformGraficoQuantidadeProdutosPeriodo.Grafico1BeforePrint(
  Sender: TfrxReportComponent);
begin

if Sender.Name = 'Picture1' then
   TfrxPictureView(Sender).Picture.Assign(
     DBChart1.TeeCreateMetafile(False,
       Rect(0, 0, Round(Sender.Width), Round(Sender.Height))));

end;

procedure TformGraficoQuantidadeProdutosPeriodo.SpeedButton1Click(
  Sender: TObject);
begin

  SaveDialog1.FileName := 'Gr�fico - Qtdes Vendidas de '+ FormatDateTime('dd-mm-yy',DM.tabParametros.FieldByName('DataInicial').value) + ' a ' + FormatDateTime('dd-mm-yy',DM.tabParametros.FieldByName('DataFinal').value);

  If SaveDialog1.Execute Then
    Try
      DBChart1.TeeCreateBitmap(clWhite, Rect(0,0, DBChart1.Width, DBChart1.Height)).SaveToFile(SaveDialog1.FileName)
    Finally
      ShowMessage('Gr�fico exportado com sucesso!');
    End;
  end;


procedure TformGraficoQuantidadeProdutosPeriodo.SpeedButton2Click(
  Sender: TObject);
begin

  Grafico1.ShowReport();

end;

procedure TformGraficoQuantidadeProdutosPeriodo.tresdeClick(Sender: TObject);
begin

  if tresde.Checked = true then
  begin
    DBChart1.View3D := true;
  end
  else
  begin
    DBChart1.View3D := false;
  end;

end;

end.
