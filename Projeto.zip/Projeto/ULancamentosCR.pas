unit ULancamentosCR;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, ExtCtrls, Grids, DBGrids, StdCtrls, Buttons, Menus, ImgList, DB;

type
  TfrmLancamentosCR = class(TForm)
    Panel1: TPanel;
    Panel2: TPanel;
    Grade1: TDBGrid;
    edtFiltro: TEdit;
    Label1: TLabel;
    SpeedButton1: TSpeedButton;
    Shape1: TShape;
    Shape2: TShape;
    Label2: TLabel;
    Label3: TLabel;
    ImageList1: TImageList;
    chkOcultarPagos: TCheckBox;
    Label4: TLabel;
    Shape3: TShape;
    Label5: TLabel;
    SpeedButton2: TSpeedButton;
    procedure edtFiltroChange(Sender: TObject);
    procedure Grade1DrawColumnCell(Sender: TObject; const Rect: TRect;
      DataCol: Integer; Column: TColumn; State: TGridDrawState);
    procedure SpeedButton1Click(Sender: TObject);
    procedure Grade1DblClick(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure chkOcultarPagosClick(Sender: TObject);
    procedure SpeedButton2Click(Sender: TObject);
  private
    procedure Filtrar(Sender: TObject);
    { Private declarations }
  public
    { Public declarations }
  end;


var
  frmLancamentosCR: TfrmLancamentosCR;

implementation

uses UDMLanc, ULanc_Inclusao, UDM, UDetalhes, UArvore;

{$R *.dfm}


procedure TfrmLancamentosCR.Filtrar(Sender: TObject);
begin

  if edtFiltro.text = '' then
  begin
    //DM.qyListagemCR.Filtered := false;
  end
  else
  begin
    if chkOcultarPagos.Checked = true then
    begin
      DM.qyListagemCR.Filter := 'Nome like ' + QuotedStr('%'+edtFiltro.text+'%') + ' and saldo > 0' ;
    end
    else
    begin
      DM.qyListagemCR.Filter := 'Nome like ' + QuotedStr('%'+edtFiltro.text+'%');
    end;
  end;

end;



procedure TfrmLancamentosCR.FormClose(Sender: TObject;
  var Action: TCloseAction);
begin

  DM.qyListagemCR.Filtered := false;

end;

procedure TfrmLancamentosCR.FormShow(Sender: TObject);
begin

  chkOcultarPagos.Checked := true;
  edtFiltro.Text := '';
  DM.tabPagamentos.Close;
  DM.tabPagamentos.Open;
  DM.qyListagemCR.Close;
  DM.qyListagemCR.Open;
  DM.qyListagemCR.Filter := 'Saldo > 0';
  DM.qyListagemCR.Filtered := true;

end;

procedure TfrmLancamentosCR.Grade1DblClick(Sender: TObject);
var
  Marcador : TBookMark;

begin

 if DM.qylistagemcr.RecordCount = 0 then
 begin
   Abort;
 end;


  Marcador := DM.qyListagemCR.GetBookmark;

  DM.qyListagem.Filter := 'IDDetalhe = ' + QuotedStr(DM.qyListagemCR.FieldByName('IDDetalhe').value);
  DM.qyListagem.Filtered := true;

  formDetalhes.ShowModal;

  DM.qyListagemCR.Close;
  DM.qyListagemCR.Open;

  if DM.qyListagemCR.BookmarkValid(Marcador) then
  begin
    DM.qyListagemCR.GotoBookmark(Marcador);
  end;



end;

procedure TfrmLancamentosCR.Grade1DrawColumnCell(Sender: TObject;
  const Rect: TRect; DataCol: Integer; Column: TColumn; State: TGridDrawState);

var
  Icon: TBitmap;
  nIndiceImagem: byte;

begin

  Grade1.DefaultDrawDataCell(Rect, Column.field, State);

  if DM.qyListagemCRDias.AsString <> '' then
  begin

  if (DM.qyListagemCRDias.AsInteger > 0) and (DM.qyListagemCRDias.AsInteger <= 30) and (DM.qyListagemCRSaldo.Value >0) then
    begin
      Grade1.Canvas.Brush.Color:=$0080FFFF; // fundo
      Grade1.Canvas.Font.Color:=clBlack; // fonte
      Grade1.Canvas.FillRect(Rect);
      Grade1.DefaultDrawDataCell(Rect, Column.field, State);
    end;
  if (DM.qyListagemCRDias.AsInteger > 30) and (DM.qyListagemCRSaldo.Value >0) then
    begin
      Grade1.Canvas.Brush.Color:=$008282FF; // fundo
      Grade1.Canvas.Font.Color:=clBlack; // fonte
      Grade1.Canvas.FillRect(Rect);
      Grade1.DefaultDrawDataCell(Rect, Column.field, State);
    end;

  end;


  //�cones de acordo com o tipo
  if UpperCase(Column.Field.FieldName) = 'TIPOLANC' then
  begin
    Grade1.Canvas.FillRect(Rect);

    if Column.Field.AsString = 'Venda' then
      nIndiceImagem := 0
    else
    if Column.Field.AsString = 'Compra/Despesa' then
      nIndiceImagem := 1
    else
    if (Column.Field.AsString <> 'Venda') and (Column.Field.AsString <> 'Compra/Despesa') then
      nIndiceImagem := 2;

      // desenha a imagem conforme a condi��o acima
      ImageList1.Draw(Grade1.Canvas, Rect.Left + 9, Rect.Top + 1, nIndiceImagem);


    end;

end;


procedure TfrmLancamentosCR.SpeedButton1Click(Sender: TObject);
begin

  edtFiltro.Text := '';

end;

procedure TfrmLancamentosCR.SpeedButton2Click(Sender: TObject);
begin

  formArvore.ShowModal;

end;

procedure TfrmLancamentosCR.chkOcultarPagosClick(Sender: TObject);
begin

  if edtFiltro.text <> '' then
  begin

    if chkOcultarPagos.Checked = true then
    begin
      DM.qyListagemCR.Filter := 'Nome like ' + QuotedStr('%'+edtFiltro.text+'%') + ' and saldo > 0' ;
    end
    else
    begin
      DM.qyListagemCR.Filter := 'Nome like ' + QuotedStr('%'+edtFiltro.text+'%');
    end;

  end
  else
  begin

    if chkOcultarPagos.Checked = true then
    begin
      DM.qyListagemCR.Filter := 'saldo > 0' ;
    end
    else
    begin
      DM.qyListagemCR.Filter := '';
    end;

  end;


end;

procedure TfrmLancamentosCR.edtFiltroChange(Sender: TObject);
begin

  if edtFiltro.text <> '' then
  begin

    if chkOcultarPagos.Checked = true then
    begin
      DM.qyListagemCR.Filter := 'Nome like ' + QuotedStr('%'+edtFiltro.text+'%') + ' and saldo > 0' ;
    end
    else
    begin
      DM.qyListagemCR.Filter := 'Nome like ' + QuotedStr('%'+edtFiltro.text+'%');
    end;

  end
  else
  begin

    if chkOcultarPagos.Checked = true then
    begin
      DM.qyListagemCR.Filter := 'saldo > 0' ;
    end
    else
    begin
      DM.qyListagemCR.Filter := '';
    end;

  end;


end;


end.
