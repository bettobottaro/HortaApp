unit UCadastroClientesFornecedores;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, ExtCtrls, DBCtrls, Grids, DBGrids, DB;

type
  TformCadastroClientesFornecedores = class(TForm)
    DBGrid1: TDBGrid;
    DBNavigator1: TDBNavigator;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  formCadastroClientesFornecedores: TformCadastroClientesFornecedores;

implementation

uses UDM;

{$R *.dfm}

procedure TformCadastroClientesFornecedores.FormClose(Sender: TObject;
  var Action: TCloseAction);
begin

  if DM.tabClientesFornecedores.state in [dsEdit, dsInsert] then
  begin
        if MessageDlg('Deseja realmente sair sem salvar ?', mtConfirmation, [mbYes,mbNo], 0)=mrYes then
        begin
          DM.tabClientesFornecedores.Cancel;
        end
        else
        begin
          Abort;
        end;
  end;


end;

initialization
  RegisterClass(TformCadastroClientesFornecedores);

finalization
  UnRegisterClasses([TformCadastroClientesFornecedores]);

end.
